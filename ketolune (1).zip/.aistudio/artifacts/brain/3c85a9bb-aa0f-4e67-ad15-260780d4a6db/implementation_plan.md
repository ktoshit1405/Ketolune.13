# KETOLUNE — Frontend-Only Redesign & Implementation Plan

## 1. Executive Summary & Design Foundations
This plan governs the complete visual and structural reconstruction of the KETOLUNE frontend. It translates the bold composition, oversized condensed typography, organic scalloped cloud transitions, and contrasting colour scenes of the reference website into the tactile, atmospheric world of KETOLUNE, while keeping the core mystery intact.

### Non-Negotiable Brand Rules
- **Physical Brand Line**: Exactly `"Made slowly. Meant personally."`
- **Atmosphere Reference**: The original KETOLUNE campaign artwork ("LET THE SURPRISE UNFOLD") with natural kraft paper, fabric, dried botanicals, butterflies, and atmospheric skies.
- **Tone**: Human, intriguing, tactile, and curatorial. Zero fake scarcity, zero fabrication of manufacturing/studio disclosures, and zero generic phrases (such as *"authentic studio maker bandwidth"* or *"uncompromising craft"*).
- **Execution Priority**: Static photographic excellence first across all screen widths. Animation and 3D are deferred until static visual quality and layout composition are verified.
- **Scope**: Frontend-only. No backend, database, or payment rewrites. Functional UI interactions handled via clean, self-contained client state.

---

## 2. Approved Design Tokens & Typography

### Approved Palette
| Token Name | Hex Code | Scene / Usage Application |
| :--- | :--- | :--- |
| **Sky Blue** | `#579CF5` | Hero sky backdrop, primary visual atmosphere |
| **Pale Sky** | `#DDEBFF` | Soft sky tints, cloud silhouettes, gentle hover surfaces |
| **Deep Indigo** | `#19182F` | High-contrast editorial chapter scenes, deep text, nighttime mystery |
| **Atmospheric Blue** | `#394D92` | Mid-tone sky transitions, curatorial frames |
| **Lavender** | `#DDA6F0` | Soft horizon tints, romantic accent transitions |
| **Soft Blush** | `#EFC9D0` | Delicate tactile highlights, floral accents |
| **Warm Cream** | `#F7EFDF` | Main editorial paper ground ("The Idea", note cards, typography) |
| **Kraft Brown** | `#A97849` | Physical parcel wrappers, tag strings, tactile borders |
| **Charcoal** | `#242322` | Editorial typography, fine hairlines, high-contrast readable prose |
| **Pale Chartreuse** | `#E8F36B` | High-impact accent tags, small badges, button highlights (used with discipline) |
| **Tangerine** | `#FF7738` | Warm sunset pop, select micro-interactions |
| **Mint** | `#51C99A` | Fresh botanical accent, active state indicator |

### Typographic System
- **Oversized Condensed Headlines**: `Bebas Neue` / `League Spartan` / bold uppercase tracking-tighter for marquee titles (`LET THE SURPRISE UNFOLD`).
- **Curatorial Body Prose**: Clean modern editorial sans (`Plus Jakarta Sans`) with relaxed leading (`leading-relaxed`) and constrained line widths (`max-w-xl` to `max-w-2xl`).
- **Handwritten Signature Mark**: Authentic cursive script (`Caveat` / `La Belle Aurore`) for "Ketolune" tags and personal notes.
- **Accession & Metadata**: Subdued uppercase tracking-widest (`text-xs uppercase tracking-widest text-[#242322]/60`).

---

## 3. Approved Six-Photo Asset Mapping
The approved six-photo collage is separated into distinct high-resolution assets and purposeful visual scenes:

| Asset Name | Visual Subject | Mapped Section / Component | Composition & Layout Role |
| :--- | :--- | :--- | :--- |
| **Asset 1: Hero Sky Gift** | Tactile wrapped gift held against atmospheric sky & warm daylight | **Hero & Campaign Composition** (`Hero.tsx`) | Primary focal image, anchored prominently in the central viewport with floating detail tags |
| **Asset 2: Handwritten Tag** | Extreme close-up of handwritten "Ketolune" kraft label & natural twine | **The Idea** (`TheIdea.tsx`) | Split-screen anchor proving human physical touch |
| **Asset 3: Overhead Composition** | Flat-lay of natural fabric, dried flowers, twine, and parcel details | **Featured-Gift Capsule** (`FeaturedGiftCapsule.tsx`) | Curated interactive zoom/inspect component |
| **Asset 4: Paper Note & Stationery** | Tactile letterpress note reading "Made slowly. Meant personally." | **The Note / Personal Message** (`TheNote.tsx`) | Intimate reading section highlighting personal dedication |
| **Asset 5: Solitary Mystery Package** | Single closed kraft package resting quietly on limestone slab | **Product Tiers & Enrollment** (`TiersAndEnrollment.tsx`) | Visual proof of mystery and restraint |
| **Asset 6: Wrapped Batch Collection** | Collection of wrapped packages ready for dispatch | **How It Works & The Drop** (`HowItWorks.tsx`) | Visual proof of slow monthly dispatch rhythm |

*Note: All website typography, labels, and CTA buttons remain real HTML/CSS elements; no baked-in image text.*

---

## 4. Components to Remove & Replace

### Components & Visual Patterns to Remove
1. **Empty Dark 3D Viewer & Low-Poly Gift Box**: Completely replace the crude Three.js canvas as the default hero with the approved photographic composition (`Asset 1`).
2. **Plain Blue Hero with Oversized Lime Serif**: Replace with the sky-inspired gradient (`#579CF5` to `#DDEBFF`), condensed sans typography, and drifting organic cloud silhouettes.
3. **Thick Black Outlines & Nested Pill Cards**: Remove repetitive `border-3 border-black` and generic SaaS card patterns. Replace with generous paperspace, delicate hairlines (`1px solid rgba(36,35,34,0.12)`), and organic scalloped edge dividers.
4. **Isolated Purple Pricing Panel**: Replace with a cohesive Warm Cream (`#F7EFDF`) and Deep Indigo (`#19182F`) tier selection block.
5. **Artificial Copy & Leaked Concepts**: Remove all occurrences of "authentic studio maker bandwidth", "uncompromising craft", and detailed internal studio disclosures.
6. **Redundant Floating CTAs & Emojis**: Eliminate screen-cluttering duplicate buttons and ensure zero emojis exist across the codebase.

### New & Rebuilt Components
- `Navbar.tsx`: Art-directed editorial header with clean links, brand wordmark, and subtle allocation indicator.
- `Hero.tsx`: Sky-inspired composition with condensed headline, approved hero photograph, organic cloud transitions, and interactive visual affordance.
- `TheIdea.tsx`: Clean editorial spread pairing the handwritten tag macro shot with succinct, human brand philosophy.
- `HowItWorks.tsx`: Three-step narrative sequence on Warm Cream ground, pairing photographic proof with clear steps.
- `FeaturedGiftCapsule.tsx`: Dedicated tactile presentation component with overhead flat-lay asset, material breakdown, and hover inspection.
- `TiersAndEnrollment.tsx`: Cohesive selection and 3-question curation flow:
  1. *Who is this gift meant for?*
  2. *What atmosphere resonates most?*
  3. *Optional personal message / inscription.*
- `FinalCTA.tsx`: Bold, full-width contrasting colour scene prompting the final reservation.
- `Footer.tsx`: Oversized graphic footer with scalloped cloud silhouette, studio coordinates, dispatch calendar, navigation, and quiet copyright.
- `FeedbackStates.tsx`: Elegant loading skeletons, empty states, and reservation confirmation screens.

---

## 5. Sequential Section Flow & Visual Storytelling

```
┌─────────────────────────────────────────────────────────────┐
│ SCENE 1: THE SKY MARQUEE & CAMPAIGN ARRIVAL                 │
│ Bg: Sky Blue (#579CF5) -> Pale Sky (#DDEBFF)                │
│ Nav: Minimal editorial header                               │
│ Headline: CONDENSED "LET THE SURPRISE UNFOLD"               │
│ Hero Focal: Asset 1 (Sky Gift) + Hairline Material Badges   │
│ Transition: Organic Scalloped Cloud Divider                 │
└─────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ SCENE 2: THE IDEA (EDITORIAL CHAPTER)                       │
│ Bg: Warm Cream (#F7EFDF) | Text: Charcoal (#242322)         │
│ Composition: Asymmetric split layout                        │
│ Focal Image: Asset 2 (Macro Handwritten "Ketolune" Tag)     │
│ Brand Line: "Made slowly. Meant personally."                │
└─────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ SCENE 3: HOW IT WORKS (THE RHYTHM)                          │
│ Bg: Pale Sky (#DDEBFF) / Lavender Sky Tint                  │
│ Focal Image: Asset 6 (Wrapped Batch Collection)             │
│ Flow: 01. The Monthly Drop -> 02. Personal Curation         │
│       -> 03. The Unfolding Surprise                         │
└─────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ SCENE 4: FEATURED GIFT CAPSULE (TACTILE INSPECTION)         │
│ Bg: Deep Indigo (#19182F) | Text: Warm Cream (#F7EFDF)      │
│ Focal Image: Asset 3 (Overhead Flat-Lay Composition)        │
│ Layout: Museum accession presentation, material details     │
└─────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ SCENE 5: TIERS, ENROLLMENT & PERSONAL MESSAGE               │
│ Bg: Warm Cream (#F7EFDF) with Soft Blush / Mint Accents     │
│ Focal Image: Asset 5 (Solitary Mystery Package on Stone)    │
│ Interactive: Tier cards (Single Gift vs Seasonal Journey),  │
│              3-question recipient survey & personal note    │
└─────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ SCENE 6: FINAL SCENE & OVERSIZED GRAPHIC FOOTER             │
│ Bg: Deep Indigo (#19182F) with Scalloped Cloud Transition   │
│ Final CTA: High-impact reservation button                   │
│ Graphic Footer: Studio location, dispatch dates, brand seal │
└─────────────────────────────────────────────────────────────┘
```

---

## 6. Interaction & Animation Strategy
1. **Static Baseline First**: All sections, grids, typographies, and images must look pristine without CSS animations active.
2. **Subtle Motion Principles**:
   - Drifting paper clouds with subtle horizontal translation.
   - Mouse-movement parallax on hero image layer and floating detail annotations.
   - Smooth accordions for the 3-question enrollment flow.
   - Seamless tab / carousel inspection in the Featured-Gift Capsule.
   - Respect `prefers-reduced-motion` across all components.
3. **Interactive 3D Gate**:
   - 3D is strictly an optional enhanced mode accessible via a secondary toggle button (`[ View Interactive 3D Model ]`).
   - If toggled, the model will only mount if Three.js assets and WebGL initialize cleanly without layout shifts; otherwise, it falls back instantly to photographic inspection.

---

## 7. Explicit Responsive Behaviour Matrix

| Breakpoint | Viewport Width | Layout & Composition Adjustments |
| :--- | :--- | :--- |
| **Desktop Wide** | 1440px+ | Full multi-column editorial spread, asymmetric overlapping photo cards, expansive cloud dividers. |
| **Desktop Standard**| 1280px | Constrained containers (`max-w-7xl`), balanced margins, prominent hero composition. |
| **Laptop / Small Desktop** | 1024px | Stacked hero image with side-aligned headline; 2-column grid for tier cards and accession metadata. |
| **Tablet Landscape** | 834px | Full-width photo heroes with overlapping text cards; horizontal scrolling for photo gallery. |
| **Tablet Portrait** | 768px | Single-column narrative flow, sticky mobile reservation bar, tap-friendly question controls. |
| **Large Mobile** | 430px / 390px | Vertically stacked scenes, full-width touch targets (minimum 48px), condensed headline font sizing adjusted to prevent line overflow. |
| **Small Mobile** | 375px | Compact padding (`px-4`), preserved typographic hierarchy, crisp single-column card layouts with zero horizontal scroll. |

---

## 8. Implementation Order & Verification Process

1. **Step 1: Asset Audit & Public Directory Setup**
   - Ensure the 6 approved photographic assets and the hero campaign art are placed in `/public/images/` with clean paths.
   - Implement safe `onError` fallbacks on all image tags.

2. **Step 2: Design Tokens & Tailwind Configuration**
   - Update CSS variables and Tailwind utilities with the exact approved 12-color hex palette.
   - Ensure font families for condensed sans, editorial serif, and handwritten script are linked in `index.html`.

3. **Step 3: Remove Failed Frontend Components**
   - Delete/deprecate `StudioIngredients.tsx`, placeholder 3D stages, and clunky thick-border card components.

4. **Step 4: Build Static Responsive Scenes**
   - Implement `Hero.tsx`, `TheIdea.tsx`, `HowItWorks.tsx`, `FeaturedGiftCapsule.tsx`, `TiersAndEnrollment.tsx`, and `Footer.tsx`.
   - Implement empty, loading, and successful enrollment feedback states.

5. **Step 5: Visual Verification & Polish**
   - Compile and lint the applet.
   - Verify rendered output across all target viewport sizes (375px to 1440px).
   - Verify absence of emojis, artificial disclosures, and broken layouts.

---

## 9. Clear Acceptance Criteria
- [ ] Visual design is distinct and directly inspired by the Lofty Lab reference (bold condensed type, sky scenes, organic transitions, contrasting color chapters).
- [ ] All 6 panels from the approved collage are mapped to specific, meaningful sections with real photographic assets.
- [ ] Hero displays approved photographic artwork prominently in the top viewport; no empty 3D stage.
- [ ] Approved 12-color palette is adhered to across all sections.
- [ ] Exact brand line `"Made slowly. Meant personally."` is featured accurately.
- [ ] No emojis, no artificial technical jargon ("authentic studio maker bandwidth"), and no fake scarcity.
- [ ] Complete 3-question enrollment flow with optional personal message functions smoothly in local state.
- [ ] Fully responsive and tested at 375px, 390px, 430px, 768px, 834px, 1024px, 1280px, and 1440px.
- [ ] Applet compiles cleanly with zero lint errors and passes production build.
