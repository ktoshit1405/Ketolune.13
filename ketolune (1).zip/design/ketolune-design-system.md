# KETOLUNE Design System Specification
Derived from Reference Framer Website Architecture + KETOLUNE Brand Visual Identity

## Palette
- **Sky & Atmosphere**: `#3b82f6` (Vibrant Blue), `#60a5fa` (Soft Sky), `#dbeafe` (Pale Mist), `#f0fdf4` (Soft Mint)
- **Primary Canvas**: `#ffffff` (Clean Paper White), `#f8fafc` (Ultra Light Slate), `#f3e8d2` (Warm Cream)
- **Deep Contrast**: `#0f172a` (Slate Black), `#1e1b4b` (Midnight Indigo)
- **Accents**:
  - `#e8f36b` (Signature Pale Chartreuse)
  - `#a6a0d7` / `#c084fc` (Pastel Lavender / Lilac)
  - `#fb923c` (Warm Ochre / Orange)
  - `#34d399` (Mint Green)
  - `#f472b6` (Soft Blush)
  - `#38bdf8` (Cerulean Cyan)

## Typography
- **Display**: High-contrast editorial serif (`Cormorant Garamond` / `Syne` / `Playfair Display`) + condensed grotesque bold (`Plus Jakarta Sans` / `Inter` font-black tracking-tight).
- **Body**: Clean readable modern sans (`Plus Jakarta Sans`).
- **Metadata**: Monospace tabular numerals (`JetBrains Mono`).

## Tactile Components
- Scalloped / arch cloud borders (`<svg>` masked divider / scalloped scallops).
- Interactive sticker badges (eyes tracking cursor, fluttering butterfly, wax seal, rainbow cloud).
- Stacked colorful service cards with interactive expand/click.
- Fanning vertical cards in footer with hover elevation and tilt.
- Floating bottom-right quick action pill ("Enroll for Drop 01").
