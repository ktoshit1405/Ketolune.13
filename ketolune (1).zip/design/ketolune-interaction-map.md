# KETOLUNE Asset & Interaction Map

## Asset Mapping
- **Hero Canvas Artwork**: `/src/assets/images/ketolune_campaign_hero_1791402590851.jpg` (Full-bleed kraft box on basalt rock, dried botanicals, frayed silk, electric blue butterfly, textile clouds).
- **Secondary Hero Cutout / Box**: `/src/assets/images/hero_ketolune_box_1791401654002.jpg` (Close tactile inspection).
- **Craft Workbench / Made Slowly**: `/src/assets/images/craft_made_slowly_1791401666377.jpg` (Wheel-thrown clay, pure beeswax candle, linen spools, fountain ink).
- **Archival Keepsake Note**: `/src/assets/images/note_the_part_they_keep_1791401680168.jpg` (Deckled cotton rag paper, antique fountain pen, plum botanical wax seal).
- **Gift World Collage**: `/src/assets/images/gift_world_collage_1791401692409.jpg` (Still-life spread of Mini, Medium, and Large components).
- **Paper & Scraps Macro**: `/src/assets/images/ketolune_paper_craft_1791402601787.jpg` (Torn deckled edges, frayed silk ribbons, natural twine).

## Key Interactions
1. **Interactive Tracking Eyes Sticker**:
   - Eyes placed beside the headline whose pupils smoothly track the cursor coordinates anywhere in the viewport.
2. **Fluttering Butterfly**:
   - Electric blue butterfly detail drifting with gentle organic flutter.
3. **Scalloped Arch Cloud Transitions**:
   - Smooth cloud arch curves separating sections.
4. **Stacked Colorful Craft Accordion**:
   - 5 colorful full-width cards (Blue, Orange, Green, Yellow, Lilac) that stack and expand interactively.
5. **Infinite Marquee Ticker**:
   - Continuous smooth horizontal looping pills.
6. **Footer Fanning Cards**:
   - 4 vertical cards that lift, rotate subtly, and reveal an "Explore →" badge on hover.
7. **Floating Quick-Action Pill**:
   - Bottom right sticky pill button ("ENROLL FOR DROP 01").
8. **Fully Operational Modals & Drawers**:
   - 3-Question intimate enrollment modal.
   - Curation reveal & configurator.
   - Cart drawer & trustworthy checkout (INR pricing: Mini ₹379, Medium ₹579, Large ₹779, Delivery ₹19, Tip ₹50).
   - Real order tracking view.
