# Reference Website Reverse-Engineering & Architecture Analysis
**Source Reference**: Lofty Lab (Framer Website Experience)

## 1. Core Visual & Experiential Beats
1. **Floating Pill Navigation**:
   - Centered floating navbar with rounded pill container.
   - Distinct brand mark badge + clean page links ("Home", "The Idea", "How It Works", "The Batch", "Gift World", "Track Journey").
   - Action triggers (Enroll button, Bag drawer trigger).
   - Sticky floating bottom-right CTA pill ("ENROLL FOR BATCH").

2. **The Hero Experience**:
   - Atmospheric sky-blue & cloud backdrop with soft drifting gradients.
   - Oversized condensed headline with high-contrast typography ("LET THE SURPRISE UNFOLD").
   - Playful, interactive tactile elements (eyes tracking the mouse pointer, fluttering butterfly, drifting clouds).
   - Central call to action pill ("Enroll for Drop 01") and secondary action.

3. **Scalloped / Cloud-Arch Section Transitions**:
   - Signature scalloped / cloud-arch SVG border mask between sections (e.g. Hero into Manifesto, and Batch into Testimonials).
   - Smoothly reveals the white/cream tactile content below as you scroll.

4. **Conversational Manifesto Section**:
   - Large headline + conversational statement ("An LA social media agency..." -> translated to KETOLUNE: "A personalized mystery gifting studio. We don't pull items from warehouse shelves. Think of us as your personal maker, chandler, and letterer in one tactile parcel.").
   - Inline decorative stickers/badges ("90's Baby", "Made Slowly", "Meant Personally", "No Warehouse Stock").
   - Featured editorial photography with wavy badge and playful sticky notes.

5. **Our Works / Product Curations**:
   - Large condensed title with "Explore All Curations" button.
   - Editorial photography cards with pill category tags ("Mini Mystery", "Medium Mystery", "Large Heirloom Mystery").
   - Hover reveals ("View Curation →") and interactive tier selection.

6. **Interactive Stacked Service / Craft Cards**:
   - Stacked cards in distinct vibrant editorial pastel colors that overlap and reveal on scroll/click:
     - 01 Electric Blue: Raw Stoneware Clay (Wheel-thrown, double-fired, mineral glaze)
     - 02 Vibrant Orange: Hand-Poured Beeswax (145°F pure filtered cappings, custom aroma infusion)
     - 03 Emerald Green: Deckled Cotton Rag Note (300gsm hand-torn, archival fountain pen)
     - 04 Chartreuse Yellow: Plant-Dyed Frayed Silk (Madder & indigo ribbon ties)
     - 05 Lavender Violet: The Mystery Unfolding (Basalt stone foundation, dried florals, wax seal)

7. **Infinite Marquee / Pill Ticker ("Our Superpowers" -> "The Studio Ingredients")**:
   - Horizontal drifting pills marquee with colorful tags ("Zero Warehouse Stock", "Made Slowly", "Meant Personally", "Pure Filtered Beeswax", "Wild Basalt Stoneware", "300gsm Cotton Rag", "7-8 Day Making", "No Two Identical").

8. **Our Process (3 Distinct Steps with Illustrated Badges)**:
   - 01: Plan / Tell Us About Them (Star/Pencil badge, mint background)
   - 02: Action / Studio Crafts (Lightning/Wheel badge, cobalt background)
   - 03: Amplify / The Surprise Unfolds (Rainbow/Gift badge, coral background)

9. **The Batch & Why Us (4 Numbered Feature Cards with Stickers)**:
   - 01: Human Effort (Smile / Hand sticker)
   - 02: Strict 30 Capacity (Focus / Studio sticker)
   - 03: Real Anticipation (Vibe / Clock sticker)
   - 04: Archival Keepsake (Lightning / Letter sticker)

10. **Drop 01 Studio Metrics**:
    - "+30 Total Slots", "7–8 Days Making Cycle", "₹379 Starting Tier".

11. **Giver Keepsake Notes (Speech Bubble & Letter Format)**:
    - Floating testimonial letter cards in vivid pastels with avatars, wax seal stamps, and genuine giver sentiments.

12. **Pre-Footer Action Banner**:
    - Large hero card with artwork and "Ready to Let the Surprise Unfold?" + CTA.

13. **Signature Fanning Cards Footer**:
    - Interactive colored vertical cards that lift and tilt on hover ("The Idea", "How It Works", "The Batch", "Enroll / Bag") with an interactive "Explore →" badge!
