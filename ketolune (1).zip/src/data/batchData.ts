export interface BatchTier {
  id: 'mini' | 'medium' | 'large';
  name: string; // "The Little Keepsake", "The Thoughtful Collection", "The Grand Unfolding"
  customerFacingName: string;
  totalCapacity: number;
  enrolledCount: number;
  priceINR: number;
  tagline: string;
  description: string;
  contents: string[];
  dimensions: string;
}

export interface BatchInfo {
  batchNumber: string;
  status: 'OPEN' | 'CLOSING_SOON' | 'CLOSED';
  dates: {
    enrollmentEnd: string;
    selectionDate: string;
    bookingWindow: string;
    productionDays: string;
    shippingEstimate: string;
  };
  tiers: BatchTier[];
  deliveryFeeINR: number;
  monthlyEnrollmentCap: number;
  currentEnrolledCount: number;
}

export const CURRENT_BATCH: BatchInfo = {
  batchNumber: "Studio Allotment",
  status: "OPEN",
  deliveryFeeINR: 19, // Approved standard delivery charge: ₹19
  monthlyEnrollmentCap: 50, // Approved monthly capacity: 50 members
  currentEnrolledCount: 38,
  dates: {
    enrollmentEnd: "OCT 20",
    selectionDate: "OCT 21",
    bookingWindow: "OCT 22 — OCT 23",
    productionDays: "Approximately 7–8 business days preparation before dispatch",
    shippingEstimate: "Dispatched upon studio inspection"
  },
  tiers: [
    {
      id: 'mini',
      name: "The Little Keepsake",
      customerFacingName: "The Little Keepsake",
      totalCapacity: 25,
      enrolledCount: 19,
      priceINR: 399, // Approved price: ₹399
      tagline: "An intimate, tactile token of genuine attention.",
      description: "A quiet, thoughtful mystery gesture guided by your recipient observations. Hand-wrapped in heavyweight unbleached kraft paper with an authentic wax impression and your keepsake note.",
      contents: [
        "Curated handmade mystery selection guided by your 3 observations",
        "Hand-lettered archival keepsake note in your words",
        "Hand-pressed botanical wax seal impression",
        "Tactile unbleached kraft presentation packaging"
      ],
      dimensions: "14 × 14 × 10 cm"
    },
    {
      id: 'medium',
      name: "The Thoughtful Collection",
      customerFacingName: "The Thoughtful Collection",
      totalCapacity: 15,
      enrolledCount: 12,
      priceINR: 599, // Approved price: ₹599
      tagline: "Our signature multi-sensory mystery assembly.",
      description: "A fuller unfolding of sentiment and surprise. Individually curated around their quiet habits, hand-assembled, and sealed in archival presentation wrapping with dried botanicals.",
      contents: [
        "Signature multi-element mystery gift assembly",
        "Personalized archival note with your dedicated words",
        "Hand-pressed botanical wax seal impression",
        "Curated dried botanical sprig tied to exterior tag",
        "Hand-tied tactile presentation wrapping"
      ],
      dimensions: "22 × 18 × 14 cm"
    },
    {
      id: 'large',
      name: "The Grand Unfolding",
      customerFacingName: "The Grand Unfolding",
      totalCapacity: 10,
      enrolledCount: 7,
      priceINR: 799, // Approved price: ₹799
      tagline: "A substantial, unrepeatable centerpiece surprise.",
      description: "Our most comprehensive allocation. A deeply personal surprise assembly designed to be kept for years, delivered in our handcrafted rigid presentation box.",
      contents: [
        "Centerpiece heirloom mystery gift assembly",
        "Curated sensory & tactile companion pieces",
        "Extended archival keepsake letter with your dedication",
        "Bespoke handcrafted presentation box with hand-tied ribbon closure",
        "Personal botanical wax impression"
      ],
      dimensions: "28 × 24 × 16 cm"
    }
  ]
};

export interface CustomizationOption {
  aroma: {
    id: string;
    label: string;
    notes: string;
  }[];
  ceramicFinish: {
    id: string;
    label: string;
    hex: string;
    texture: string;
  }[];
  ribbonColor: {
    id: string;
    label: string;
    hex: string;
  }[];
  waxSealColor: {
    id: string;
    label: string;
    hex: string;
  }[];
}

export const CUSTOMIZATION_OPTIONS: CustomizationOption = {
  aroma: [
    { id: 'rain-moss', label: 'Petrichor & Wet Moss', notes: 'Rain on stone, wild violet, crushed fern' },
    { id: 'smoked-fig', label: 'Smoked Fig & Raw Honey', notes: 'Wild fig leaves, charred birch, honeyed amber' },
    { id: 'lavender-cypress', label: 'Alpine Lavender & Cypress', notes: 'Dried lavender buds, resinous pine, cold stone' },
    { id: 'unscented', label: 'Unscented Pure Clean', notes: 'Zero fragrance, pure clean tactile presence' }
  ],
  ceramicFinish: [
    { id: 'volcanic-charcoal', label: 'Volcanic Basalt', hex: '#262831', texture: 'Matte, textured mineral tone' },
    { id: 'raw-terracotta', label: 'Warm Ochre Bisque', hex: '#9d6854', texture: 'Earthy warmth presentation tone' },
    { id: 'pale-celadon', label: 'Mist Celadon', hex: '#778484', texture: 'Silky satin tactile finish' },
    { id: 'chalk-white', label: 'Eggshell Chalk', hex: '#d9d4c7', texture: 'Subtle specks, soft matte finish' }
  ],
  ribbonColor: [
    { id: 'dusty-lavender', label: 'Dusty Lavender Tie', hex: '#978faa' },
    { id: 'chartreuse-silk', label: 'Muted Pale Chartreuse', hex: '#e8f36b' },
    { id: 'raw-kraft-cord', label: 'Natural Spun Linen Cord', hex: '#b5a18a' },
    { id: 'charcoal-silk', label: 'Washed Charcoal Ribbon', hex: '#373a46' }
  ],
  waxSealColor: [
    { id: 'plum-wax', label: 'Deep Plum Wax', hex: '#582d3e' },
    { id: 'antique-bronze', label: 'Antique Bronze Wax', hex: '#7e6445' },
    { id: 'forest-ink', label: 'Forest Ink Wax', hex: '#263b32' }
  ]
};

export interface OrderState {
  orderId: string;
  recipientName: string;
  tierId: 'mini' | 'medium' | 'large';
  collectionId?: string;
  interestId?: string;
  selectedAroma: string;
  selectedCeramic: string;
  selectedRibbon: string;
  selectedWaxSeal: string;
  noteText: string;
  appreciationAmountINR: number;
  currentMilestone: number; // 0 to 6
  estimatedDelivery: string;
  createdAt: string;
  shippingAddress?: {
    name: string;
    address: string;
    city: string;
    postalCode: string;
    state: string;
  };
}

export const SAMPLE_ORDERS: Record<string, OrderState> = {
  'KL-8821': {
    orderId: 'KL-8821',
    recipientName: 'Elena Rostova',
    tierId: 'medium',
    collectionId: 'botanical-herbarium',
    interestId: 'pressed-flowers',
    selectedAroma: 'Alpine Lavender & Cypress',
    selectedCeramic: 'Volcanic Basalt',
    selectedRibbon: 'Dusty Lavender Tie',
    selectedWaxSeal: 'Deep Plum Wax',
    noteText: "To the one who notices the quietest light at dusk. May this little weight bring your mornings stillness.",
    appreciationAmountINR: 50,
    currentMilestone: 3, // 3: "BEING MADE"
    estimatedDelivery: 'OCT 26, 2026',
    createdAt: 'OCT 12, 2026',
    shippingAddress: {
      name: 'Elena Rostova',
      address: '42 Meadowbrook Crescent, Apt 3B',
      city: 'Bengaluru',
      postalCode: '560038',
      state: 'Karnataka'
    }
  }
};
