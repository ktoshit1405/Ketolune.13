export type RecipientPath = 'boys' | 'girls';

export interface GiftItem {
  id: string;
  name: string;
  description: string;
  materials: string;
  tierCompatibility: ('keepsake' | 'thoughtful' | 'grand')[];
}

export interface CollectionInterest {
  id: string;
  label: string;
  description: string;
  sampleItems: string[];
}

export interface CuratedCollection {
  id: string;
  path: RecipientPath;
  title: string;
  tagline: string;
  description: string;
  themeExplanation: string;
  coverImage: string;
  interests: CollectionInterest[];
  availableItems: GiftItem[];
  availableTiers: ('keepsake' | 'thoughtful' | 'grand')[];
  isAvailable: boolean;
  order: number;
}

export const CURATED_COLLECTIONS: CuratedCollection[] = [
  // --- BOYS COLLECTIONS ---
  {
    id: 'artisan-worktable',
    path: 'boys',
    title: 'The Artisan Worktable',
    tagline: 'Raw tactile craft, natural woods, mineral weights & workshop utility.',
    description: 'For the one who appreciates honest materials, quiet workshops, and everyday objects built with patient human hands.',
    themeExplanation: 'Anchored in earthy basalt stoneware, natural woodgrain, and beeswax finishes. Designed to reside naturally on an active desk or study table.',
    coverImage: '/images/craft_made_slowly.jpg',
    isAvailable: true,
    order: 1,
    availableTiers: ['keepsake', 'thoughtful', 'grand'],
    interests: [
      {
        id: 'quiet-rituals',
        label: 'Quiet Daily Rituals & Coffee',
        description: 'Morning habits, unhurried routines, slow espresso, quiet reading moments.',
        sampleItems: ['Handmade basalt desk weight', 'Cedarwood solid balm', 'Archival morning note']
      },
      {
        id: 'wood-leather',
        label: 'Woodworking & Hand Tools',
        description: 'Tactile affinity for natural wood grains, oiled leather, and durable instruments.',
        sampleItems: ['Carved walnut pocket piece', 'Vegetable-tanned leather cord', 'Wax-sealed craft seal']
      },
      {
        id: 'minimal-utility',
        label: 'Minimalist Architecture & Utility',
        description: 'Clean geometry, functional stationery, and unadorned surfaces.',
        sampleItems: ['Geometric stoneware vessel', 'Architectural rule marker', 'Letterpress dedication card']
      }
    ],
    availableItems: [
      {
        id: 'basalt-weight',
        name: 'Cast Basalt Desk Weight',
        description: 'Hand-shaped mineral stone weight with tactile textured matte surface.',
        materials: 'Natural volcanic basalt, vegetable felt base',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      },
      {
        id: 'walnut-pebble',
        name: 'Carved Walnut Pocket Keepsake',
        description: 'Ergonomically carved walnut worry-stone polished with pure beeswax.',
        materials: 'Fallen walnut hardwood, raw beeswax polish',
        tierCompatibility: ['thoughtful', 'grand']
      },
      {
        id: 'cedar-balm',
        name: 'Workshop Cedarwood & Fir Balm',
        description: 'Hand-blended solid botanical grooming balm in aluminum screw-top tin.',
        materials: 'Organic jojoba, beeswax, Atlas cedar essential oil',
        tierCompatibility: ['thoughtful', 'grand']
      },
      {
        id: 'archival-letter',
        name: 'Dip-Pen Keepsake Inscription',
        description: 'Your personal dedication written word-for-word onto heavy 300gsm cotton paper.',
        materials: 'Deckled cotton rag, archival carbon black ink, wax seal',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      }
    ]
  },
  {
    id: 'fandom-chronicles',
    path: 'boys',
    title: 'The Fandom & Lore Chronicles',
    tagline: 'Deep fictional worlds, gaming lore, indie nostalgia & epic narratives.',
    description: 'For the dedicated fan whose imagination lives in fantasy realms, game universes, or cherished animated sagas.',
    themeExplanation: 'We distill the atmosphere of their favorite universes into subtle, mature handmade keepsakes—avoiding cheap plastic merch in favor of heirloom immersion.',
    coverImage: '/images/gift_world_collage.jpg',
    isAvailable: true,
    order: 2,
    availableTiers: ['keepsake', 'thoughtful', 'grand'],
    interests: [
      {
        id: 'anime-manga',
        label: 'Anime & Studio Ghibli Aesthetics',
        description: 'Atmospheric animations, wandering heroes, quiet countryside landscapes.',
        sampleItems: ['Antiqued fantasy quest letter', 'Pressed botanical seal', 'Character essence aroma']
      },
      {
        id: 'gaming-lore',
        label: 'Gaming Universes & Indie RPGs',
        description: 'Expansive game lore, Souls-like resilience, nostalgic 16-bit soundtracks.',
        sampleItems: ['Embossed brass medallion', 'Wax-sealed traveler map note', 'Campfire amber wax tablet']
      },
      {
        id: 'sci-fi-fantasy',
        label: 'Sci-Fi & High Fantasy Literature',
        description: 'Ancient archives, starlit voyages, mythic brotherhood, heroic oaths.',
        sampleItems: ['Archival manuscript inscription', 'Antiqued compass keepsake', 'Forest ink wax seal']
      }
    ],
    availableItems: [
      {
        id: 'lore-tablet',
        name: 'Custom Quest Letter & Wax Seal',
        description: 'A bespoke parchment letter written from within the narrative universe of their favorite lore.',
        materials: 'Tea-stained cotton rag, metallic seal impression, twine',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      },
      {
        id: 'brass-token',
        name: 'Hand-Embossed Guild Medallion',
        description: 'Heavy solid brass pocket coin stamped with a symbolic crest.',
        materials: 'Solid brass, hand-patinated antique finish',
        tierCompatibility: ['thoughtful', 'grand']
      },
      {
        id: 'campfire-amber',
        name: 'Campfire Smoke & Amber Aroma Tablet',
        description: 'Hand-poured beeswax tablet with notes of birch tar, sweet amber, and spruce.',
        materials: 'Pure beeswax, cold-pressed botanical essences, hemp tie',
        tierCompatibility: ['thoughtful', 'grand']
      }
    ]
  },
  {
    id: 'midnight-study',
    path: 'boys',
    title: 'The Midnight Study & Kinship',
    tagline: 'Late-night notebooks, inside jokes, brotherhood & timeless companionship.',
    description: 'For the friend, brother, or partner who stays up debating ideas, listening to vinyl, and remembering the quiet stories only the two of you share.',
    themeExplanation: 'Warm amber tones, heavy paper goods, hand-bound bindings, and frank sentiments that skip the awkwardness of sentimental greetings.',
    coverImage: '/images/note_the_part_they_keep.jpg',
    isAvailable: true,
    order: 3,
    availableTiers: ['keepsake', 'thoughtful', 'grand'],
    interests: [
      {
        id: 'deep-friendship',
        label: 'Brotherhood & Shared Memories',
        description: 'Inside jokes, unspoken loyalty, memories of surviving life changes together.',
        sampleItems: ['Dedicated honest letter', 'Frayed charcoal linen ribbon', 'Desk companion stone']
      },
      {
        id: 'late-night-study',
        label: 'Philosophy, Books & Espresso',
        description: 'Quiet nocturnal reading, margin notes, rain on glass, classic cinema.',
        sampleItems: ['Hand-bound pocket notebook', 'Dark roast & cardamom sachet', 'Brass bookmark']
      },
      {
        id: 'music-vinyl',
        label: 'Music, Indie Bands & Vinyl Records',
        description: 'Album artwork appreciation, lo-fi beats, lyrical depth, personal playlists.',
        sampleItems: ['Lyrics keepsake card', 'Vinyl-inspired seal', 'Aromatic smoked fig candle']
      }
    ],
    availableItems: [
      {
        id: 'pocket-journal',
        name: 'Hand-Bound Kraft Notebook',
        description: 'Smyth-sewn 64-page blank notebook with unbleached heavy kraft covers.',
        materials: '100gsm fountain pen friendly paper, linen thread',
        tierCompatibility: ['thoughtful', 'grand']
      },
      {
        id: 'brotherhood-note',
        name: 'Honest Kinship Dedication Note',
        description: 'Word-for-word inscription capturing your raw gratitude or shared inside memory.',
        materials: 'Archival heavy cardstock, dip-pen ink, wax impression',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      },
      {
        id: 'brass-bookmark',
        name: 'Hand-Finished Brass Bookmark',
        description: 'Slender, weighted brass reading marker that ages into a unique patina.',
        materials: 'Solid brass, matte brushed finish',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      }
    ]
  },
  {
    id: 'trail-solitary',
    path: 'boys',
    title: 'The Trail & Solitary Path',
    tagline: 'Open ridges, endurance, solitary trails, pine resin & wind.',
    description: 'For the explorer, runner, or thinker who finds their balance in wide open air, solo disciplines, and cold mornings.',
    themeExplanation: 'Durable natural fibers, mountain botanicals, and grounded symbols of perseverance and quiet strength.',
    coverImage: '/images/hero_ketolune_box.jpg',
    isAvailable: true,
    order: 4,
    availableTiers: ['keepsake', 'thoughtful', 'grand'],
    interests: [
      {
        id: 'hiking-outdoors',
        label: 'Mountain Trails & Camping',
        description: 'Trail markers, alpine air, solitary ridge hikes, forest serenity.',
        sampleItems: ['Pine resin travel tin candle', 'Natural linen bandana', 'Topographic note card']
      },
      {
        id: 'solitary-discipline',
        label: 'Running, Athletics & Endurance',
        description: 'Early morning miles, quiet persistence, focused training rituals.',
        sampleItems: ['Milestone milestone coin', 'Hydrosol recovery mist', 'Unbroken encouragement note']
      },
      {
        id: 'natural-elements',
        label: 'Earth, Geology & Cold Rivers',
        description: 'Raw stone textures, geological specimens, tactile riverbed rocks.',
        sampleItems: ['River stone talisman', 'Linen utility wrap', 'Deep forest wax stamp']
      }
    ],
    availableItems: [
      {
        id: 'pine-candle',
        name: 'Highland Pine & Juniper Travel Candle',
        description: 'Pure soy & beeswax candle infused with Siberian fir needle and crushed juniper.',
        materials: 'Natural wax blend, cotton wick, seamless travel tin',
        tierCompatibility: ['thoughtful', 'grand']
      },
      {
        id: 'linen-bandana',
        name: 'Hand-Dyed Raw Linen Kerchief',
        description: 'Washed Belgian linen kerchief with frayed fringed edges.',
        materials: '100% natural unbleached linen, plant-toned wash',
        tierCompatibility: ['thoughtful', 'grand']
      },
      {
        id: 'milestone-talisman',
        name: 'Carved Milestone River Talisman',
        description: 'Smooth river stone inscribed with a single meaningful date or coordinate.',
        materials: 'Natural river stone, hand-etched numeral',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      }
    ]
  },

  // --- GIRLS COLLECTIONS ---
  {
    id: 'botanical-herbarium',
    path: 'girls',
    title: 'The Botanical Herbarium',
    tagline: 'Pressed wildflowers, apothecary florals, soft morning light & tea ceremonies.',
    description: 'For the one who pauses for morning sunlight, presses flowers inside heavy books, and surrounds herself with gentle living beauty.',
    themeExplanation: 'Soft dusty pastels, unbleached cotton paper, delicate dried botanical sprigs, and gentle restorative botanical scents.',
    coverImage: '/images/ketolune_paper_craft.jpg',
    isAvailable: true,
    order: 1,
    availableTiers: ['keepsake', 'thoughtful', 'grand'],
    interests: [
      {
        id: 'pressed-flowers',
        label: 'Pressed Botanicals & Wildflowers',
        description: 'Meadow flora, delicate petals, glass frames, field botanicals.',
        sampleItems: ['Pressed floral glass specimen', 'Lavender wax tablet', 'Handmade petal paper note']
      },
      {
        id: 'tea-rituals',
        label: 'Afternoon Tea & Herbal Infusions',
        description: 'Ceramic cups, chamomile tea at dusk, loose leaf blends, quiet afternoons.',
        sampleItems: ['Ceramic tea resting stone', 'Apothecary floral vial', 'Warm honey wax seal']
      },
      {
        id: 'poetry-prose',
        label: 'Poetry, Gentle Letters & Calligraphy',
        description: 'Rainer Maria Rilke, handwritten envelopes, intimate stationery.',
        sampleItems: ['Calligraphy archival dedication', 'Frayed lilac silk ribbon', 'Deckled parchment']
      }
    ],
    availableItems: [
      {
        id: 'porcelain-dish',
        name: 'Hand-Cast Porcelain Trinket Dish',
        description: 'Delicate porcelain dish with organic undulating rim and unglazed exterior.',
        materials: 'High-fire English porcelain, clear satin glaze interior',
        tierCompatibility: ['thoughtful', 'grand']
      },
      {
        id: 'lavender-herbarium',
        name: 'Apothecary Botanical Specimen Vial',
        description: 'Glass apothecary vial containing wild mountain lavender buds and golden chamomile.',
        materials: 'Borosilicate glass, cork stopper, botanical harvest',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      },
      {
        id: 'botanical-wax-tablet',
        name: 'Wild Rose & Beeswax Scented Tablet',
        description: 'Hanging wax tablet adorned with dried larkspur petals for scenting wardrobes or desks.',
        materials: 'Filtered beeswax, wild rose absolute, linen ribbon',
        tierCompatibility: ['thoughtful', 'grand']
      }
    ]
  },
  {
    id: 'nostalgia-ephemera',
    path: 'girls',
    title: 'The Nostalgia & Pop Ephemera',
    tagline: 'K-pop lyric keepsakes, comfort anime, indie playlists & film photography.',
    description: 'For the creative soul whose heart beats to beloved fandoms, Korean dramas, retro film prints, and heartfelt aesthetic corners.',
    themeExplanation: 'Playful yet sophisticated; merges meaningful pop-culture sentiment with archival packaging, personal polaroids, and soft pastel wax seals.',
    coverImage: '/images/let_surprise_unfold_art.jpg',
    isAvailable: true,
    order: 2,
    availableTiers: ['keepsake', 'thoughtful', 'grand'],
    interests: [
      {
        id: 'kpop-music',
        label: 'K-Pop Fandoms & Lyrical Bridges',
        description: 'Deep album concepts, comforting music lyrics, concert memories, lightstick glow.',
        sampleItems: ['Hand-lettered lyric keepsake', 'Pastel plum wax seal', 'Archival sleeve envelope']
      },
      {
        id: 'comfort-anime',
        label: 'Comfort Anime & Studio Ghibli',
        description: 'Spirited Away coziness, train rides in the rain, warm bakeries, nostalgic summers.',
        sampleItems: ['Ghibli aesthetic artwork card', 'Ceramic morning mug token', 'Hand-tied ribbon parcel']
      },
      {
        id: 'film-photography',
        label: 'Polaroid & Film Camera Memories',
        description: '35mm grain, vintage scrapbooks, captured smiles, tangible physical photos.',
        sampleItems: ['Personal photo keepsake frame', 'Kraft photo sleeve', 'Wax-stamped date card']
      }
    ],
    availableItems: [
      {
        id: 'lyric-card',
        name: 'Hand-Lettered Lyric / Quote Keepsake',
        description: 'Her favorite song bridge or comforting phrase penned in flowing dip-pen calligraphy.',
        materials: 'Heavy textured watercolor paper, gouache ink, wax seal',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      },
      {
        id: 'photo-pouch',
        name: 'Archival Keepsake Photo Sleeve',
        description: 'Handmade cotton rag envelope specifically tailored to house her favorite instant photo.',
        materials: '300gsm cotton rag, Japanese washi string tie',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      },
      {
        id: 'acrylic-memory',
        name: 'Botanical Resin Memory Token',
        description: 'Clear hand-poured casting preserving a delicate sprig of forget-me-not blossoms.',
        materials: 'Eco-resin, dried forget-me-nots, brass ring',
        tierCompatibility: ['thoughtful', 'grand']
      }
    ]
  },
  {
    id: 'sanctuary-stillness',
    path: 'girls',
    title: 'The Sanctuary of Stillness',
    tagline: 'Cozy cashmere warmth, soothing rituals, rain on the roof & soft sanctuary.',
    description: 'For the one who gives so much of herself to the world and deserves a moment of deep, gentle stillness without expectations.',
    themeExplanation: 'Warm comforting aromas, soft tactile textiles, soothing stone cups, and tender reminders that she is worthy of rest.',
    coverImage: '/images/hero_ketolune_box.jpg',
    isAvailable: true,
    order: 3,
    availableTiers: ['keepsake', 'thoughtful', 'grand'],
    interests: [
      {
        id: 'cozy-evenings',
        label: 'Rainy Day Reading & Warm Blankets',
        description: 'Curling up with fiction, woolen socks, quiet evening shadows, candle flicker.',
        sampleItems: ['Alpine lavender candle', 'Velvet ribbon book ribbon', 'Soothing encouragement card']
      },
      {
        id: 'sisterhood-care',
        label: 'Sisterhood & Best Friend Unconditional Love',
        description: 'Unspoken bonds, laughing until crying, holding space during tough transitions.',
        sampleItems: ['Deep gratitude letter', 'Plum wax seal', 'Tactile ceramic palm stone']
      },
      {
        id: 'grounding-scents',
        label: 'Grounding Scents & Calm Spaces',
        description: 'Sandalwood, vanilla bean, dried chamomile, petrichor, tranquil bedrooms.',
        sampleItems: ['Natural beeswax votive', 'Aromatic linen sachet', 'Personal dedication note']
      }
    ],
    availableItems: [
      {
        id: 'ceramic-votive',
        name: 'Handmade Ceramic Candle Vessel',
        description: 'Thrown on the potter\'s wheel, filled with slow-burning soy wax and sweet fig & cypress.',
        materials: 'Speckled stoneware clay, pure soy wax, wooden crackle wick',
        tierCompatibility: ['thoughtful', 'grand']
      },
      {
        id: 'palm-stone',
        name: 'Smooth Ceramic Grounding Palm Stone',
        description: 'Tactile sculpted ceramic stone designed to fit comfortably in the palm of her hand.',
        materials: 'Unglazed smooth terracotta, mineral polish',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      },
      {
        id: 'velvet-bookmark',
        name: 'Silk Velvet Reading Ribbon',
        description: 'Plum-toned frayed silk velvet ribbon bookmark with hand-stamped brass charm.',
        materials: '100% silk velvet, antique brass pendant',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      }
    ]
  },
  {
    id: 'milestone-vault',
    path: 'girls',
    title: 'The Milestone & Keepsake Vault',
    tagline: 'Important birthdays, graduations, golden chapters & timeless gratitude.',
    description: 'For celebratory occasions and life landmarks that deserve more than an ordinary present from a shopping cart.',
    themeExplanation: 'Rich archival presentation box, gilded accents, dried evergreen sprigs, and a comprehensive collection of keepsakes designed to be kept forever.',
    coverImage: '/images/note_the_part_they_keep.jpg',
    isAvailable: true,
    order: 4,
    availableTiers: ['keepsake', 'thoughtful', 'grand'],
    interests: [
      {
        id: 'birthday-milestone',
        label: 'Milestone Birthdays (18th, 21st, 25th, 30th)',
        description: 'Honoring who she has become, memories of growth, celebrating her presence.',
        sampleItems: ['Dedicated archival milestone letter', 'Botanical wax seal', 'Heirloom gift assembly']
      },
      {
        id: 'graduation-newchapter',
        label: 'Graduation & Stepping Into New Chapters',
        description: 'Moving to a new city, landing a dream job, bravely starting over.',
        sampleItems: ['Bravery talisman', 'Hand-stitched linen pouch', 'Letterpress encouragement']
      },
      {
        id: 'long-distance',
        label: 'Long-Distance Friendship & Love',
        description: 'Miles apart but unbroken; a tangible piece of your closeness delivered to her door.',
        sampleItems: ['Coordinates keepsake', 'Archival stationery set', 'Preserved botanical sprig']
      }
    ],
    availableItems: [
      {
        id: 'heirloom-box',
        name: 'Bespoke Handcrafted Presentation Box',
        description: 'Rigid heavyweight archival gift box wrapped in raw unbleached paper with linen ties.',
        materials: '1200gsm archival bookbinding board, unbleached kraft wrap, botanical seal',
        tierCompatibility: ['grand']
      },
      {
        id: 'milestone-letter',
        name: 'Extended Archival Keepsake Letter',
        description: 'Multi-paragraph personal letter transcribed by hand onto deckled cotton stationery.',
        materials: 'Hand-torn 300gsm cotton rag, archival carbon black ink, plum wax stamp',
        tierCompatibility: ['keepsake', 'thoughtful', 'grand']
      },
      {
        id: 'ceramic-vessel',
        name: 'Miniature Stoneware Memory Vessel',
        description: 'Hand-thrown tiny ceramic vessel to hold small treasured memories or matches.',
        materials: 'Stoneware clay, mineral slip finish',
        tierCompatibility: ['thoughtful', 'grand']
      }
    ]
  }
];
