import { User } from 'firebase/auth';
import { db } from './firebase';
import { collection, getDocs, doc, updateDoc } from 'firebase/firestore';

export interface AdminIdentity {
  name: string;
  email: string;
}

// Exactly two approved administrator identity pairs
export const APPROVED_ADMINS: AdminIdentity[] = [
  { name: 'keerthi', email: 'k.toshit1405@gmail.com' },
  { name: 'toshit', email: 'toshitsairathod@gmail.com' },
];

/**
 * Validates whether the authenticated user matches the exact administrator allowlist.
 */
export function isAuthorizedAdmin(user: User | null): boolean {
  if (!user || !user.email) return false;
  const userEmail = user.email.toLowerCase().trim();
  return APPROVED_ADMINS.some(admin => admin.email.toLowerCase().trim() === userEmail);
}

/**
 * Returns matching admin name if authorized
 */
export function getAdminName(user: User | null): string | null {
  if (!user || !user.email) return null;
  const match = APPROVED_ADMINS.find(admin => admin.email.toLowerCase().trim() === user.email?.toLowerCase().trim());
  return match ? match.name : null;
}

export type EnrollmentStatus = 'PENDING_REVIEW' | 'ACCEPTED' | 'REJECTED';

export interface EnrollmentRecord {
  id: string;
  recipientName: string;
  giverName: string;
  giverEmail: string;
  recipientCategory?: 'boys' | 'girls';
  selectedTier: 'mini' | 'medium' | 'large';
  q1: string;
  q2: string;
  q3: string;
  extraNote?: string;
  attachmentUrl?: string;
  status: EnrollmentStatus;
  createdAt: string;
  adminDecisionBy?: string;
  adminDecisionDate?: string;
}

// Local mock initial state if Firestore is empty or offline
const INITIAL_DEMO_ENROLLMENTS: EnrollmentRecord[] = [
  {
    id: 'ENR-8821',
    recipientName: 'Elena Rostova',
    giverName: 'Maya Rostova',
    giverEmail: 'maya.rostova@example.com',
    recipientCategory: 'girls',
    selectedTier: 'medium',
    q1: 'My elder sister who stayed by my side during our coldest winter.',
    q2: 'Reads backward from the last chapter, drinks tea cold, keeps dried lavender in coat pockets.',
    q3: 'That she doesn’t have to solve everything for everyone to be loved.',
    extraNote: 'Allergic to synthetic perfumes; prefer natural pine and lavender.',
    status: 'ACCEPTED',
    createdAt: '2026-10-10T14:32:00Z',
    adminDecisionBy: 'keerthi',
    adminDecisionDate: '2026-10-11T09:15:00Z'
  },
  {
    id: 'ENR-9042',
    recipientName: 'Devansh K.',
    giverName: 'Arjun Mehta',
    giverEmail: 'arjun.m@example.com',
    recipientCategory: 'boys',
    selectedTier: 'large',
    q1: 'My college roommate and creative partner on our indie film project.',
    q2: 'Listens to lo-fi ambient tracks while carving wood blocks late at night.',
    q3: 'That his quiet persistence is deeply inspiring to all of us.',
    extraNote: 'Graduation celebration landmark.',
    status: 'PENDING_REVIEW',
    createdAt: '2026-10-12T11:20:00Z'
  },
  {
    id: 'ENR-9108',
    recipientName: 'Nisha S.',
    giverName: 'Tanya Roy',
    giverEmail: 'tanya.roy@example.com',
    recipientCategory: 'girls',
    selectedTier: 'mini',
    q1: 'My dearest childhood friend now living 3000 miles away.',
    q2: 'Collects postage stamps from vintage letters and loves Studio Ghibli.',
    q3: 'I miss our Sunday walks through the botanical greenhouse.',
    status: 'PENDING_REVIEW',
    createdAt: '2026-10-13T08:45:00Z'
  }
];

export async function fetchAllEnrollments(): Promise<EnrollmentRecord[]> {
  try {
    const snap = await getDocs(collection(db, 'enrollments'));
    if (!snap.empty) {
      const records: EnrollmentRecord[] = [];
      snap.forEach(doc => {
        records.push({ id: doc.id, ...doc.data() } as EnrollmentRecord);
      });
      return records;
    }
  } catch {
    // Silent fallback to local storage
  }
  
  // Return stored local records if available
  const saved = localStorage.getItem('ketolune_enrollments_db');
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch {
      // fallback
    }
  }
  localStorage.setItem('ketolune_enrollments_db', JSON.stringify(INITIAL_DEMO_ENROLLMENTS));
  return INITIAL_DEMO_ENROLLMENTS;
}

export async function updateEnrollmentStatus(
  enrollmentId: string,
  newStatus: EnrollmentStatus,
  adminName: string
): Promise<boolean> {
  const all = await fetchAllEnrollments();
  const updated = all.map(item => {
    if (item.id === enrollmentId) {
      return {
        ...item,
        status: newStatus,
        adminDecisionBy: adminName,
        adminDecisionDate: new Date().toISOString()
      };
    }
    return item;
  });

  localStorage.setItem('ketolune_enrollments_db', JSON.stringify(updated));

  // Also try Firestore
  try {
    const docRef = doc(db, 'enrollments', enrollmentId);
    await updateDoc(docRef, {
      status: newStatus,
      adminDecisionBy: adminName,
      adminDecisionDate: new Date().toISOString()
    });
  } catch {
    // Silent fallback
  }

  return true;
}

export function saveNewEnrollment(record: Omit<EnrollmentRecord, 'id' | 'createdAt' | 'status'>): EnrollmentRecord {
  const newRec: EnrollmentRecord = {
    ...record,
    id: `ENR-${Math.floor(1000 + Math.random() * 9000)}`,
    status: 'PENDING_REVIEW',
    createdAt: new Date().toISOString()
  };

  const stored = localStorage.getItem('ketolune_enrollments_db');
  let current: EnrollmentRecord[] = INITIAL_DEMO_ENROLLMENTS;
  if (stored) {
    try {
      current = JSON.parse(stored);
    } catch {}
  }
  const updated = [newRec, ...current];
  localStorage.setItem('ketolune_enrollments_db', JSON.stringify(updated));
  return newRec;
}
