import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signInAnonymously, 
  signOut as fbSignOut,
  onAuthStateChanged, 
  updateProfile,
  User 
} from 'firebase/auth';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { getFirestore, collection, addDoc, doc, setDoc, getDoc, getDocs } from 'firebase/firestore';

export const firebaseConfig = {
  apiKey: "AIzaSyAHng7rFb6RW8HVAwuLS0pe4lqirf8Hptg",
  authDomain: "ketolune-a155a.firebaseapp.com",
  projectId: "ketolune-a155a",
  storageBucket: "ketolune-a155a.firebasestorage.app",
  messagingSenderId: "475888644414",
  appId: "1:475888644414:web:316927fdc525d1877abc6f",
  measurementId: "G-JFP5727L8F"
};

// Initialize Firebase
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const storage = getStorage(app);
export const db = getFirestore(app);

// The 2 registered client and admin accounts
export interface AuthorizedClient {
  name: string;
  email: string;
  role: string;
}

export interface RegisteredAccount extends AuthorizedClient {
  password: string;
}

export const REGISTERED_ACCOUNTS: RegisteredAccount[] = [
  {
    name: 'keerthi',
    email: 'k.toshit1405@gmail.com',
    password: 'toshit1405',
    role: 'Verified Studio Client & Admin',
  },
  {
    name: 'toshit',
    email: 'toshitsairathod@gmail.com',
    password: 'keerthi1307',
    role: 'Verified Studio Client & Admin',
  },
];

export const AUTHORIZED_CLIENTS: AuthorizedClient[] = REGISTERED_ACCOUNTS.map(({ name, email, role }) => ({
  name,
  email,
  role,
}));

export function isAuthorizedClientEmail(email?: string | null): boolean {
  if (!email) return false;
  const clean = email.toLowerCase().trim();
  return clean === 'k.toshit1405@gmail.com' || clean === 'toshitsairathod@gmail.com';
}

export function getAuthorizedClient(email?: string | null): AuthorizedClient | undefined {
  if (!email) return undefined;
  const clean = email.toLowerCase().trim();
  return AUTHORIZED_CLIENTS.find(c => c.email.toLowerCase().trim() === clean);
}

// Get active client session from localStorage if present
export function getStoredClientSession(): AuthorizedClient | null {
  try {
    const raw = localStorage.getItem('ketolune_client_session');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (isAuthorizedClientEmail(parsed?.email)) {
        return parsed;
      }
    }
  } catch {
    // Ignore JSON errors
  }
  return null;
}

// Credential-based authentication requiring matching Name, Email, and Password
export async function authenticateWithCredentials(nameInput: string, emailInput: string, passwordInput: string) {
  const normName = nameInput.trim().toLowerCase();
  const normEmail = emailInput.trim().toLowerCase();
  const normPassword = passwordInput.trim();

  if (!normName || !normEmail || !normPassword) {
    throw new Error('Please fill in your name, email, and password.');
  }

  // Find matching account
  const match = REGISTERED_ACCOUNTS.find((acc) => {
    const nameMatches = acc.name.toLowerCase() === normName;
    const emailMatches = acc.email.toLowerCase() === normEmail;
    const passMatches = acc.password === normPassword;
    return nameMatches && emailMatches && passMatches;
  });

  if (!match) {
    throw new Error('Invalid credentials. Please verify your registered name, email, and password.');
  }

  // Ensure Firebase Auth session exists
  let currentUser = auth.currentUser;
  if (!currentUser) {
    try {
      const cred = await signInAnonymously(auth);
      currentUser = cred.user;
    } catch {
      // Clean fallback without console clutter
    }
  }

  if (currentUser) {
    try {
      await updateProfile(currentUser, {
        displayName: match.name,
      });
    } catch {
      // Clean fallback without console clutter
    }
  }

  // Persist record to Firebase Firestore
  try {
    await setDoc(doc(db, 'clients', match.email), {
      name: match.name,
      email: match.email,
      role: match.role,
      lastLogin: new Date().toISOString(),
      uid: currentUser?.uid || 'client-uid',
      authMethod: 'credential_auth',
    }, { merge: true });
  } catch {
    // Clean fallback without console clutter
  }

  const clientSession: AuthorizedClient = {
    name: match.name,
    email: match.email,
    role: match.role,
  };

  // Persist sessions
  localStorage.setItem('ketolune_client_session', JSON.stringify(clientSession));
  sessionStorage.setItem('ketolune_admin_session', JSON.stringify({
    name: match.name,
    email: match.email,
    verifiedAt: new Date().toISOString(),
  }));

  window.dispatchEvent(new Event('ketolune_auth_change'));

  return { user: currentUser, client: clientSession };
}

// Google Sign-in with STRICT allowlist enforcement
export async function signInWithGoogle() {
  const provider = new GoogleAuthProvider();
  try {
    const result = await signInWithPopup(auth, provider);
    const user = result.user;

    // Strict validation: ONLY allow the two authorized emails
    if (!isAuthorizedClientEmail(user.email)) {
      await fbSignOut(auth);
      localStorage.removeItem('ketolune_client_session');
      window.dispatchEvent(new Event('ketolune_auth_change'));
      throw new Error(`Access denied for ${user.email}. Only authorized KETOLUNE accounts are permitted.`);
    }

    // Match client profile
    const client = getAuthorizedClient(user.email);
    if (client) {
      localStorage.setItem('ketolune_client_session', JSON.stringify(client));
      try {
        await setDoc(doc(db, 'clients', client.email), {
          name: client.name,
          email: client.email,
          role: client.role,
          lastLogin: new Date().toISOString(),
          uid: user.uid,
          provider: 'google',
        }, { merge: true });
      } catch {
        // Fallback gracefully
      }
    }

    window.dispatchEvent(new Event('ketolune_auth_change'));
    return user;
  } catch (error) {
    throw error;
  }
}

export async function signOutUser() {
  try {
    localStorage.removeItem('ketolune_client_session');
    sessionStorage.removeItem('ketolune_admin_session');
    await fbSignOut(auth);
    window.dispatchEvent(new Event('ketolune_auth_change'));
  } catch {
    // Clean signout
  }
}

export function subscribeToAuth(callback: (user: User | null, client: AuthorizedClient | null) => void) {
  // Listen to Firebase Auth state
  const unsubscribeFb = onAuthStateChanged(auth, (user) => {
    let client = getStoredClientSession();
    if (user && user.email && isAuthorizedClientEmail(user.email)) {
      client = getAuthorizedClient(user.email) || client;
    }
    callback(user, client);
  });

  // Also listen to local session changes
  const handleStorage = () => {
    const client = getStoredClientSession();
    callback(auth.currentUser, client);
  };

  window.addEventListener('ketolune_auth_change', handleStorage);
  window.addEventListener('storage', handleStorage);

  return () => {
    unsubscribeFb();
    window.removeEventListener('ketolune_auth_change', handleStorage);
    window.removeEventListener('storage', handleStorage);
  };
}

// Storage Helpers: Upload keepsake photo or letter attachment for parcel
export async function uploadKeepsakeAsset(file: File, path: string = 'keepsakes'): Promise<string> {
  try {
    const fileRef = ref(storage, `${path}/${Date.now()}_${file.name}`);
    const snapshot = await uploadBytes(fileRef, file);
    const downloadURL = await getDownloadURL(snapshot.ref);
    return downloadURL;
  } catch {
    // Return object URL as fallback for preview
    return URL.createObjectURL(file);
  }
}

// Firestore Helpers: Save gift reservation
export async function saveReservation(reservationData: Record<string, any>) {
  try {
    const docRef = await addDoc(collection(db, 'reservations'), {
      ...reservationData,
      createdAt: new Date().toISOString(),
    });
    return docRef.id;
  } catch {
    return `RES-${Date.now()}`;
  }
}
