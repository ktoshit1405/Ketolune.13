import { GoogleGenAI } from '@google/genai';

const GEMINI_API_KEY = (import.meta as any).env?.VITE_GEMINI_API_KEY || 'AQ.Ab8RN6JOhh7dc_Yi4_Vik63NR7NrnCd5jUBaa02hldOPyI4ApQ';

let aiInstance: GoogleGenAI | null = null;

try {
  if (GEMINI_API_KEY) {
    aiInstance = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
  }
} catch {
  // Silent fallback
}

export interface CurationInsight {
  giftEssence: string;
  recommendedTone: string;
  suggestedNoteSnippet: string;
}

/**
 * Generate a soulful, bespoke keepsake note suggestion based on the giver's 3 answers.
 */
export async function generateKeepsakeNoteSuggestion(params: {
  recipientName: string;
  relation: string;
  habits: string;
  uniqueTrait: string;
}): Promise<string> {
  const { recipientName, relation, habits, uniqueTrait } = params;

  if (!aiInstance) {
    return `For ${recipientName}. To the one who brings a quiet grace to every ordinary day. May this small parcel remind you how deeply your presence is felt and cherished.`;
  }

  const prompt = `You are the master artisan calligrapher at KETOLUNE, an artisanal slow-craft luxury gifting studio ("Made slowly. Meant personally.").
Write an intimate, poetic, non-cliché 2-3 sentence handwritten keepsake note to accompany a surprise gift parcel.
Recipient name: ${recipientName}
Their relationship to giver: ${relation}
Their quiet habit / what they are like: ${habits}
What makes them uniquely them: ${uniqueTrait}

Rules:
- Deeply personal, tender, tactile, and grounded.
- Absolutely NO generic greeting card clichés, no corporate cheerfulness, no cheesy hashtags, no exclamation marks.
- Return ONLY the final note text, suitable to be inscribed on archival paper with dip pen.`;

  try {
    const response = await aiInstance.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text?.trim() || `To ${recipientName}. For the quiet rituals and the unsaid truths. May this small weight bring your evenings stillness.`;
  } catch {
    return `To ${recipientName}. To the quiet ways you hold the world together without ever asking for praise. May this handcrafted piece remind you of how deeply you are loved.`;
  }
}
