import { useState, useEffect, lazy, Suspense } from 'react';
import { Routes, Route, useNavigate, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

// Global & Shared
import Navbar from './components/Navbar';
import CartDrawer, { CartItem } from './components/CartDrawer';
import CheckoutModal from './components/CheckoutModal';
import AuthModal from './components/AuthModal';

// Landing Page Components
import Hero from './components/Hero';
import TheIdea from './components/TheIdea';
import MadeSlowly from './components/MadeSlowly';
import StudioIngredients from './components/StudioIngredients';
import HowItWorks from './components/HowItWorks';
import TheBatch from './components/TheBatch';
import FeaturedGiftCapsule from './components/FeaturedGiftCapsule';
import TheNote from './components/TheNote';
import ProductWorld from './components/ProductWorld';
import TheQuestions from './components/TheQuestions';
import TheWait from './components/TheWait';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';

// Dedicated Route Pages (Code-split with dynamic imports)
const CollectionsPage = lazy(() => import('./pages/CollectionsPage'));
const EnrollPage = lazy(() => import('./pages/EnrollPage'));
const ReservePage = lazy(() => import('./pages/ReservePage'));
const AccountPage = lazy(() => import('./pages/AccountPage'));
const OrdersPage = lazy(() => import('./pages/OrdersPage'));
const AdminLoginPage = lazy(() => import('./pages/AdminLoginPage'));
const AdminDashboardPage = lazy(() => import('./pages/AdminDashboardPage'));

import { CURRENT_BATCH, BatchTier, SAMPLE_ORDERS } from './data/batchData';

export default function App() {
  const navigate = useNavigate();

  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [appreciationAmount, setAppreciationAmount] = useState(0);

  // Cart state: Initialized empty for visitors (no fake items), persisted within active session
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const stored = sessionStorage.getItem('ketolune_cart_items');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      sessionStorage.setItem('ketolune_cart_items', JSON.stringify(cartItems));
    } catch {
      // ignore
    }
  }, [cartItems]);

  const handleAddToCart = (config: {
    tier: BatchTier;
    aroma: string;
    ceramicFinish: string;
    ribbonColor: string;
    waxSealColor: string;
    noteText: string;
  }) => {
    const newItem: CartItem = {
      id: `cart-${Date.now()}`,
      tier: config.tier,
      aroma: config.aroma,
      ceramicFinish: config.ceramicFinish,
      ribbonColor: config.ribbonColor,
      waxSealColor: config.waxSealColor,
      noteText: config.noteText,
      recipientName: 'Recipient',
    };
    setCartItems([newItem]);
    setCartOpen(true);
  };

  const handleRemoveItem = (id: string) => {
    setCartItems(cartItems.filter((item) => item.id !== id));
  };

  const handleToggleAppreciation = () => {
    setAppreciationAmount((prev) => (prev > 0 ? 0 : 50));
  };

  const handleProceedToCheckout = () => {
    setCartOpen(false);
    setCheckoutOpen(true);
  };

  const handleOrderSuccess = (orderId: string) => {
    setCheckoutOpen(false);
    navigate(`/orders?orderId=${orderId}`);
  };

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    el?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#F7EFDF] text-[#242322] flex flex-col font-sans selection:bg-[#E8F36B] selection:text-[#242322]">
      {/* Floating Top Navbar */}
      <Navbar
        onOpenEnrollment={() => navigate('/enroll')}
        onOpenCart={() => setCartOpen(true)}
        onOpenTracking={() => navigate('/orders')}
        onOpenAuth={() => setAuthOpen(true)}
        onNavigateSection={scrollToSection}
        cartCount={cartItems.length}
      />

      {/* Main View Router */}
      <main className="flex-1">
        <Suspense fallback={
          <div className="min-h-[60vh] bg-[#F7EFDF] flex items-center justify-center font-mono text-xs uppercase tracking-widest text-[#A97849]">
            Loading atelier...
          </div>
        }>
          <Routes>
            {/* Landing Page */}
            <Route
              path="/"
              element={
                <HomeLandingView
                  onOpenEnrollment={() => navigate('/enroll')}
                  onSelectTier={(tier) => navigate(`/collections?tier=${tier.id}`)}
                  scrollToSection={scrollToSection}
                />
              }
            />

            {/* Curated Collection Discovery */}
            <Route path="/collections" element={<CollectionsPage />} />

            {/* Client Enrollment */}
            <Route path="/enroll" element={<EnrollPage />} />

            {/* Reservation & Payment */}
            <Route path="/reserve" element={<ReservePage />} />

            {/* Client Account & Status */}
            <Route path="/account" element={<AccountPage />} />

            {/* Order Status & Tracking */}
            <Route path="/orders" element={<OrdersPage />} />

            {/* Admin Login */}
            <Route path="/admin/login" element={<AdminLoginPage />} />

            {/* Protected Admin Dashboard */}
            <Route path="/admin" element={<AdminDashboardPage />} />

            {/* Catch-all */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
      </main>

      {/* Interactive Global Drawers & Modals */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        appreciationAmount={appreciationAmount}
        onToggleAppreciation={handleToggleAppreciation}
        onRemoveItem={handleRemoveItem}
        onProceedToCheckout={handleProceedToCheckout}
      />

      <CheckoutModal
        isOpen={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        items={cartItems}
        appreciationAmount={appreciationAmount}
        onOrderSuccess={handleOrderSuccess}
      />

      <AuthModal
        isOpen={authOpen}
        onClose={() => setAuthOpen(false)}
      />
    </div>
  );
}

interface HomeLandingViewProps {
  onOpenEnrollment: () => void;
  onSelectTier: (tier: BatchTier) => void;
  scrollToSection: (sectionId: string) => void;
}

function HomeLandingView({ onOpenEnrollment, onSelectTier, scrollToSection }: HomeLandingViewProps) {
  const navigate = useNavigate();

  return (
    <>
      {/* Scene 1: Hero Campaign Artwork & Sky Atmosphere */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
      >
        <Hero
          onOpenEnrollment={onOpenEnrollment}
          onScrollToManifesto={() => scrollToSection('idea')}
          onScrollToHowItWorks={() => scrollToSection('how-it-works')}
        />
      </motion.div>

      {/* Scene 2: The Idea (Conversational Manifesto) */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
      >
        <TheIdea onOpenEnrollment={onOpenEnrollment} />
      </motion.div>

      {/* Scene 3: Our Craft (Interactive Stacked Color Cards) */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
      >
        <MadeSlowly />
      </motion.div>

      {/* Scene 4: Studio Ingredients (Infinite Marquee & Organic Photo Cutout) */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
      >
        <StudioIngredients />
      </motion.div>

      {/* Scene 5: How It Works (Our Process - 3 Distinct Steps) */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
      >
        <HowItWorks onOpenEnrollment={onOpenEnrollment} />
      </motion.div>

      {/* Scene 6: Why KETOLUNE & Allotment Metrics */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
      >
        <TheBatch onOpenEnrollment={onOpenEnrollment} />
      </motion.div>

      {/* Scene 7: Featured Gift Capsule (Tactile Inspection) */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.12 }}
        transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
      >
        <FeaturedGiftCapsule />
      </motion.div>

      {/* Scene 8: Curations & Tier Allocations (Product World) */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
      >
        <ProductWorld
          onSelectTier={onSelectTier}
          onOpenEnrollment={onOpenEnrollment}
        />
      </motion.div>

      {/* Scene 9: The Note Detail */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
      >
        <TheNote />
      </motion.div>

      {/* Scene 10: The Three Nuanced Questions */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
      >
        <TheQuestions onStartQuestion={() => navigate('/enroll')} />
      </motion.div>

      {/* Scene 11: Production Lifecycle Window */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
      >
        <TheWait />
      </motion.div>

      {/* Scene 12: Final Call to Action */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
      >
        <FinalCTA onOpenEnrollment={onOpenEnrollment} />
      </motion.div>

      {/* Scene 13: Signature Fanning Cards Footer */}
      <motion.div
        initial={{ opacity: 0, y: 35 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      >
        <Footer
          onOpenEnrollment={onOpenEnrollment}
          onOpenTracking={() => navigate('/orders')}
          onNavigateSection={scrollToSection}
        />
      </motion.div>
    </>
  );
}
