export default function StudioIngredients() {
  const pills = [
    { text: "Zero Warehouse Stock", bg: "bg-[#242322]", textCol: "text-white" },
    { text: "Made Slowly", bg: "bg-[#e8f36b]", textCol: "text-[#242322] font-bold" },
    { text: "Meant Personally", bg: "bg-[#FF7738]", textCol: "text-white" },
    { text: "Pure Filtered Beeswax", bg: "bg-[#F7EFDF]", textCol: "text-[#242322] font-bold border border-[#242322]/20" },
    { text: "Wild Basalt Stoneware", bg: "bg-[#242322]", textCol: "text-[#F7EFDF]" },
    { text: "300gsm Cotton Rag", bg: "bg-[#51C99A]", textCol: "text-[#242322] font-bold" },
    { text: "7–8 Day Making Window", bg: "bg-[#DDA6F0]", textCol: "text-[#242322] font-bold" },
    { text: "Plant-Dyed Frayed Silk", bg: "bg-[#EFC9D0]", textCol: "text-[#242322] font-bold" },
    { text: "No Two Identical", bg: "bg-[#A97849]", textCol: "text-white" },
    { text: "Pressed Botanical Wax Seal", bg: "bg-[#242322]", textCol: "text-[#F7EFDF]" }
  ];

  return (
    <section id="ingredients" className="py-24 px-6 bg-[#F7EFDF] text-[#242322] overflow-hidden select-none border-t border-[#242322]/10">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Title */}
        <div className="text-center space-y-2">
          <h2 className="text-5xl sm:text-7xl md:text-8xl font-black uppercase tracking-tight text-[#242322] font-condensed">
            STUDIO INGREDIENTS
          </h2>
          <p className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
            The DNA Inside Every Surprise
          </p>
        </div>

        {/* Central Organic Cutout Image (Pure - NO text or butterflies overlaid) */}
        <div className="relative max-w-xl mx-auto flex flex-col items-center justify-center space-y-3">
          {/* Organic Rounded Oval Cutout Container */}
          <div className="w-full aspect-[16/10] rounded-[3rem] overflow-hidden border-2 border-[#242322]/20 shadow-xl bg-[#EDE8DF]">
            <img
              src="/images/craft_made_slowly.jpg"
              alt="Makers at the workbench"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/src/assets/images/craft_made_slowly_1791401666377.jpg';
              }}
            />
          </div>
          {/* Caption cleanly below image */}
          <div className="text-xs font-mono text-[#242322]/60 uppercase tracking-wider">
            Hands-on studio formulation & slow crafting
          </div>
        </div>

        {/* Infinite Drifting Pill Marquee Ticker */}
        <div className="relative w-full overflow-hidden py-4">
          <div className="flex gap-3 w-max animate-marquee hover:[animation-play-state:paused]">
            {[...pills, ...pills, ...pills].map((p, idx) => (
              <span
                key={idx}
                className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-sans font-bold shadow-sm uppercase tracking-wider whitespace-nowrap cursor-default transition-transform hover:scale-105 ${p.bg} ${p.textCol}`}
              >
                {p.text}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
