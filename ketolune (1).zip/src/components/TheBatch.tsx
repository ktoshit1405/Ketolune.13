interface TheBatchProps {
  onOpenEnrollment?: () => void;
}

export default function TheBatch({ onOpenEnrollment }: TheBatchProps = {}) {
  const cards = [
    {
      num: "01",
      tag: "HUMAN ATTENTION",
      title: "Human Effort",
      desc: "We believe in human attention over factory shortcuts. Each gift is individually considered, curated, and lettered by hand."
    },
    {
      num: "02",
      tag: "INTENTIONAL SCALE",
      title: "Dedicated Allocation",
      desc: "Every release is thoughtfully limited to protect our focus. No mass warehousing, no compromise on personal care."
    },
    {
      num: "03",
      tag: "AUTHENTIC FIT",
      title: "Authentic & Personal",
      desc: "Shaped around their quiet habits, genuine quirks, and unsaid sentiments, not generic gift-catalog questionnaires."
    },
    {
      num: "04",
      tag: "HEIRLOOM PIECE",
      title: "Tactile & Keepsake",
      desc: "From quiet observation to a physical unboxing. Designed to be kept on their desk or nightstand for years to come."
    }
  ];

  return (
    <section id="batch" className="pt-24 bg-white text-slate-900 select-none border-t border-slate-100">
      <div className="max-w-6xl mx-auto px-6 space-y-16">
        {/* Title */}
        <div className="text-center space-y-2">
          <h2 className="text-5xl sm:text-7xl md:text-8xl font-black uppercase tracking-tight text-slate-950 font-condensed">
            WHY KETOLUNE?
          </h2>
          <p className="text-xs font-mono uppercase tracking-widest text-[#7B5CA8] font-bold">
            The Standards We Stand By
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {cards.map((c) => (
            <div
              key={c.num}
              className="p-8 sm:p-10 rounded-[2.5rem] bg-[#FAF8F5] border border-slate-900/10 shadow-sm flex flex-col justify-between space-y-8 hover:bg-white hover:border-[#7B5CA8]/30 hover:shadow-xl transition-all duration-300"
            >
              <div className="flex justify-between items-start">
                <span className="px-3.5 py-1 bg-[#242322] text-[#F7EFDF] rounded-full text-xs font-mono font-bold tracking-wider">
                  {c.tag}
                </span>
                <span className="text-xs font-mono font-bold text-[#A97849]">
                  {c.num}
                </span>
              </div>

              <div className="space-y-3">
                <h3 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#242322] font-condensed uppercase">
                  {c.title}
                </h3>
                <p className="text-sm font-sans text-[#242322]/75 leading-relaxed">
                  {c.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Atmospheric Lavender Background with Perfect Harmonious Palette for the 3 Blocks (Corrected Screenshot 1) */}
      <div className="mt-20">
        <div className="w-full bg-[#EBE4F7] border-t border-[#D8CEEE] pt-14 pb-24">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Box 1: Mint Sage */}
              <div className="p-8 sm:p-10 rounded-[2.5rem] bg-[#D7EFE2] border border-[#A7D7BC] shadow-lg text-center flex flex-col justify-center space-y-3">
                <h3 className="text-3xl sm:text-4xl font-black text-[#193B2B] tracking-tight font-condensed uppercase leading-none">
                  NOT PICKED.<br />NOT PACKED.
                </h3>
                <p className="text-xs sm:text-sm font-sans font-medium text-[#193B2B]/80 leading-relaxed">
                  Made for them. Personalized mystery gifting shaped around one person.
                </p>
              </div>

              {/* Box 2: Warm Terracotta Orange (Screenshot 1A: Orange Timeline Block) */}
              <div className="p-8 sm:p-10 rounded-[2.5rem] bg-[#FCE8DC] border border-[#F3BBA0] shadow-lg text-center flex flex-col justify-center space-y-3 text-[#64290B]">
                <h3 className="text-3xl sm:text-4xl font-black tracking-tight font-condensed uppercase leading-none">
                  A LITTLE TIME.<br />A LOT OF MEANING.
                </h3>
                <p className="text-xs sm:text-sm font-sans font-medium text-[#64290B]/85 leading-relaxed">
                  Your surprise takes shape after booking. Good things deserve a little thought.
                </p>
              </div>

              {/* Box 3: Lavender Wisteria (Screenshot 1B: Purple Price Removed) */}
              <div className="p-8 sm:p-10 rounded-[2.5rem] bg-[#E5D7FA] border border-[#C5AFF0] shadow-lg text-center flex flex-col justify-center space-y-3 text-[#391963]">
                <h3 className="text-3xl sm:text-4xl font-black tracking-tight font-condensed uppercase leading-none">
                  MADE FOR THEIR<br />KIND OF PERSON.
                </h3>
                <p className="text-xs sm:text-sm font-sans font-medium text-[#391963]/85 leading-relaxed">
                  Tell us a little about them. Let the surprise take it from there.
                </p>
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
