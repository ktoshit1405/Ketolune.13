import { useState } from 'react';
import { ArrowRight, HelpCircle } from 'lucide-react';

interface TheQuestionsProps {
  onStartQuestion: (index: number) => void;
}

export default function TheQuestions({ onStartQuestion }: TheQuestionsProps) {
  const [activeQuestion, setActiveQuestion] = useState(0);

  const questions = [
    {
      num: "01 / 03",
      title: "Who are they to you?",
      subtext: "The relation, the quiet bond, the invisible history.",
      example: "“My sister Maya. She took care of me when our apartment flooded and never let anyone see her cry.”",
      studioTranslation: "Directs the gift's mood, scale, and tactile packaging orientation."
    },
    {
      num: "02 / 03",
      title: "What are they like when nobody is watching?",
      subtext: "Their quietest habits, private rituals, and sensory memories.",
      example: "“She leaves cold tea bags on the saucer, reads books backwards, and keeps train stubs in her winter coat.”",
      studioTranslation: "Guides sensory curation: selecting aromas and tactile companion elements that resonate with their quiet world."
    },
    {
      num: "03 / 03",
      title: "What’s one thing that is very “them”?",
      subtext: "The sentiment or feeling you wish you could say without clumsiness.",
      example: "“That they don't have to carry the whole world on their shoulders anymore.”",
      studioTranslation: "Shapes the hand-lettered archival keepsake note and personalized wax seal impression."
    }
  ];

  return (
    <section id="questions" className="py-24 sm:py-32 px-6 bg-[#EDE8DF] text-[#242322] border-t border-[#242322]/10 select-none">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Provocative Statement in Warm Aesthetic */}
          <div className="lg:col-span-5 space-y-6">
            <div className="text-xs font-mono uppercase tracking-[0.2em] text-[#A97849] font-bold flex items-center gap-2">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Three Intimate Questions</span>
            </div>

            <h2 className="text-4xl sm:text-5xl md:text-6xl font-condensed uppercase tracking-tight text-[#242322] leading-[0.95]">
              TELL US<br />
              <span className="text-[#A97849] italic font-serif">ABOUT THEM.</span>
            </h2>

            <p className="text-sm sm:text-base text-[#242322]/80 leading-relaxed font-sans">
              Three questions. No giant questionnaire. We don't ask for shoe sizes or generic gift-registry filters. We listen for human nuance.
            </p>

            {/* Interactive Step Switcher */}
            <div className="space-y-2 pt-2">
              {questions.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveQuestion(idx)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all text-xs font-mono flex items-center justify-between cursor-pointer ${
                    activeQuestion === idx
                      ? 'border-[#A97849] bg-white text-[#242322] shadow-sm font-bold'
                      : 'border-[#242322]/15 bg-transparent text-[#242322]/60 hover:text-[#242322] hover:bg-white/40'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-[#A97849]">{q.num}</span>
                    <span className="truncate max-w-[220px]">{q.title}</span>
                  </div>
                  <span className="text-[#A97849]">{activeQuestion === idx ? '●' : '○'}</span>
                </button>
              ))}
            </div>

            <div className="pt-2">
              <button
                onClick={() => onStartQuestion(activeQuestion)}
                className="px-6 py-3.5 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] text-xs font-bold tracking-wider uppercase transition-colors inline-flex items-center gap-2 rounded-full cursor-pointer shadow-md"
              >
                <span>Answer Question {activeQuestion + 1} Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Right Column: Tactile Question Preview Paper Sheet */}
          <div className="lg:col-span-7">
            <div className="p-8 sm:p-12 bg-[#F7EFDF] text-[#242322] rounded-3xl shadow-xl border border-[#242322]/10 space-y-6">
              <div className="flex justify-between items-center text-xs font-mono pb-4 border-b border-[#242322]/10 text-[#A97849]">
                <span className="font-bold tracking-widest">{questions[activeQuestion].num}</span>
                <span>KETOLUNE STUDIO PROMPT</span>
              </div>

              <div>
                <h3 className="text-3xl sm:text-4xl font-serif italic text-[#242322] leading-tight">
                  "{questions[activeQuestion].title}"
                </h3>
                <p className="text-xs font-mono text-[#242322]/60 mt-2">
                  {questions[activeQuestion].subtext}
                </p>
              </div>

              {/* Sample Answer from a Giver */}
              <div className="p-5 bg-white/80 rounded-2xl border-l-4 border-[#A97849] space-y-1">
                <div className="text-[10px] font-mono uppercase text-[#A97849] font-bold">
                  Example Giver Observation
                </div>
                <p className="text-sm font-serif italic text-[#242322] leading-relaxed">
                  {questions[activeQuestion].example}
                </p>
              </div>

              {/* Studio Translation */}
              <div className="pt-2 text-xs font-mono text-[#242322]/70 flex items-start gap-2">
                <span className="text-[#A97849] font-bold shrink-0">STUDIO ACTION:</span>
                <span>{questions[activeQuestion].studioTranslation}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
