import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ShoppingBag, Menu, X, ArrowDownRight, User as UserIcon, Shield } from 'lucide-react';
import { subscribeToAuth, AuthorizedClient } from '../services/firebase';

interface NavbarProps {
  onOpenEnrollment: () => void;
  onOpenCart: () => void;
  onOpenTracking?: () => void;
  onOpenAuth?: () => void;
  onNavigateSection?: (sectionId: string) => void;
  cartCount: number;
}

export default function Navbar({
  onOpenEnrollment,
  onOpenCart,
  onOpenTracking,
  onOpenAuth,
  onNavigateSection,
  cartCount,
}: NavbarProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [client, setClient] = useState<AuthorizedClient | null>(null);

  useEffect(() => {
    const unsub = subscribeToAuth((_user, activeClient) => {
      setClient(activeClient);
    });
    return () => unsub();
  }, []);

  const handleNavClick = (sectionId: string) => {
    if (location.pathname !== '/') {
      navigate(`/#${sectionId}`);
    } else if (onNavigateSection) {
      onNavigateSection(sectionId);
    } else {
      const el = document.getElementById(sectionId);
      el?.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* Editorial Floating Header Bar */}
      <header className="fixed top-4 left-0 right-0 z-50 flex justify-center px-4 pointer-events-none select-none">
        <div className="pointer-events-auto flex items-center justify-between w-full max-w-5xl bg-[#F7EFDF]/95 backdrop-blur-md px-4 sm:px-6 py-2.5 rounded-full border border-[#242322]/10 shadow-lg shadow-[#242322]/5">
          {/* Brand Wordmark & Handcrafted Tag */}
          <button
            onClick={() => {
              navigate('/');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-2 group cursor-pointer"
          >
            <span className="font-condensed text-2xl sm:text-3xl tracking-tight text-[#242322] font-bold">
              KETOLUNE
            </span>
            <span className="hidden sm:inline-block font-script text-base text-[#A97849] -rotate-3 transition-transform group-hover:rotate-0">
              studio
            </span>
          </button>

          {/* Editorial Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-xs uppercase tracking-widest font-semibold text-[#242322]/80">
            <button
              onClick={() => handleNavClick('idea')}
              className="hover:text-[#242322] transition-colors cursor-pointer"
            >
              The Idea
            </button>
            <button
              onClick={() => handleNavClick('how-it-works')}
              className="hover:text-[#242322] transition-colors cursor-pointer"
            >
              How It Works
            </button>
            <button
              onClick={() => navigate('/collections')}
              className={`hover:text-[#242322] transition-colors cursor-pointer ${
                location.pathname === '/collections' ? 'text-[#242322] font-bold underline' : ''
              }`}
            >
              Collections
            </button>
            <button
              onClick={() => navigate('/enroll')}
              className={`hover:text-[#242322] transition-colors cursor-pointer ${
                location.pathname === '/enroll' ? 'text-[#242322] font-bold underline' : ''
              }`}
            >
              Enrollment
            </button>
            <button
              onClick={() => navigate('/account')}
              className={`hover:text-[#242322] transition-colors cursor-pointer ${
                location.pathname === '/account' ? 'text-[#242322] font-bold underline' : ''
              }`}
            >
              Status
            </button>
            <button
              onClick={() => navigate('/orders')}
              className={`text-[#A97849] hover:text-[#242322] transition-colors cursor-pointer ${
                location.pathname === '/orders' ? 'font-bold underline' : ''
              }`}
            >
              Tracking
            </button>
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2.5">
            {/* Curator Admin link */}
            <button
              onClick={() => navigate('/admin')}
              title="Curator Admin Access"
              className="hidden lg:flex p-2 text-[#242322]/60 hover:text-[#242322] hover:bg-black/5 rounded-full transition-colors cursor-pointer"
            >
              <Shield className="w-4 h-4 text-[#A97849]" />
            </button>

            {/* Account / Auth Button */}
            {onOpenAuth && (
              <button
                onClick={onOpenAuth}
                aria-label="Account / Sign in"
                className={`flex items-center gap-1.5 p-2 rounded-full transition-colors cursor-pointer ${
                  client 
                    ? 'px-3 py-1 bg-white/90 border border-[#242322]/15 text-[#242322] hover:border-[#A97849]' 
                    : 'text-[#242322] hover:text-[#A97849] hover:bg-black/5'
                }`}
                title={client ? `Logged in: ${client.name} (${client.email})` : "Account / Client Access"}
              >
                {client ? (
                  <>
                    <span className="w-2 h-2 rounded-full bg-[#394D92]" />
                    <span className="capitalize font-mono text-xs font-bold">{client.name}</span>
                  </>
                ) : (
                  <UserIcon className="w-4 h-4" />
                )}
              </button>
            )}

            {/* Bag Button */}
            <button
              onClick={onOpenCart}
              aria-label="Open Cart Bag"
              className="relative p-2 text-[#242322] hover:text-[#242322] hover:bg-black/5 rounded-full transition-colors cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-[#242322] text-[#F7EFDF] text-[10px] font-bold flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Reserve CTA */}
            <button
              onClick={() => navigate('/enroll')}
              className="px-4 sm:px-5 py-2 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-sm"
            >
              Enroll Now
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-[#242322] rounded-full"
              aria-label="Toggle navigation"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-x-4 top-20 z-50 bg-[#F7EFDF] border border-[#242322]/15 rounded-3xl p-6 shadow-2xl space-y-4 md:hidden animate-fade-in text-[#242322]">
          <nav className="flex flex-col gap-3 text-sm font-semibold uppercase tracking-wider">
            <button
              onClick={() => handleNavClick('idea')}
              className="text-left py-2 border-b border-[#242322]/10"
            >
              The Idea
            </button>
            <button
              onClick={() => handleNavClick('how-it-works')}
              className="text-left py-2 border-b border-[#242322]/10"
            >
              How It Works
            </button>
            <button
              onClick={() => {
                navigate('/collections');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 border-b border-[#242322]/10"
            >
              Collections (Boys & Girls)
            </button>
            <button
              onClick={() => {
                navigate('/enroll');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 border-b border-[#242322]/10"
            >
              Client Enrollment
            </button>
            <button
              onClick={() => {
                navigate('/account');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 border-b border-[#242322]/10"
            >
              Check Enrollment Status
            </button>
            <button
              onClick={() => {
                navigate('/orders');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 text-[#A97849]"
            >
              Production Tracking
            </button>
            <button
              onClick={() => {
                navigate('/admin');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 text-xs font-mono text-[#242322]/60"
            >
              Curator Admin Dashboard
            </button>
          </nav>

          <button
            onClick={() => {
              navigate('/enroll');
              setMobileMenuOpen(false);
            }}
            className="w-full py-3 bg-[#242322] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider text-center"
          >
            Enroll a Recipient
          </button>
        </div>
      )}

      {/* Sticky Bottom-Right Floating Action Pill */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => navigate('/enroll')}
          className="px-5 py-3 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider shadow-2xl flex items-center gap-2 transition-all duration-300 hover:scale-105 border border-[#F7EFDF]/20 cursor-pointer"
          aria-label="Floating Reserve Gift Action"
        >
          <span>Enroll a Gift</span>
          <ArrowDownRight className="w-3.5 h-3.5 text-[#E8F36B]" />
        </button>
      </div>
    </>
  );
}
