import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  X, 
  LogIn, 
  LogOut, 
  CheckCircle2, 
  ShieldCheck, 
  AlertTriangle,
  ArrowRight,
  ExternalLink,
  Lock,
  Eye,
  EyeOff,
  User as UserIcon,
  Mail,
  KeyRound
} from 'lucide-react';
import { 
  AuthorizedClient, 
  authenticateWithCredentials, 
  signInWithGoogle, 
  signOutUser, 
  subscribeToAuth 
} from '../services/firebase';
import { User } from 'firebase/auth';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AuthModal({ isOpen, onClose }: AuthModalProps) {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeClient, setActiveClient] = useState<AuthorizedClient | null>(null);

  // Form input fields
  const [nameInput, setNameInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToAuth((user, client) => {
      setCurrentUser(user);
      setActiveClient(client);
    });
    return () => unsubscribe();
  }, []);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    setIsSubmitting(true);

    try {
      const res = await authenticateWithCredentials(nameInput, emailInput, passwordInput);
      setActiveClient(res.client);
      setFeedback({
        type: 'success',
        text: `Authentication successful. Welcome, ${res.client.name}!`
      });
      // Clear sensitive inputs
      setPasswordInput('');
      setTimeout(() => {
        onClose();
      }, 900);
    } catch (err: any) {
      setFeedback({
        type: 'error',
        text: err.message || 'Invalid credentials. Please verify your name, email, and password.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    setFeedback(null);
    try {
      const user = await signInWithGoogle();
      setFeedback({
        type: 'success',
        text: `Google verification complete for ${user.email}.`
      });
      setTimeout(() => {
        onClose();
      }, 900);
    } catch (err: any) {
      setFeedback({
        type: 'error',
        text: err.message || 'Google authentication failed. Please enter your name, email, and password above.'
      });
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleSignOut = async () => {
    await signOutUser();
    setActiveClient(null);
    setNameInput('');
    setEmailInput('');
    setPasswordInput('');
    setFeedback({
      type: 'success',
      text: 'Signed out successfully.'
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242322]/80 backdrop-blur-md select-none animate-fade-in">
      <div className="relative w-full max-w-md bg-[#F7EFDF] border border-[#242322]/15 p-6 sm:p-8 rounded-3xl shadow-2xl text-[#242322]">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[#242322]/60 hover:text-[#242322] rounded-full transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center space-y-2 mb-6">
          <div className="w-12 h-12 rounded-full bg-[#FAF7F2] border border-[#A97849]/30 flex items-center justify-center mx-auto text-[#A97849] shadow-sm">
            {activeClient ? <ShieldCheck className="w-6 h-6" /> : <Lock className="w-5 h-5" />}
          </div>
          <h3 className="font-condensed text-3xl sm:text-4xl uppercase tracking-tight text-[#242322] font-bold">
            {activeClient ? 'CLIENT SESSION ACTIVE' : 'CLIENT ACCESS'}
          </h3>
          <p className="text-xs font-mono text-[#242322]/70 max-w-xs mx-auto">
            {activeClient 
              ? `Signed in as ${activeClient.name} (${activeClient.email})` 
              : 'Enter your name, email, and designated access password to sign in.'}
          </p>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div className={`mb-5 p-3.5 rounded-2xl text-xs font-mono flex items-start gap-2.5 ${
            feedback.type === 'success' 
              ? 'bg-[#E8F36B]/25 border border-[#242322]/20 text-[#242322]' 
              : 'bg-red-50 border border-red-200 text-red-800'
          }`}>
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-[#242322] shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            )}
            <span className="leading-relaxed">{feedback.text}</span>
          </div>
        )}

        {/* Active Session View */}
        {activeClient ? (
          <div className="space-y-4">
            <div className="p-5 bg-white/95 rounded-2xl border border-[#242322]/15 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-[#242322]/10 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full bg-[#242322] text-[#F7EFDF] font-bold text-sm flex items-center justify-center uppercase">
                    {activeClient.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold capitalize text-[#242322] leading-tight">
                      {activeClient.name}
                    </h4>
                    <span className="text-[11px] font-mono text-[#242322]/60">
                      {activeClient.email}
                    </span>
                  </div>
                </div>
                <span className="px-2.5 py-1 bg-[#E8F36B] text-[#242322] text-[10px] font-mono font-bold uppercase rounded-full">
                  Authorized
                </span>
              </div>

              <div className="text-xs text-[#242322]/75 font-sans leading-relaxed">
                You have active access to your curated gift reservations, tracking, and studio portal.
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={() => {
                  onClose();
                  navigate('/account');
                }}
                className="p-3 bg-white hover:bg-[#FAF7F2] border border-[#242322]/15 rounded-xl text-xs font-mono font-bold uppercase tracking-wider text-[#242322] transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
              >
                <span>My Portal</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#A97849]" />
              </button>

              <button
                onClick={() => {
                  onClose();
                  navigate('/admin');
                }}
                className="p-3 bg-white hover:bg-[#FAF7F2] border border-[#242322]/15 rounded-xl text-xs font-mono font-bold uppercase tracking-wider text-[#242322] transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
              >
                <span>Studio Admin</span>
                <ExternalLink className="w-3.5 h-3.5 text-[#A97849]" />
              </button>
            </div>

            {/* Sign Out */}
            <button
              onClick={handleSignOut}
              className="w-full py-3 bg-transparent border border-[#242322]/20 hover:bg-[#242322]/5 text-[#242322] rounded-full text-xs font-mono uppercase font-bold tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              <LogOut className="w-4 h-4" />
              <span>Switch Account / Sign Out</span>
            </button>
          </div>
        ) : (
          /* Secure Input Login Form (No public names or emails shown) */
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Name Input */}
            <div className="space-y-1.5 text-left">
              <label className="block text-[11px] font-mono uppercase tracking-wider text-[#A97849] font-bold">
                Your Name
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full pl-10 pr-4 py-3 bg-white/95 rounded-2xl border border-[#242322]/15 text-xs text-[#242322] placeholder:text-[#242322]/35 focus:outline-none focus:border-[#A97849] focus:ring-1 focus:ring-[#A97849] transition-all shadow-sm font-sans"
                />
                <UserIcon className="w-4 h-4 text-[#242322]/40 absolute left-3.5 top-3.5" />
              </div>
            </div>

            {/* Email Input */}
            <div className="space-y-1.5 text-left">
              <label className="block text-[11px] font-mono uppercase tracking-wider text-[#A97849] font-bold">
                Registered Email
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="e.g. name@example.com"
                  className="w-full pl-10 pr-4 py-3 bg-white/95 rounded-2xl border border-[#242322]/15 text-xs text-[#242322] placeholder:text-[#242322]/35 focus:outline-none focus:border-[#A97849] focus:ring-1 focus:ring-[#A97849] transition-all shadow-sm font-sans"
                />
                <Mail className="w-4 h-4 text-[#242322]/40 absolute left-3.5 top-3.5" />
              </div>
            </div>

            {/* Password Input */}
            <div className="space-y-1.5 text-left">
              <label className="block text-[11px] font-mono uppercase tracking-wider text-[#A97849] font-bold">
                Access Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-3 bg-white/95 rounded-2xl border border-[#242322]/15 text-xs text-[#242322] placeholder:text-[#242322]/35 focus:outline-none focus:border-[#A97849] focus:ring-1 focus:ring-[#A97849] transition-all shadow-sm font-mono tracking-wider"
                />
                <KeyRound className="w-4 h-4 text-[#242322]/40 absolute left-3.5 top-3.5" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3.5 text-[#242322]/40 hover:text-[#242322] transition-colors cursor-pointer"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting || googleLoading}
              className="w-full py-3.5 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50 mt-2"
            >
              <LogIn className="w-4 h-4 text-[#E8F36B]" />
              <span>{isSubmitting ? 'VERIFYING CREDENTIALS...' : 'SIGN IN'}</span>
            </button>

            {/* Divider */}
            <div className="relative flex py-2 items-center">
              <div className="flex-grow border-t border-[#242322]/10"></div>
              <span className="flex-shrink mx-3 text-[10px] font-mono text-[#242322]/40 uppercase tracking-widest">
                Or Google Auth
              </span>
              <div className="flex-grow border-t border-[#242322]/10"></div>
            </div>

            {/* Google Authentication Option */}
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isSubmitting || googleLoading}
              className="w-full py-3 bg-white/90 hover:bg-white border border-[#242322]/15 rounded-full text-xs font-mono text-[#242322] font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2.5 cursor-pointer shadow-sm hover:shadow disabled:opacity-50"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{googleLoading ? 'VERIFYING VIA GOOGLE...' : 'CONTINUE WITH GOOGLE'}</span>
            </button>

            <p className="text-[10px] font-mono text-center text-[#242322]/40 pt-1">
              Private access. Credentials verified securely against studio records.
            </p>
          </form>
        )}

      </div>
    </div>
  );
}
