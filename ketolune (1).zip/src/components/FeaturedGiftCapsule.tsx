import { useState } from 'react';

// Asset 3: Overhead gift composition with natural fabric, dried flowers, stationery, and parcel details
const ASSET_OVERHEAD_COMPOSITION = '/images/note_the_part_they_keep.jpg';

export default function FeaturedGiftCapsule() {
  const [activeLabel, setActiveLabel] = useState<number>(0);

  const experienceLabels = [
    {
      num: "01",
      title: "THREE THOUGHTFUL ANSWERS.",
      subtitle: "The Human Blueprint",
      desc: "You illuminate what words usually skip: the morning rituals, the eccentric obsessions, the unspoken generosity. Those three observations form the private blueprint of the parcel."
    },
    {
      num: "02",
      title: "PERSONALIZED CURATION.",
      subtitle: "Atelier Assembly",
      desc: "Our workshop pairs tactile keepsakes, personal sensory aromatics, and bespoke stationery into an unrepeatable harmony made exclusively for this single recipient."
    },
    {
      num: "03",
      title: "A SURPRISE KEPT UNDER WRAPS.",
      subtitle: "The Thrill of Mystery",
      desc: "Enclosed in heavyweight unbleached kraft, hand-tied botanical cord, and an authentic wax seal. The contents remain an absolute mystery until their hands break the twine."
    },
    {
      num: "04",
      title: "A NOTE IN YOUR OWN WORDS, IF YOU CHOOSE.",
      subtitle: "Archival Inscription",
      desc: "Add a dedication that sounds unmistakably like you. Inscribed faithfully with dip pen onto heavy cotton paper—every pause, inside joke, and honest sentiment preserved."
    }
  ];

  return (
    <section id="capsule" className="py-24 sm:py-32 px-6 bg-[#EDE8DF] text-[#242322] select-none border-b border-[#242322]/10">
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Curatorial Header with Magnetic, Compelling Copy */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-[#242322]/15 pb-8">
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center gap-3 text-xs uppercase tracking-widest font-mono text-[#A97849] font-bold">
              <span>Chapter 03</span>
              <span>•</span>
              <span>The Mystery Unfolding</span>
            </div>
            <h2 className="font-condensed text-5xl sm:text-7xl lg:text-8xl uppercase tracking-tight text-[#242322] leading-[0.9]">
              A SURPRISE THAT<br />
              <span className="text-[#A97849]">STARTS WITH THEM.</span>
            </h2>
          </div>
          <div className="max-w-md space-y-3">
            <p className="text-base sm:text-lg text-[#242322]/85 leading-relaxed font-sans">
              Tell us what makes them who they are. We'll use your answers to guide the gift selection.
            </p>
            <p className="text-xs font-mono text-[#242322]/65 leading-relaxed">
              No warehouse registries. No automated assembly lines. Just human care and the patient craft of gifting.
            </p>
          </div>
        </div>

        {/* Featured Layout: Pure Photographic Asset 3 + Four Magnetic Experience Labels */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Main Visual: Asset 3 Overhead Composition (Pure - NO text overlaid on image) */}
          <div className="lg:col-span-6 space-y-3">
            <div className="relative rounded-3xl overflow-hidden border border-[#242322]/15 shadow-xl bg-[#DFD7C7] aspect-[4/3] group">
              <img
                src={ASSET_OVERHEAD_COMPOSITION}
                alt="Overhead flat-lay composition of KETOLUNE gift parcel with handmade stationery and dried botanicals"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/images/hero_ketolune_box.jpg';
                }}
              />
            </div>
            {/* Active inspection spec cleanly placed BELOW the photo */}
            <div className="p-4 rounded-2xl bg-[#F7EFDF] border border-[#242322]/10 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold uppercase tracking-wider text-[#242322]">
                  {experienceLabels[activeLabel].title}
                </span>
                <span className="text-[#A97849] ml-2 text-[11px] font-mono">
                  [{experienceLabels[activeLabel].subtitle}]
                </span>
              </div>
              <span className="font-script text-base text-[#A97849]">
                Made slowly. Meant personally.
              </span>
            </div>
          </div>

          {/* Four Distinct Editorial Labels */}
          <div className="lg:col-span-6 space-y-4">
            <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold pb-1 flex items-center justify-between">
              <span>The Four Cornerstones</span>
              <span className="text-[#242322]/40 font-normal">Select to inspect</span>
            </div>

            {experienceLabels.map((item, idx) => (
              <div
                key={item.num}
                onClick={() => setActiveLabel(idx)}
                className={`p-5 rounded-2xl border transition-all cursor-pointer ${
                  activeLabel === idx
                    ? 'bg-[#F7EFDF] border-[#A97849] shadow-md -translate-x-1'
                    : 'bg-white/70 border-[#242322]/10 hover:bg-white hover:border-[#A97849]/30'
                }`}
              >
                <div className="flex items-center justify-between pb-1">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xs font-mono text-[#A97849] font-bold">
                      {item.num} —
                    </span>
                    <h3 className="font-condensed text-xl sm:text-2xl uppercase tracking-tight text-[#242322] font-bold">
                      {item.title}
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono text-[#A97849] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/80 border border-[#A97849]/20">
                    {item.subtitle}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-[#242322]/75 leading-relaxed font-sans pl-7">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
}
