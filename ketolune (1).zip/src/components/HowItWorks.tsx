// Asset 6: Collection of closed wrapped packages ready for monthly dispatch
const ASSET_WRAPPED_BATCH = '/images/gift_world_collage.jpg';

interface HowItWorksProps {
  onOpenEnrollment: () => void;
}

export default function HowItWorks({ onOpenEnrollment }: HowItWorksProps) {
  const steps = [
    {
      num: "01",
      tag: "OBSERVE",
      title: "Three Questions",
      desc: "Share three subtle details about the person: their quiet daily habit, sensory palette, and what they hold dear.",
      accent: "bg-[#FFFDF7] text-[#242322] border-[#D8CEEE]",
      badgeBg: "bg-[#EAE4F5] text-[#553C7B]",
      footerLabel: "Phase 01 • Listening"
    },
    {
      num: "02",
      tag: "CURATE",
      title: "Personalized Curation",
      desc: "Our workshop shapes an unrepeatable combination: tactile keepsakes, personal aromatics, thoughtful stationery, and botanicals.",
      accent: "bg-[#F7F2FD] text-[#242322] border-[#CFC3E8]",
      badgeBg: "bg-[#DFD3F4] text-[#472E6D]",
      footerLabel: "Phase 02 • Crafting"
    },
    {
      num: "03",
      tag: "DISPATCH",
      title: "The Unfolding",
      desc: "Arrives closed in tactile kraft paper with a personal wax seal. The contents remain a complete mystery until opened.",
      accent: "bg-[#FAF7EE] text-[#242322] border-[#D8CEEE]",
      badgeBg: "bg-[#ECE6D8] text-[#5A4F36]",
      footerLabel: "Phase 03 • The Reveal"
    }
  ];

  return (
    <section id="how-it-works" className="py-24 sm:py-32 px-6 bg-[#EBE4F7] text-[#242322] select-none border-b border-[#242322]/10">
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-[#242322]/15 pb-8">
          <div className="space-y-3">
            <div className="flex items-center gap-3 text-xs uppercase tracking-widest font-mono text-[#7B5CA8] font-bold">
              <span>Chapter 02</span>
              <span>•</span>
              <span>The Ritual</span>
            </div>
            <h2 className="font-condensed text-5xl sm:text-7xl lg:text-8xl text-[#242322] uppercase tracking-tight leading-[0.9]">
              HOW IT UNFOLDS
            </h2>
          </div>
          <p className="max-w-md text-sm sm:text-base text-[#242322]/80 leading-relaxed font-sans">
            A simple three-stage sequence designed to create genuine delight without the recipient ever guessing what is inside.
          </p>
        </div>

        {/* 3 Editorial Step Columns with Perfect Harmonic Lavender / Cream Palette */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((st) => (
            <div
              key={st.num}
              className={`${st.accent} rounded-3xl p-8 border shadow-sm flex flex-col justify-between space-y-8 hover:shadow-lg transition-all duration-300 hover:-translate-y-1`}
            >
              <div className="flex items-center justify-between">
                <span className="font-condensed text-3xl font-bold text-[#242322]">
                  {st.num}
                </span>
                <span className={`text-[10px] font-mono font-bold tracking-widest uppercase px-3 py-1 rounded-full ${st.badgeBg}`}>
                  {st.tag}
                </span>
              </div>

              <div className="space-y-3">
                <h3 className="font-condensed text-3xl sm:text-4xl uppercase tracking-tight text-[#242322]">
                  {st.title}
                </h3>
                <p className="text-sm text-[#242322]/80 leading-relaxed font-sans">
                  {st.desc}
                </p>
              </div>

              <div className="pt-4 border-t border-[#242322]/10 flex items-center justify-between text-xs font-mono text-[#242322]/65 uppercase">
                <span>{st.footerLabel}</span>
                <span className="text-[#7B5CA8] font-bold">→</span>
              </div>
            </div>
          ))}
        </div>

        {/* Photographic Showcase: Asset 6 Pure Photography (NO text overlaid on image) */}
        <div className="space-y-3">
          <div className="relative rounded-3xl overflow-hidden border border-[#242322]/15 shadow-xl bg-[#EDE8DF] aspect-[21/9] sm:aspect-[24/9]">
            <img
              src={ASSET_WRAPPED_BATCH}
              alt="Collection of wrapped KETOLUNE gift parcels ready for monthly dispatch"
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/images/ketolune_campaign_hero.jpg';
              }}
            />
          </div>
          {/* Caption cleanly placed below photo */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs font-mono text-[#242322]/60 gap-2 px-1">
            <span>Each parcel sealed by hand in unbleached kraft, botanical sprigs, and wax</span>
            <span className="font-script text-base text-[#7B5CA8]">Meant personally</span>
          </div>
        </div>

        {/* Action Button */}
        <div className="text-center pt-2">
          <button
            onClick={onOpenEnrollment}
            className="px-9 py-4 bg-[#242322] hover:bg-[#7B5CA8] text-[#F7EFDF] rounded-full text-xs sm:text-sm font-bold uppercase tracking-wider transition-all hover:scale-105 cursor-pointer shadow-lg shadow-[#242322]/15"
          >
            Begin Stage 01
          </button>
        </div>

      </div>
    </section>
  );
}
