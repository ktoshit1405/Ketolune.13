import { useState, useEffect } from 'react';

// Refined tactile tracking lens that tracks mouse pointer coordinates with clean vector optics
export function TrackingLensBadge({ className = '' }: { className?: string }) {
  const [pupilPos, setPupilPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      const x = ((e.clientX / innerWidth) - 0.5) * 5;
      const y = ((e.clientY / innerHeight) - 0.5) * 5;
      setPupilPos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div className={`inline-flex items-center gap-1.5 bg-slate-950/90 text-white px-3 py-1.5 rounded-full border border-white/20 shadow-lg select-none backdrop-blur-md ${className}`}>
      {/* Precision Lens Indicator */}
      <div className="w-4 h-4 rounded-full border border-white/60 flex items-center justify-center relative overflow-hidden bg-slate-900">
        <div
          className="w-1.5 h-1.5 bg-[#e8f36b] rounded-full transition-transform duration-75 ease-out shadow-sm"
          style={{ transform: `translate(${pupilPos.x}px, ${pupilPos.y}px)` }}
        />
      </div>
      <span className="text-[10px] font-mono uppercase tracking-widest text-slate-200 font-bold">
        Curating in Real-Time
      </span>
    </div>
  );
}

// Delicate, realistic Cerulean Butterfly Vector with smooth organic flutter
export function ButterflyGraphic({ className = '' }: { className?: string }) {
  return (
    <div className={`inline-flex items-center justify-center select-none ${className}`}>
      <svg
        className="w-8 h-8 sm:w-10 sm:h-10 text-sky-400 drop-shadow-md hover:scale-110 transition-transform duration-300"
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M24 28C24 28 17 21 11 20C5 19 3 23 5 28C7 33 13 36 21 31L24 28Z"
          fill="#38bdf8"
          fillOpacity="0.85"
        />
        <path
          d="M24 28C24 28 31 21 37 20C43 19 45 23 43 28C41 33 35 36 27 31L24 28Z"
          fill="#0284c7"
          fillOpacity="0.85"
        />
        <path
          d="M24 22C24 22 15 13 11 9C7 5 3 7 4 13C5 19 13 25 22 23L24 22Z"
          fill="#38bdf8"
        />
        <path
          d="M24 22C24 22 33 13 37 9C41 5 45 7 44 13C43 19 35 25 26 23L24 22Z"
          fill="#0ea5e9"
        />
        <ellipse cx="24" cy="24" rx="1.5" ry="8" fill="#0f172a" />
      </svg>
    </div>
  );
}

// Scalloped cloud arch divider
export function ScallopedCloudDivider({
  bgColor = "bg-white",
  topColor = "transparent",
  flip = false
}: {
  bgColor?: string;
  topColor?: string;
  flip?: boolean;
}) {
  return (
    <div className={`w-full overflow-hidden leading-none select-none ${flip ? 'rotate-180 -mt-1' : '-mb-1'}`}>
      <svg
        className="w-full h-12 sm:h-16 md:h-20 fill-current text-white"
        viewBox="0 0 1200 120"
        preserveAspectRatio="none"
      >
        <path d="M0,0 C75,80 125,80 200,0 C275,80 325,80 400,0 C475,80 525,80 600,0 C675,80 725,80 800,0 C875,80 925,80 1000,0 C1075,80 1125,80 1200,0 L1200,120 L0,120 Z" />
      </svg>
    </div>
  );
}
