import { useState } from 'react';
import { CUSTOMIZATION_OPTIONS, BatchTier, CURRENT_BATCH } from '../data/batchData';
import { Check, Sparkles, ShoppingBag, ArrowLeft, Clock } from 'lucide-react';

interface CuratedResultViewProps {
  recipientName?: string;
  initialTier?: BatchTier;
  onAddToCart: (item: {
    tier: BatchTier;
    aroma: string;
    ceramicFinish: string;
    ribbonColor: string;
    waxSealColor: string;
    noteText: string;
  }) => void;
  onBack: () => void;
}

export default function CuratedResultView({
  recipientName = "Elena",
  initialTier = CURRENT_BATCH.tiers[1],
  onAddToCart,
  onBack,
}: CuratedResultViewProps) {
  const [selectedTier, setSelectedTier] = useState<BatchTier>(initialTier);
  const [selectedAroma, setSelectedAroma] = useState(CUSTOMIZATION_OPTIONS.aroma[2]);
  const [selectedCeramic, setSelectedCeramic] = useState(CUSTOMIZATION_OPTIONS.ceramicFinish[0]);
  const [selectedRibbon, setSelectedRibbon] = useState(CUSTOMIZATION_OPTIONS.ribbonColor[0]);
  const [selectedSeal, setSelectedSeal] = useState(CUSTOMIZATION_OPTIONS.waxSealColor[0]);
  const [customNote, setCustomNote] = useState(
    `For ${recipientName}. To the one who notices the quietest light at dusk. May this small weight bring your mornings stillness.`
  );

  const handleBook = () => {
    onAddToCart({
      tier: selectedTier,
      aroma: selectedAroma.label,
      ceramicFinish: selectedCeramic.label,
      ribbonColor: selectedRibbon.label,
      waxSealColor: selectedSeal.label,
      noteText: customNote,
    });
  };

  return (
    <div className="min-h-screen py-20 px-6 bg-[#F7EFDF] text-[#242322]">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Navigation back */}
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-mono text-[#A97849] hover:text-[#242322] transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>RETURN TO HOME</span>
        </button>

        {/* Curation Proposal Header */}
        <div className="space-y-4 border-b border-[#242322]/15 pb-8">
          <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-[0.2em] text-[#A97849] font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Curated For {recipientName.toUpperCase()}</span>
          </div>

          <h1 className="text-4xl sm:text-6xl md:text-7xl font-condensed uppercase tracking-tight text-[#242322] leading-none font-bold">
            WE THINK THIS ONE<br />
            <span className="text-[#A97849] italic font-serif">FITS THEM.</span>
          </h1>

          <p className="text-sm md:text-base text-[#242322]/80 max-w-2xl font-sans leading-relaxed">
            Finding the little things that matter. Based on your answers, our studio has shaped this tactile mystery assembly. You may adjust finishes below to harmonize with their rituals.
          </p>
        </div>

        {/* Main Configurator Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Visual Curation Proposal */}
          <div className="lg:col-span-5 space-y-8 sticky top-24">
            {/* Visual Box Preview */}
            <div className="relative aspect-[4/3] bg-[#EDE8DF] border border-[#242322]/15 rounded-3xl overflow-hidden p-6 flex flex-col justify-between shadow-xl">
              <div className="flex justify-between items-start text-xs font-mono">
                <span className="text-[#242322] uppercase font-bold px-3 py-1 bg-white/80 rounded-full border border-[#242322]/10">{selectedTier.name} PARCEL</span>
                <span className="text-xl font-bold font-mono text-[#242322]">₹{selectedTier.priceINR}</span>
              </div>

              {/* Tactile preview badge */}
              <div className="space-y-2 my-auto text-center py-6">
                <div className="text-xs font-mono uppercase text-[#A97849] tracking-widest font-bold">
                  Studio Parcel Assembly
                </div>
                <div className="text-3xl font-serif italic text-[#242322]">
                  "{selectedAroma.label}"
                </div>
                <div className="flex justify-center items-center gap-2 text-xs font-mono text-[#242322]/70 pt-2">
                  <span
                    className="w-3 h-3 rounded-full border border-[#242322]/20"
                    style={{ backgroundColor: selectedCeramic.hex }}
                  />
                  <span>{selectedCeramic.label}</span>
                  <span>·</span>
                  <span
                    className="w-3 h-3 rounded-full border border-[#242322]/20"
                    style={{ backgroundColor: selectedRibbon.hex }}
                  />
                  <span>{selectedRibbon.label}</span>
                </div>
              </div>

              <div className="pt-4 border-t border-[#242322]/10 flex justify-between text-[11px] font-mono text-[#242322]/70">
                <span>Dimensions: {selectedTier.dimensions}</span>
                <span className="text-[#A97849] font-bold">Made slowly. Meant personally.</span>
              </div>
            </div>

            {/* Accurate Production & Dispatch Disclaimer */}
            <div className="p-4 bg-white/80 rounded-2xl border-l-4 border-[#A97849] space-y-1.5 shadow-sm">
              <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#A97849] uppercase">
                <Clock className="w-3.5 h-3.5" />
                <span>Production & Timeline Notice</span>
              </div>
              <p className="text-xs font-sans text-[#242322]/80 leading-relaxed">
                Preparation takes approximately 7–8 business days before dispatch. Delivery time is additional and depends on your location.
              </p>
            </div>

            {/* Included in this Curation */}
            <div className="p-6 bg-white/80 border border-[#242322]/10 rounded-2xl space-y-4 shadow-sm">
              <div className="text-xs font-mono uppercase tracking-wider text-[#A97849] font-bold">
                Inclusions inside box:
              </div>
              <ul className="space-y-2 text-xs text-[#242322]/85 font-sans">
                {selectedTier.contents.map((c, i) => (
                  <li key={i} className="flex items-start gap-2.5">
                    <Check className="w-3.5 h-3.5 text-[#A97849] shrink-0 mt-0.5" />
                    <span>{c}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Right Column: Editorial Configurator Controls */}
          <div className="lg:col-span-7 space-y-10">
            {/* 1. Tier Switcher (Applicable price disclosed in private booking stage) */}
            <div className="space-y-3">
              <label className="block text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                01. Gift Tier & Scale
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {CURRENT_BATCH.tiers.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setSelectedTier(t)}
                    className={`p-4 rounded-2xl border text-left transition-colors cursor-pointer ${
                      selectedTier.id === t.id
                        ? 'border-[#242322] bg-white text-[#242322] shadow-md font-bold'
                        : 'border-[#242322]/10 bg-white/50 text-[#242322]/70 hover:bg-white/80'
                    }`}
                  >
                    <div className="flex justify-between items-baseline mb-1">
                      <span className="text-xs font-mono font-bold text-[#242322]">{t.name}</span>
                      <span className="text-xs font-mono font-bold text-[#242322]">₹{t.priceINR}</span>
                    </div>
                    <p className="text-[11px] text-[#242322]/70 line-clamp-2">{t.tagline}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Scent / Aroma formulation */}
            <div className="space-y-3">
              <div className="flex justify-between items-baseline">
                <label className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                  02. Sensory Atmosphere & Scent Palette
                </label>
                <span className="text-xs font-mono text-[#242322] font-semibold">{selectedAroma.label}</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {CUSTOMIZATION_OPTIONS.aroma.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => setSelectedAroma(a)}
                    className={`p-4 rounded-2xl border text-left transition-colors cursor-pointer ${
                      selectedAroma.id === a.id
                        ? 'border-[#242322] bg-white text-[#242322] shadow-sm font-semibold'
                        : 'border-[#242322]/10 bg-white/50 text-[#242322]/70 hover:bg-white/80'
                    }`}
                  >
                    <div className="text-xs font-semibold text-[#242322] mb-1">{a.label}</div>
                    <p className="text-[11px] text-[#242322]/70 leading-relaxed font-sans">{a.notes}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Ceramic Glaze & Material Finish */}
            <div className="space-y-3">
              <div className="flex justify-between items-baseline">
                <label className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                  03. Packaging Finishing & Material Tone
                </label>
                <span className="text-xs font-mono text-[#242322] font-semibold">{selectedCeramic.label}</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {CUSTOMIZATION_OPTIONS.ceramicFinish.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setSelectedCeramic(c)}
                    className={`p-3.5 rounded-2xl border text-left transition-colors cursor-pointer flex flex-col justify-between min-h-[90px] ${
                      selectedCeramic.id === c.id
                        ? 'border-[#242322] bg-white shadow-sm'
                        : 'border-[#242322]/10 bg-white/50 hover:bg-white/80'
                    }`}
                  >
                    <div
                      className="w-5 h-5 rounded-full border border-black/10 mb-2 shadow-xs"
                      style={{ backgroundColor: c.hex }}
                    />
                    <div>
                      <div className="text-xs font-medium text-[#242322] leading-tight">{c.label}</div>
                      <div className="text-[10px] text-[#242322]/60 font-sans">{c.texture}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* 4. Plant-Dyed Silk Ribbon */}
            <div className="space-y-3">
              <div className="flex justify-between items-baseline">
                <label className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                  04. Hand-Tied Ribbon Tone
                </label>
                <span className="text-xs font-mono text-[#242322] font-semibold">{selectedRibbon.label}</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {CUSTOMIZATION_OPTIONS.ribbonColor.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => setSelectedRibbon(r)}
                    className={`p-3.5 rounded-2xl border text-left transition-colors cursor-pointer flex flex-col justify-between min-h-[80px] ${
                      selectedRibbon.id === r.id
                        ? 'border-[#242322] bg-white shadow-sm'
                        : 'border-[#242322]/10 bg-white/50 hover:bg-white/80'
                    }`}
                  >
                    <div
                      className="w-5 h-5 rounded-full border border-black/10 mb-2 shadow-xs"
                      style={{ backgroundColor: r.hex }}
                    />
                    <div className="text-xs font-medium text-[#242322] leading-tight">{r.label}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* 5. Hand-Pressed Botanical Wax Seal */}
            <div className="space-y-3">
              <div className="flex justify-between items-baseline">
                <label className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                  05. Hand-Pressed Wax Impression
                </label>
                <span className="text-xs font-mono text-[#242322] font-semibold">{selectedSeal.label}</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {CUSTOMIZATION_OPTIONS.waxSealColor.map((w) => (
                  <button
                    key={w.id}
                    onClick={() => setSelectedSeal(w)}
                    className={`p-3.5 rounded-2xl border text-left transition-colors cursor-pointer flex items-center gap-3 ${
                      selectedSeal.id === w.id
                        ? 'border-[#242322] bg-white shadow-sm font-semibold'
                        : 'border-[#242322]/10 bg-white/50 hover:bg-white/80'
                    }`}
                  >
                    <div
                      className="w-5 h-5 rounded-full border border-black/10 shrink-0 shadow-xs"
                      style={{ backgroundColor: w.hex }}
                    />
                    <div className="text-xs text-[#242322]">{w.label}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* 6. Letterpress Keepsake Note */}
            <div className="space-y-3">
              <div className="flex justify-between items-baseline">
                <label className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                  06. Dedicated Keepsake Inscription (Optional)
                </label>
                <span className="text-[10px] font-mono text-[#242322]/60">Archival Paper</span>
              </div>
              <textarea
                rows={3}
                value={customNote}
                onChange={(e) => setCustomNote(e.target.value)}
                placeholder="Optional personal message. Your exact words will be preserved..."
                className="w-full p-4 bg-white/80 border border-[#242322]/15 rounded-2xl text-xs sm:text-sm text-[#242322] placeholder-[#242322]/40 focus:border-[#242322] outline-none font-serif italic resize-none leading-relaxed"
              />
            </div>

            {/* Reserve & Add to Bag CTA */}
            <div className="pt-6 border-t border-[#242322]/15 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <div className="font-condensed text-2xl uppercase tracking-tight text-[#242322] font-bold">
                  {selectedTier.name} PARCEL ALLOCATION — ₹{selectedTier.priceINR}
                </div>
                <div className="text-xs font-mono text-[#A97849]">
                  Personalized allocation for {recipientName}
                </div>
              </div>

              <button
                onClick={handleBook}
                className="w-full sm:w-auto px-8 py-4 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl hover:scale-105"
              >
                <ShoppingBag className="w-4 h-4 text-[#E8F36B]" />
                <span>Reserve & Add to Bag (₹{selectedTier.priceINR})</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
