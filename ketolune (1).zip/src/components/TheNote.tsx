// Asset 4: Paper note and stationery detail
const ASSET_PAPER_NOTE = '/images/note_the_part_they_keep.jpg';

export default function TheNote() {
  const notePrinciples = [
    {
      num: "01",
      title: "YOUR MESSAGE IS OPTIONAL.",
      desc: "If you have words to share, we include them faithfully. If you prefer the gift to speak on its own, it will."
    },
    {
      num: "02",
      title: "YOUR WORDS STAY YOURS.",
      desc: "We never rewrite your message into generic sentimental copy. Your original phrasing and tone are honored."
    },
    {
      num: "03",
      title: "SAY IT YOUR WAY.",
      desc: "A single inside joke, an honest thank you, or quiet gratitude. Say what only the two of you understand."
    },
    {
      num: "04",
      title: "MAKE IT PERSONAL.",
      desc: "Inscribed on our archival paper with a personal wax impression. Designed to be kept on their desk for years."
    }
  ];

  return (
    <section className="py-24 sm:py-32 px-6 bg-[#F7EFDF] text-[#242322] select-none border-b border-[#242322]/10">
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Curatorial Header */}
        <div className="max-w-3xl space-y-4">
          <div className="flex items-center gap-3 text-xs uppercase tracking-widest font-mono text-[#A97849] font-bold">
            <span>Chapter 04</span>
            <span>•</span>
            <span>The Personal Note</span>
          </div>
          <h2 className="font-condensed text-5xl sm:text-7xl lg:text-8xl text-[#242322] uppercase tracking-tight leading-[0.9]">
            THE NOTE THAT SOUNDS LIKE YOU.
          </h2>
          <p className="text-base sm:text-lg text-[#242322]/80 leading-relaxed font-sans">
            Have something you want them to hear? Add your own words. We'll keep them yours.
          </p>
        </div>

        {/* Editorial Split: Pure Asset 4 Photography + Real Gifting Principles */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Asset 4 Photography (Pure - NO text overlaid on image) */}
          <div className="lg:col-span-6 space-y-3">
            <div className="relative rounded-3xl overflow-hidden border border-[#242322]/15 shadow-xl bg-[#EDE8DF] aspect-[4/3] group">
              <img
                src={ASSET_PAPER_NOTE}
                alt="Tactile letterpress note card with handwritten dedication and wax seal"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/images/craft_made_slowly.jpg';
                }}
              />
            </div>
            {/* Clean caption below image */}
            <div className="flex items-center justify-between text-xs font-mono text-[#242322]/60 px-1">
              <span>Archival Keepsake Stationery • Wax Seal Impression</span>
              <span className="font-script text-base text-[#A97849]">Meant personally</span>
            </div>
          </div>

          {/* 4 Concise Editorial Labels */}
          <div className="lg:col-span-6 space-y-4">
            {notePrinciples.map((p) => (
              <div
                key={p.num}
                className="p-5 rounded-2xl bg-white/80 border border-[#242322]/10 shadow-sm space-y-1 hover:border-[#A97849]/40 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-[#A97849]">{p.num} —</span>
                  <h3 className="font-condensed text-xl sm:text-2xl uppercase tracking-tight text-[#242322] font-bold">
                    {p.title}
                  </h3>
                </div>
                <p className="text-xs sm:text-sm text-[#242322]/75 font-sans leading-relaxed pl-7">
                  {p.desc}
                </p>
              </div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
}
