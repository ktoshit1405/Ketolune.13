import { CURRENT_BATCH, BatchTier } from '../data/batchData';
import { ArrowUpRight, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ProductWorldProps {
  onSelectTier: (tier: BatchTier) => void;
  onOpenEnrollment: () => void;
}

// Asset 5: Solitary mystery package resting on raw limestone
const ASSET_SOLITARY_PACKAGE = '/images/ketolune_campaign_hero.jpg';

export default function ProductWorld({ onSelectTier, onOpenEnrollment }: ProductWorldProps) {
  const navigate = useNavigate();
  const { tiers } = CURRENT_BATCH;

  const cardImages = [
    "/images/craft_made_slowly.jpg",
    ASSET_SOLITARY_PACKAGE,
    "/images/hero_ketolune_box.jpg",
  ];

  return (
    <section id="tiers" className="py-24 sm:py-32 px-6 bg-[#F7EFDF] text-[#242322] select-none border-b border-[#242322]/10">
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Curatorial Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 pb-6 border-b border-[#242322]/15">
          <div className="space-y-3">
            <div className="flex items-center gap-3 text-xs uppercase tracking-widest font-mono text-[#A97849] font-bold">
              <span>Chapter 05</span>
              <span>•</span>
              <span>The Allocations</span>
            </div>
            <h2 className="font-condensed text-5xl sm:text-7xl lg:text-8xl text-[#242322] uppercase tracking-tight leading-[0.9]">
              CHOOSE A MYSTERY
            </h2>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/collections')}
              className="px-6 py-3 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-sm flex items-center gap-2"
            >
              <span>Explore All 8 Collections</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#E8F36B]" />
            </button>
          </div>
        </div>

        {/* 3 Column Grid of Approved Tiers */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tiers.map((tier, idx) => (
            <div
              key={tier.id}
              onClick={() => {
                onSelectTier(tier);
                navigate(`/collections?tier=${tier.id}`);
              }}
              className="group cursor-pointer space-y-4"
              role="button"
              tabIndex={0}
              aria-label={`Select ${tier.customerFacingName} Parcel`}
            >
              {/* Category Marker (No price on public teaser cards) */}
              <div className="flex items-center justify-between text-xs font-mono text-[#242322]/70">
                <span className="uppercase tracking-wider font-bold text-[#242322]">
                  {tier.customerFacingName}
                </span>
                <span className="font-script text-sm text-[#A97849]">
                  Personalized
                </span>
              </div>

              {/* Large Image Card: Pure Photography with NO text overlaid on image */}
              <div className="relative aspect-[3/4] rounded-3xl overflow-hidden bg-[#EDE8DF] border border-[#242322]/15 shadow-md group-hover:shadow-xl transition-all duration-300">
                <img
                  src={cardImages[idx]}
                  alt={`${tier.customerFacingName} parcel photograph`}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/images/hero_ketolune_box.jpg';
                  }}
                />

                {/* Subtle Hover Action Pill (clickable reservation interaction preserved) */}
                <div className="absolute inset-0 bg-[#242322]/30 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center pointer-events-none">
                  <span className="px-5 py-2.5 bg-[#F7EFDF] text-[#242322] rounded-full text-xs font-bold uppercase tracking-wider shadow-lg flex items-center gap-1.5 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                    <span>Reserve Allocation</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </span>
                </div>
              </div>

              {/* Title & Tagline cleanly positioned below image */}
              <div className="space-y-1 pt-1">
                <h3 className="font-condensed text-3xl uppercase tracking-tight text-[#242322] group-hover:text-[#A97849] transition-colors">
                  {tier.customerFacingName}
                </h3>
                <p className="text-xs text-[#242322]/75 leading-relaxed font-sans">
                  {tier.tagline}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
