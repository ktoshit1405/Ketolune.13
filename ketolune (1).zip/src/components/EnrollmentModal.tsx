import { useState, useEffect } from 'react';
import { X, ArrowLeft, CheckCircle2, Sparkles, Upload, FileText, Check } from 'lucide-react';
import { CURRENT_BATCH } from '../data/batchData';
import { uploadKeepsakeAsset, saveReservation, getStoredClientSession } from '../services/firebase';
import { generateKeepsakeNoteSuggestion } from '../services/gemini';
import { sendReservationEmail } from '../services/email';

interface EnrollmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEnrollmentComplete: (answers: {
    recipientName: string;
    giverName: string;
    giverEmail: string;
    q1: string;
    q2: string;
    q3: string;
    extraNote: string;
    selectedTier: 'mini' | 'medium' | 'large';
    attachmentUrl?: string;
  }) => void;
  initialQuestionIndex?: number;
}

export default function EnrollmentModal({
  isOpen,
  onClose,
  onEnrollmentComplete,
  initialQuestionIndex = 0,
}: EnrollmentModalProps) {
  const activeClient = getStoredClientSession();
  const [step, setStep] = useState(initialQuestionIndex);
  const [recipientName, setRecipientName] = useState('');
  const [giverName, setGiverName] = useState(activeClient?.name || '');
  const [giverEmail, setGiverEmail] = useState(activeClient?.email || '');
  const [q1, setQ1] = useState('');
  const [q2, setQ2] = useState('');
  const [q3, setQ3] = useState('');
  const [extraNote, setExtraNote] = useState('');
  const [selectedTier, setSelectedTier] = useState<'mini' | 'medium' | 'large'>('medium');
  const [attachmentUrl, setAttachmentUrl] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const [isGeneratingAiNote, setIsGeneratingAiNote] = useState(false);
  const [aiNoteSuggestion, setAiNoteSuggestion] = useState<string>('');

  useEffect(() => {
    if (activeClient) {
      if (!giverName) setGiverName(activeClient.name);
      if (!giverEmail) setGiverEmail(activeClient.email);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploading(true);
    try {
      const url = await uploadKeepsakeAsset(file);
      setAttachmentUrl(url);
    } catch {
      // Fallback handled cleanly
    } finally {
      setIsUploading(false);
    }
  };

  const handleAskGemini = async () => {
    setIsGeneratingAiNote(true);
    try {
      const suggestion = await generateKeepsakeNoteSuggestion({
        recipientName: recipientName.trim() || 'Your Recipient',
        relation: q1.trim() || 'A cherished relation',
        habits: q2.trim() || 'Gentle quiet habits',
        uniqueTrait: q3.trim() || 'A quiet, deep kindness',
      });
      setAiNoteSuggestion(suggestion);
    } catch {
      // Fallback handled cleanly
    } finally {
      setIsGeneratingAiNote(false);
    }
  };

  const handleNext = async () => {
    if (step < 4) {
      setStep(step + 1);
    } else {
      const answers = {
        recipientName: recipientName.trim() || 'Elena',
        giverName: giverName.trim() || 'A Friend',
        giverEmail: giverEmail.trim() || 'friend@example.com',
        q1: q1.trim() || 'My sister Maya. She took care of our home when nobody else was around.',
        q2: q2.trim() || 'Leaves cold tea bags on saucers, reads backwards, collects river stones.',
        q3: q3.trim() || 'That they don’t have to carry every heavy burden alone anymore.',
        extraNote: extraNote.trim(),
        selectedTier,
        attachmentUrl,
      };

      // Persist in Firebase
      saveReservation(answers).catch(() => {});

      // Dispatch confirmation email
      sendReservationEmail({
        to: answers.giverEmail,
        recipientName: answers.recipientName,
        orderId: `RES-${Date.now().toString().slice(-4)}`,
        tierTitle: `${selectedTier.toUpperCase()} Parcel`,
        estimatedDispatch: '7–8 Business Days',
      }).catch(() => {});

      onEnrollmentComplete(answers);
      setStep(5);
    }
  };

  const handleBack = () => {
    if (step > 0 && step < 5) {
      setStep(step - 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#242322]/80 backdrop-blur-md overflow-y-auto select-none">
      <div className="relative w-full max-w-2xl bg-[#F7EFDF] border border-[#242322]/15 p-6 sm:p-10 rounded-3xl shadow-2xl my-8 text-[#242322]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-[#242322]/60 hover:text-[#242322] rounded-full transition-colors cursor-pointer"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Step 5: Submission Completion Screen */}
        {step === 5 ? (
          <div className="py-6 space-y-6 text-center sm:text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E8F36B] text-[#242322] text-xs font-mono font-bold uppercase tracking-wider">
              <CheckCircle2 className="w-4 h-4 text-[#242322]" />
              <span>Observation Received & Enrolled</span>
            </div>

            <h2 className="font-condensed text-5xl sm:text-6xl uppercase tracking-tight text-[#242322] leading-none font-bold">
              RESERVATION LOGGED
            </h2>

            <div className="space-y-3 text-sm sm:text-base text-[#242322]/80 leading-relaxed font-sans">
              <p>
                We have noted your observations for <span className="font-bold text-[#242322]">{recipientName || 'your recipient'}</span>. Our workshop is preparing your parcel.
              </p>
              <p className="text-xs font-mono text-[#242322]/60">
                A verification record has been dispatched to <span className="text-[#242322] font-bold">{giverEmail || 'your email'}</span>.
              </p>
            </div>

            <div className="p-4 bg-white/70 rounded-2xl border border-[#242322]/10 max-w-md">
              <p className="font-script text-xl text-[#A97849]">
                "Made slowly. Meant personally."
              </p>
            </div>

            <div className="pt-4 flex items-center gap-4">
              <button
                onClick={onClose}
                className="px-7 py-3.5 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-md"
              >
                Close Window
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Header with Step indicator */}
            <div className="flex items-center justify-between pb-4 border-b border-[#242322]/10">
              <div className="space-y-0.5">
                <span className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                  Observation Stage
                </span>
                <div className="font-condensed text-2xl uppercase tracking-tight text-[#242322] font-bold">
                  {step === 0 && 'The Recipient'}
                  {step === 1 && 'Question 01'}
                  {step === 2 && 'Question 02'}
                  {step === 3 && 'Question 03'}
                  {step === 4 && 'Parcel Format'}
                </div>
              </div>

              {/* Step indicator pills */}
              <div className="flex items-center gap-1.5">
                {[0, 1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      i === step
                        ? 'w-6 bg-[#242322]'
                        : i < step
                        ? 'w-2 bg-[#A97849]'
                        : 'w-2 bg-[#242322]/20'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Step 0: Recipient & Giver Information */}
            {step === 0 && (
              <div className="space-y-4">
                <div>
                  <h3 className="font-condensed text-3xl sm:text-4xl text-[#242322] uppercase tracking-tight font-bold">
                    Who is this for?
                  </h3>
                  <p className="text-xs text-[#242322]/70 font-sans mt-0.5">
                    We will personalize their parcel and write their name onto the archival inscription.
                  </p>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#242322]/70 mb-1">
                      Recipient's Name
                    </label>
                    <input
                      type="text"
                      value={recipientName}
                      onChange={(e) => setRecipientName(e.target.value)}
                      placeholder="e.g. Elena Rostova"
                      className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-sm text-[#242322] placeholder-[#242322]/40 focus:border-[#242322] outline-none font-sans"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-mono uppercase tracking-wider text-[#242322]/70 mb-1">
                        Your Name
                      </label>
                      <input
                        type="text"
                        value={giverName}
                        onChange={(e) => setGiverName(e.target.value)}
                        placeholder="e.g. Thomas"
                        className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-sm text-[#242322] placeholder-[#242322]/40 focus:border-[#242322] outline-none font-sans"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-mono uppercase tracking-wider text-[#242322]/70 mb-1">
                        Your Email
                      </label>
                      <input
                        type="email"
                        value={giverEmail}
                        onChange={(e) => setGiverEmail(e.target.value)}
                        placeholder="thomas@example.com"
                        className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-sm text-[#242322] placeholder-[#242322]/40 focus:border-[#242322] outline-none font-sans"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 1: Question 01 */}
            {step === 1 && (
              <div className="space-y-4">
                <div>
                  <div className="text-[11px] font-mono uppercase text-[#A97849] font-bold mb-1">
                    Question 01 of 03
                  </div>
                  <h3 className="font-condensed text-3xl sm:text-4xl text-[#242322] uppercase tracking-tight font-bold">
                    Who are they to you?
                  </h3>
                  <p className="text-xs text-[#242322]/70 font-sans mt-0.5">
                    The quiet history, shared memory, or how you think of them in your head.
                  </p>
                </div>

                <div className="p-4 bg-white/80 rounded-2xl border border-[#242322]/15">
                  <textarea
                    rows={4}
                    value={q1}
                    onChange={(e) => setQ1(e.target.value)}
                    placeholder="e.g. My sister Maya. She anchored our family when life turned upside down, and never lets anyone see her falter..."
                    className="w-full bg-transparent text-sm text-[#242322] placeholder-[#242322]/40 focus:outline-none leading-relaxed resize-none font-sans"
                  />
                </div>
              </div>
            )}

            {/* Step 2: Question 02 */}
            {step === 2 && (
              <div className="space-y-4">
                <div>
                  <div className="text-[11px] font-mono uppercase text-[#A97849] font-bold mb-1">
                    Question 02 of 03
                  </div>
                  <h3 className="font-condensed text-3xl sm:text-4xl text-[#242322] uppercase tracking-tight font-bold">
                    What are they like when nobody is watching?
                  </h3>
                  <p className="text-xs text-[#242322]/70 font-sans mt-0.5">
                    Quiet rituals, tactile quirks, or atmospheres that ground them.
                  </p>
                </div>

                <div className="p-4 bg-white/80 rounded-2xl border border-[#242322]/15">
                  <textarea
                    rows={4}
                    value={q2}
                    onChange={(e) => setQ2(e.target.value)}
                    placeholder="e.g. Drinks hot coffee by the window at dawn, saves old train tickets in coat pockets, loves the scent of rain on pine needles..."
                    className="w-full bg-transparent text-sm text-[#242322] placeholder-[#242322]/40 focus:outline-none leading-relaxed resize-none font-sans"
                  />
                </div>
              </div>
            )}

            {/* Step 3: Question 03 + Studio AI Note Refinement */}
            {step === 3 && (
              <div className="space-y-4">
                <div>
                  <div className="text-[11px] font-mono uppercase text-[#A97849] font-bold mb-1">
                    Question 03 of 03
                  </div>
                  <h3 className="font-condensed text-3xl sm:text-4xl text-[#242322] uppercase tracking-tight font-bold">
                    What’s something you wish they knew?
                  </h3>
                  <p className="text-xs text-[#242322]/70 font-sans mt-0.5">
                    The sentiment or appreciation you rarely find the right moment to speak aloud.
                  </p>
                </div>

                <div className="p-4 bg-white/80 rounded-2xl border border-[#242322]/15">
                  <textarea
                    rows={3}
                    value={q3}
                    onChange={(e) => setQ3(e.target.value)}
                    placeholder="e.g. That they don't have to carry every burden alone anymore. That people love them for who they are, not what they solve..."
                    className="w-full bg-transparent text-sm text-[#242322] placeholder-[#242322]/40 focus:outline-none leading-relaxed resize-none font-sans"
                  />
                </div>

                {/* Optional Gemini Assistant Button */}
                <div className="p-3.5 bg-[#FAF7F2] rounded-xl border border-[#A97849]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                  <div className="flex items-center gap-2 text-xs font-mono text-[#A97849] font-medium">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Want inspiration for their keepsake note?</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleAskGemini}
                    disabled={isGeneratingAiNote}
                    className="px-3.5 py-1.5 bg-white border border-[#A97849]/40 hover:bg-[#A97849] hover:text-white text-[#242322] rounded-full text-xs font-mono transition-all cursor-pointer shadow-sm disabled:opacity-50"
                  >
                    {isGeneratingAiNote ? 'Curating draft...' : '✨ Suggest Note with Gemini'}
                  </button>
                </div>

                {aiNoteSuggestion && (
                  <div className="p-4 bg-white/90 rounded-xl border-l-4 border-[#A97849] text-xs font-serif italic text-[#242322] space-y-2">
                    <div className="text-[10px] font-mono uppercase not-italic text-[#A97849] font-bold">
                      Studio Gemini Draft:
                    </div>
                    <p className="leading-relaxed">"{aiNoteSuggestion}"</p>
                    <button
                      type="button"
                      onClick={() => setExtraNote(aiNoteSuggestion)}
                      className="not-italic text-[11px] font-mono text-[#A97849] underline hover:text-[#242322] cursor-pointer"
                    >
                      Use as Dedicated Note Inscription
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Step 4: Tier Preference, Keepsake Upload & Notes */}
            {step === 4 && (
              <div className="space-y-5">
                <div>
                  <div className="text-[11px] font-mono uppercase text-[#A97849] font-bold mb-1">
                    Final Detail
                  </div>
                  <h3 className="font-condensed text-3xl sm:text-4xl text-[#242322] uppercase tracking-tight font-bold">
                    Select a Parcel Format
                  </h3>
                  <p className="text-xs text-[#242322]/70 font-sans mt-0.5">
                    Choose the scale of the mystery parcel.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {CURRENT_BATCH.tiers.map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setSelectedTier(t.id)}
                      className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                        selectedTier === t.id
                          ? 'border-[#242322] bg-white shadow-md'
                          : 'border-[#242322]/10 bg-white/50 hover:bg-white/80'
                      }`}
                    >
                      <div className="flex justify-between items-baseline mb-1">
                        <span className="font-condensed text-xl uppercase font-bold text-[#242322]">
                          {t.name}
                        </span>
                        <span className="text-[11px] font-script text-[#A97849]">Personalized</span>
                      </div>
                      <p className="text-[11px] text-[#242322]/70 font-sans">
                        {t.tagline}
                      </p>
                    </button>
                  ))}
                </div>

                {/* Dedicated Note */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-[#242322]/70 mb-1">
                    Your Optional Personal Note Inscription
                  </label>
                  <textarea
                    rows={2}
                    value={extraNote}
                    onChange={(e) => setExtraNote(e.target.value)}
                    placeholder="Words inscribed word-for-word onto archival cotton paper with dip pen..."
                    className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs text-[#242322] placeholder-[#242322]/40 focus:border-[#242322] outline-none resize-none font-sans"
                  />
                </div>

                {/* Firebase Storage Keepsake Attachment */}
                <div className="p-3.5 bg-white/70 rounded-xl border border-dashed border-[#A97849]/40 flex items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="text-xs font-mono font-bold text-[#242322] flex items-center gap-1.5">
                      <Upload className="w-3.5 h-3.5 text-[#A97849]" />
                      <span>Optional Keepsake Photo / Letter Upload (Firebase Storage)</span>
                    </div>
                    <p className="text-[11px] text-[#242322]/60">
                      Include a handwritten letter scan or personal memory photo to place inside the parcel.
                    </p>
                  </div>
                  <div>
                    <label className="px-3.5 py-1.5 bg-[#242322] text-[#F7EFDF] rounded-full text-xs font-mono font-medium hover:bg-[#A97849] cursor-pointer inline-flex items-center gap-1.5 transition-colors">
                      {isUploading ? 'Uploading...' : attachmentUrl ? '✓ Attached' : 'Attach File'}
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation buttons */}
            <div className="flex items-center justify-between pt-4 border-t border-[#242322]/10">
              {step > 0 ? (
                <button
                  type="button"
                  onClick={handleBack}
                  className="px-4 py-2 text-xs font-mono text-[#242322]/70 hover:text-[#242322] flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>BACK</span>
                </button>
              ) : (
                <span />
              )}

              <button
                type="button"
                onClick={handleNext}
                className="px-7 py-3 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-md"
              >
                <span>{step === 4 ? 'Confirm Reservation' : 'Continue →'}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
