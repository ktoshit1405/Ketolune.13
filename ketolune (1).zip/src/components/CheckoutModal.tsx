import { useState, useEffect } from 'react';
import { X, Lock, CreditCard, ArrowRight, ShieldCheck, QrCode, Building, Banknote } from 'lucide-react';
import { CartItem } from './CartDrawer';
import { CURRENT_BATCH } from '../data/batchData';
import { sendReservationEmail } from '../services/email';
import { saveReservation, getStoredClientSession } from '../services/firebase';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  appreciationAmount: number;
  onOrderSuccess: (orderId: string) => void;
}

export default function CheckoutModal({
  isOpen,
  onClose,
  items,
  appreciationAmount,
  onOrderSuccess,
}: CheckoutModalProps) {
  const activeClient = getStoredClientSession();
  const [recipientName, setRecipientName] = useState(items[0]?.recipientName || 'Elena Rostova');
  const [addressLine, setAddressLine] = useState('42 Meadowbrook Crescent, Indiranagar');
  const [city, setCity] = useState('Bengaluru');
  const [state, setState] = useState('Karnataka');
  const [postalCode, setPostalCode] = useState('560038');
  const [giverEmail, setGiverEmail] = useState(activeClient?.email || '');
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking' | 'cod'>('upi');
  const [upiId, setUpiId] = useState('recipient@okhdfcbank');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (activeClient?.email) {
      setGiverEmail(activeClient.email);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const baseSubtotal = items.reduce((sum, item) => sum + item.tier.priceINR, 0);
  const delivery = items.length > 0 ? CURRENT_BATCH.deliveryFeeINR : 0;
  const grandTotal = baseSubtotal + delivery + appreciationAmount;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const generatedOrderId = `KL-${Math.floor(1000 + Math.random() * 9000)}`;

    try {
      // 1. Record in Firebase
      await saveReservation({
        orderId: generatedOrderId,
        recipientName,
        address: `${addressLine}, ${city}, ${state} - ${postalCode}`,
        giverEmail,
        items: items.map(i => ({ tier: i.tier.name, aroma: i.aroma, note: i.noteText })),
        totalAmountINR: grandTotal,
        paymentMethod,
        paymentStatus: 'AUTHORIZED',
      });

      // 2. Dispatch via Resend Mail
      await sendReservationEmail({
        to: giverEmail,
        recipientName,
        orderId: generatedOrderId,
        tierTitle: items[0]?.tier.name || 'Personalized Mystery',
        estimatedDispatch: '7–8 Business Days',
      });
    } catch {
      // Fallback handled cleanly
    } finally {
      setIsSubmitting(false);
      onOrderSuccess(generatedOrderId);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#242322]/80 backdrop-blur-md overflow-y-auto select-none">
      <div className="relative w-full max-w-4xl bg-[#F7EFDF] border border-[#242322]/15 shadow-2xl rounded-3xl p-6 sm:p-10 my-8 text-[#242322]">
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-[#242322]/60 hover:text-[#242322] transition-colors cursor-pointer"
          aria-label="Close checkout"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="border-b border-[#242322]/10 pb-6 mb-8">
          <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-[#A97849] font-bold">
            <Lock className="w-3.5 h-3.5" />
            <span>Secure Studio Reservation</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-condensed uppercase tracking-tight text-[#242322] font-bold mt-1">
            CONFIRM YOUR KETOLUNE SPOT.
          </h2>
        </div>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Column: Delivery Address & Payment */}
          <div className="lg:col-span-7 space-y-8">
            {/* 1. Recipient Address */}
            <div className="space-y-4">
              <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                01. Delivery Details
              </div>
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-mono text-[#242322]/70 mb-1">
                      Recipient Full Name
                    </label>
                    <input
                      type="text"
                      required
                      value={recipientName}
                      onChange={(e) => setRecipientName(e.target.value)}
                      className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none focus:border-[#242322]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-[#242322]/70 mb-1">
                      Your Email (for receipt & updates)
                    </label>
                    <input
                      type="email"
                      required
                      value={giverEmail}
                      onChange={(e) => setGiverEmail(e.target.value)}
                      placeholder="e.g. yourname@example.com"
                      className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none focus:border-[#242322]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono text-[#242322]/70 mb-1">
                    Street Address & Flat
                  </label>
                  <input
                    type="text"
                    required
                    value={addressLine}
                    onChange={(e) => setAddressLine(e.target.value)}
                    className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none focus:border-[#242322]"
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-mono text-[#242322]/70 mb-1">City</label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-[#242322]/70 mb-1">State</label>
                    <input
                      type="text"
                      required
                      value={state}
                      onChange={(e) => setState(e.target.value)}
                      className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-[#242322]/70 mb-1">PIN Code</label>
                    <input
                      type="text"
                      required
                      value={postalCode}
                      onChange={(e) => setPostalCode(e.target.value)}
                      className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 2. Payment Method */}
            <div className="space-y-4 pt-4 border-t border-[#242322]/10">
              <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                02. Payment Method
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-3 rounded-xl border text-xs font-mono flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'upi'
                      ? 'border-[#242322] bg-white text-[#242322] font-bold shadow-sm'
                      : 'border-[#242322]/15 bg-white/50 text-[#242322]/60'
                  }`}
                >
                  <QrCode className="w-4 h-4 text-[#A97849]" />
                  <span>UPI / QR</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-xl border text-xs font-mono flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'card'
                      ? 'border-[#242322] bg-white text-[#242322] font-bold shadow-sm'
                      : 'border-[#242322]/15 bg-white/50 text-[#242322]/60'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-[#A97849]" />
                  <span>Card</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('netbanking')}
                  className={`p-3 rounded-xl border text-xs font-mono flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'netbanking'
                      ? 'border-[#242322] bg-white text-[#242322] font-bold shadow-sm'
                      : 'border-[#242322]/15 bg-white/50 text-[#242322]/60'
                  }`}
                >
                  <Building className="w-4 h-4 text-[#A97849]" />
                  <span>NetBanking</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('cod')}
                  className={`p-3 rounded-xl border text-xs font-mono flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'cod'
                      ? 'border-[#242322] bg-white text-[#242322] font-bold shadow-sm'
                      : 'border-[#242322]/15 bg-white/50 text-[#242322]/60'
                  }`}
                >
                  <Banknote className="w-4 h-4 text-[#A97849]" />
                  <span>COD Reserve</span>
                </button>
              </div>

              {paymentMethod === 'upi' && (
                <div>
                  <label className="block text-xs font-mono text-[#242322]/70 mb-1">
                    Virtual Payment Address (VPA / UPI ID)
                  </label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="e.g. mobile@okaxis / user@upi"
                    className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none"
                  />
                </div>
              )}

              {paymentMethod === 'card' && (
                <div className="space-y-3">
                  <input
                    type="text"
                    defaultValue="•••• •••• •••• 4242"
                    className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none"
                  />
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="text"
                      defaultValue="11 / 28"
                      className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none"
                    />
                    <input
                      type="text"
                      defaultValue="894"
                      className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none"
                    />
                  </div>
                </div>
              )}

              {paymentMethod === 'netbanking' && (
                <div>
                  <label className="block text-xs font-mono text-[#242322]/70 mb-1">
                    Select Indian Bank
                  </label>
                  <select className="w-full p-3 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none">
                    <option>HDFC Bank</option>
                    <option>ICICI Bank</option>
                    <option>State Bank of India</option>
                    <option>Axis Bank</option>
                    <option>Kotak Mahindra Bank</option>
                  </select>
                </div>
              )}

              {paymentMethod === 'cod' && (
                <div className="p-3.5 bg-white/80 rounded-xl border border-[#242322]/15 text-xs text-[#242322]/80 space-y-1">
                  <div className="font-mono font-bold text-[#A97849]">Cash on Delivery Reservation:</div>
                  <p>Our studio courier will collect the amount upon physical handover.</p>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Order Summary & Crucial Policies */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 bg-white/80 border border-[#242322]/10 rounded-2xl space-y-4 shadow-sm">
              <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                Reservation Summary
              </div>

              <div className="space-y-3">
                {items.map((item) => (
                  <div key={item.id} className="pb-3 border-b border-[#242322]/10 space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-[#242322] font-semibold">{item.tier.name} Parcel</span>
                      <span className="text-[#A97849] font-bold">Confirmed</span>
                    </div>
                    <div className="text-[11px] text-[#242322]/60">
                      {item.aroma} · {item.ceramicFinish}
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-2 pt-2 text-xs font-mono">
                <div className="flex justify-between text-[#242322]/70">
                  <span>Base Parcel Allocation</span>
                  <span>₹{baseSubtotal}</span>
                </div>
                <div className="flex justify-between text-[#242322]/70">
                  <span>Tracked Studio Courier</span>
                  <span>₹{delivery}</span>
                </div>
                {appreciationAmount > 0 && (
                  <div className="flex justify-between text-[#242322]/70">
                    <span>Artisan Appreciation</span>
                    <span>₹{appreciationAmount}</span>
                  </div>
                )}
                <div className="flex justify-between text-base font-mono font-bold text-[#242322] pt-3 border-t border-[#242322]/10">
                  <span>Total Payable</span>
                  <span className="text-[#A97849]">₹{grandTotal}</span>
                </div>
              </div>
            </div>

            {/* Preparation & Non-Refundable Custom Policy */}
            <div className="p-5 bg-white/80 rounded-2xl border-l-4 border-[#A97849] space-y-2 text-xs shadow-sm">
              <div className="font-mono font-bold text-[#A97849] uppercase">
                Timeline & Studio Policy
              </div>
              <p className="text-[#242322]/85 leading-relaxed font-sans font-medium">
                Preparation takes approximately 7–8 business days before dispatch. Delivery time is additional and depends on your location.
              </p>
              <p className="text-[11px] text-[#242322]/60 font-sans">
                Because each parcel is personalized around your answers, orders cannot be cancelled once production begins.
              </p>
            </div>

            {/* Confirm & Book CTA */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] text-xs font-bold uppercase tracking-wider rounded-full transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl hover:scale-105 disabled:opacity-50"
            >
              {isSubmitting ? (
                <span>AUTHORIZING RESERVATION...</span>
              ) : (
                <>
                  <span>CONFIRM & BOOK MY GIFT (₹{grandTotal})</span>
                  <ArrowRight className="w-4 h-4 text-[#E8F36B]" />
                </>
              )}
            </button>

            <div className="flex items-center justify-center gap-2 text-[11px] font-mono text-[#242322]/60">
              <ShieldCheck className="w-3.5 h-3.5 text-[#A97849]" />
              <span>Studio Craft Guarantee · Real Indian Delivery</span>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
