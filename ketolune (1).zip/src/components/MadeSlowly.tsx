import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

export default function MadeSlowly() {
  const [activeCard, setActiveCard] = useState<number | null>(0);

  const pillars = [
    // SCREENSHOT 4 CORRECTION: Replaces "Raw Stoneware Clay"
    {
      id: "01",
      title: "A SURPRISE THAT STARTS WITH THEM.",
      subtitle: "Tell us what makes them who they are. We'll use your answers to guide the gift selection.",
      bg: "bg-[#3b82f6]",
      textColor: "text-white",
      subtextColor: "text-blue-100",
      accentBg: "bg-blue-700/50",
      img: "/images/hero_ketolune_box.jpg",
      fallbackImg: "/images/ketolune_campaign_hero.jpg",
      points: [
        { num: "01", label: "THREE THOUGHTFUL ANSWERS." },
        { num: "02", label: "PERSONALIZED CURATION." },
        { num: "03", label: "A SURPRISE KEPT UNDER WRAPS." },
        { num: "04", label: "A NOTE IN YOUR OWN WORDS, IF YOU CHOOSE." }
      ],
      deepDetail: "Every KETOLUNE gift begins with the recipient: their temperament, quiet rituals, and sensory preferences. Packaging is inspected and sealed by hand so the surprise remains complete."
    },
    // SCREENSHOT 2 CORRECTION: Replaces "Plant-Dyed Frayed Silk"
    {
      id: "02",
      title: "THE LITTLE THINGS THAT MAKE THEM THEM.",
      subtitle: "Three thoughtful questions help us understand who you're gifting. No giant questionnaire. Just the details that matter.",
      bg: "bg-[#e8f36b]",
      textColor: "text-slate-950",
      subtextColor: "text-slate-800",
      accentBg: "bg-lime-400/60",
      img: "/images/ketolune_paper_craft.jpg",
      fallbackImg: "/images/craft_made_slowly.jpg",
      points: [
        { num: "01", label: "WHO THEY ARE TO YOU." },
        { num: "02", label: "WHAT THEY'RE LIKE." },
        { num: "03", label: "THE LITTLE THINGS THAT MAKE THEM DIFFERENT." },
        { num: "04", label: "WHAT YOU WANT US TO REMEMBER." }
      ],
      deepDetail: "We listen for the subtle quirks, quiet habits, and private atmospheres that make a human being distinct. No generic checkboxes or algorithm filters."
    },
    // SCREENSHOT 3 CORRECTION: Replaces "Hand-Poured Beeswax"
    {
      id: "03",
      title: "THE NOTE THAT SOUNDS LIKE YOU.",
      subtitle: "Have something you want them to hear? Add your own words. We'll keep them yours.",
      bg: "bg-[#f97316]",
      textColor: "text-white",
      subtextColor: "text-orange-100",
      accentBg: "bg-orange-700/50",
      img: "/images/note_the_part_they_keep.jpg",
      fallbackImg: "/images/ketolune_paper_craft.jpg",
      points: [
        { num: "01", label: "YOUR MESSAGE IS OPTIONAL." },
        { num: "02", label: "YOUR WORDS STAY YOURS." },
        { num: "03", label: "SAY IT YOUR WAY." },
        { num: "04", label: "MAKE IT PERSONAL." }
      ],
      deepDetail: "If you choose to include a message, your exact words are preserved faithfully. We never rewrite your sentiment into generic AI-generated copy."
    },
    // 4TH COHESIVE PILLAR: Delivery & Unboxing Experience
    {
      id: "04",
      title: "NOT PICKED. NOT PACKED. MADE FOR THEM.",
      subtitle: "A quiet inquiry into the recipient's world. An unrepeatable surprise kept completely under wraps until opened.",
      bg: "bg-[#c084fc]",
      textColor: "text-slate-950",
      subtextColor: "text-purple-950",
      accentBg: "bg-purple-400/60",
      img: "/images/gift_world_collage.jpg",
      fallbackImg: "/images/hero_ketolune_box.jpg",
      points: [
        { num: "01", label: "CONFIDENTIAL SENTIMENT." },
        { num: "02", label: "SLOW TACTILE UNBOXING." },
        { num: "03", label: "ZERO WAREHOUSE SHELVES." },
        { num: "04", label: "DIRECT TO THEIR DOORSTEP." }
      ],
      deepDetail: "Arrives in our signature unbleached kraft presentation parcel with a personal wax impression. The physical contents remain a total surprise until untied."
    }
  ];

  return (
    <section id="craft" className="py-24 px-6 bg-white text-slate-900 border-t border-slate-100 select-none">
      <div className="max-w-5xl mx-auto space-y-16">
        {/* Header */}
        <div className="text-center">
          <h2 className="text-6xl sm:text-7xl md:text-8xl font-black uppercase tracking-tight text-slate-950 font-condensed">
            OUR CRAFT
          </h2>
          <p className="text-xs font-mono uppercase tracking-widest text-slate-500 mt-2">
            The Personalization Experience · Click Any Card to Inspect
          </p>
        </div>

        {/* Stacked Interactive Color Cards (Exact Lofty Lab Framer Interaction) */}
        <div className="space-y-6">
          {pillars.map((s, idx) => {
            const isExpanded = activeCard === idx;

            return (
              <motion.div
                key={s.id}
                layout
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                onClick={() => setActiveCard(isExpanded ? null : idx)}
                className={`${s.bg} ${s.textColor} rounded-[2.5rem] p-8 sm:p-12 shadow-2xl border-2 border-slate-950 cursor-pointer transition-all duration-300 hover:scale-[1.01]`}
              >
                <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                  {/* Left Description & Numbered Checklist */}
                  <div className="md:col-span-7 space-y-6">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-mono uppercase tracking-widest opacity-80 font-bold">
                          Phase {s.id}
                        </span>
                        <span className={`inline-flex items-center gap-1.5 text-xs font-mono uppercase px-3 py-1 rounded-full ${s.accentBg} font-bold`}>
                          <span>{isExpanded ? 'Inspecting' : 'Click to inspect'}</span>
                          <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} />
                        </span>
                      </div>
                      <h3 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight font-condensed uppercase leading-none">
                        {s.title}
                      </h3>
                      <p className={`text-sm sm:text-base ${s.subtextColor} font-sans leading-relaxed`}>
                        {s.subtitle}
                      </p>
                    </div>

                    {/* 4 Points in Rounded Pill Grid (Editorial labels, NOT manufacturing claims) */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
                      {s.points.map((pt) => (
                        <div
                          key={pt.num}
                          className={`flex items-center gap-3 p-3 rounded-xl ${s.accentBg} backdrop-blur-sm text-xs font-mono font-bold`}
                        >
                          <span className="opacity-75">{pt.num}</span>
                          <span className="leading-snug">{pt.label}</span>
                        </div>
                      ))}
                    </div>

                    {/* Deep Detail on Expansion */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.3 }}
                          className={`pt-4 border-t border-black/15 text-xs font-sans leading-relaxed ${s.subtextColor}`}
                        >
                          <p className="font-medium italic">
                            "{s.deepDetail}"
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Right Image Feature (Showing ONLY packaging, never revealing mystery) */}
                  <div className="md:col-span-5 flex justify-center">
                    <div className="w-full max-w-[280px] aspect-square rounded-2xl overflow-hidden border-2 border-slate-950 shadow-xl bg-black/10">
                      <img
                        src={s.img}
                        alt={s.title}
                        className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = s.fallbackImg;
                        }}
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
