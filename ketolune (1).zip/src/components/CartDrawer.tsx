import { useNavigate } from 'react-router-dom';
import { X, ArrowRight, Heart, Clock, ShoppingBag } from 'lucide-react';
import { BatchTier, CURRENT_BATCH } from '../data/batchData';

export interface CartItem {
  id: string;
  tier: BatchTier;
  aroma: string;
  ceramicFinish: string;
  ribbonColor: string;
  waxSealColor: string;
  noteText: string;
  recipientName: string;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  appreciationAmount: number;
  onToggleAppreciation: () => void;
  onRemoveItem: (id: string) => void;
  onProceedToCheckout: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  items,
  appreciationAmount,
  onToggleAppreciation,
  onRemoveItem,
  onProceedToCheckout,
}: CartDrawerProps) {
  const navigate = useNavigate();

  if (!isOpen) return null;

  const baseSubtotal = items.reduce((sum, item) => sum + item.tier.priceINR, 0);
  const delivery = items.length > 0 ? CURRENT_BATCH.deliveryFeeINR : 0;
  const grandTotal = baseSubtotal + delivery + appreciationAmount;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-[#242322]/70 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-[#F7EFDF] border-l border-[#242322]/15 h-full flex flex-col justify-between p-6 sm:p-8 shadow-2xl overflow-y-auto text-[#242322]">
        {/* Header */}
        <div className="space-y-4 pb-6 border-b border-[#242322]/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#A97849] font-bold">
              Private Booking Allocation
            </span>
            <button
              onClick={onClose}
              className="p-1.5 text-[#242322]/60 hover:text-[#242322] transition-colors cursor-pointer"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <h2 className="text-3xl sm:text-4xl font-condensed uppercase tracking-tight text-[#242322] font-bold">
            YOUR LITTLE SURPRISE.
          </h2>
        </div>

        {/* Item List */}
        <div className="flex-1 py-6 space-y-6 overflow-y-auto">
          {items.length === 0 ? (
            <div className="py-16 text-center space-y-5">
              <div className="w-16 h-16 mx-auto rounded-full bg-[#EDE8DF] border border-[#242322]/10 flex items-center justify-center text-[#A97849]">
                <ShoppingBag className="w-7 h-7" />
              </div>
              <div className="space-y-1.5">
                <p className="font-serif italic text-2xl text-[#242322]">
                  Your gift bag is empty
                </p>
                <p className="text-xs font-mono text-[#242322]/65 max-w-xs mx-auto">
                  Every KETOLUNE gift is made slowly and shaped around the recipient. Start by sharing a few details about them.
                </p>
              </div>
              <div className="pt-2 flex flex-col gap-2.5 max-w-xs mx-auto">
                <button
                  onClick={() => {
                    onClose();
                    navigate('/enroll');
                  }}
                  className="px-6 py-3 bg-[#242322] hover:bg-[#394D92] text-[#F7EFDF] rounded-full text-xs font-mono uppercase tracking-wider font-bold transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>Find Their Surprise</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#E8F36B]" />
                </button>
                <button
                  onClick={() => {
                    onClose();
                    navigate('/collections');
                  }}
                  className="px-6 py-2.5 bg-white/80 hover:bg-white text-[#242322] border border-[#242322]/20 rounded-full text-xs font-mono uppercase tracking-wider font-bold transition-all cursor-pointer"
                >
                  Explore Collections
                </button>
              </div>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.id}
                className="p-5 bg-white/80 border border-[#242322]/10 rounded-2xl space-y-4 shadow-sm"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#A97849] font-bold">
                      For {item.recipientName || 'The Recipient'}
                    </span>
                    <h3 className="text-2xl font-condensed uppercase tracking-tight text-[#242322] font-bold">
                      {item.tier.name} Parcel
                    </h3>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-mono font-bold text-[#242322]">
                      ₹{item.tier.priceINR}
                    </span>
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="block text-[11px] font-mono text-red-600 hover:text-red-800 transition-colors cursor-pointer mt-0.5"
                    >
                      Remove
                    </button>
                  </div>
                </div>

                <div className="text-xs font-mono space-y-1 text-[#242322]/70 pt-2 border-t border-[#242322]/10">
                  <div>Scent: <span className="text-[#242322] font-medium">{item.aroma}</span></div>
                  <div>Finishing: <span className="text-[#242322] font-medium">{item.ceramicFinish}</span></div>
                  <div>Ribbon: <span className="text-[#242322] font-medium">{item.ribbonColor}</span></div>
                  <div>Wax Impression: <span className="text-[#242322] font-medium">{item.waxSealColor}</span></div>
                </div>

                {item.noteText && (
                  <div className="p-3 bg-[#EDE8DF] text-[#242322] border-l-2 border-[#A97849] text-xs font-serif italic rounded-r-lg">
                    "{item.noteText.slice(0, 95)}..."
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Studio Appreciation & Pricing Breakdown */}
        {items.length > 0 && (
          <div className="space-y-6 pt-6 border-t border-[#242322]/10">
            {/* Optional Maker Appreciation */}
            <div className="p-4 bg-white/80 rounded-2xl border border-[#242322]/10 flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-xs font-mono text-[#242322] flex items-center gap-1.5 font-bold">
                  <Heart className="w-3.5 h-3.5 text-[#FF7738]" />
                  <span>Studio Artisan Tip</span>
                </div>
                <div className="text-[11px] text-[#242322]/60">Optional appreciation for the handmade makers</div>
              </div>
              <button
                onClick={onToggleAppreciation}
                className={`px-3 py-1.5 text-xs font-mono border rounded-full transition-colors cursor-pointer ${
                  appreciationAmount > 0
                    ? 'border-[#242322] bg-[#242322] text-[#F7EFDF] font-bold'
                    : 'border-[#242322]/20 text-[#242322] hover:bg-[#242322]/5'
                }`}
              >
                {appreciationAmount > 0 ? '+ ₹50 Added' : '+ ₹50'}
              </button>
            </div>

            {/* Accurate Production & Delivery Disclosure */}
            <div className="p-4 bg-white/80 rounded-2xl border-l-4 border-[#A97849] space-y-1.5 text-xs">
              <div className="flex items-center gap-2 font-mono font-bold text-[#A97849] uppercase">
                <Clock className="w-3.5 h-3.5" />
                <span>Preparation Notice</span>
              </div>
              <p className="text-[#242322]/80 font-sans leading-relaxed">
                Preparation takes approximately 7–8 business days before dispatch. Delivery time is additional and depends on your location.
              </p>
            </div>

            {/* Transparent Payable Breakdown */}
            <div className="space-y-2 text-xs font-mono">
              <div className="flex justify-between text-[#242322]/70">
                <span>Handcrafted Parcel Allocation</span>
                <span>₹{baseSubtotal}</span>
              </div>
              <div className="flex justify-between text-[#242322]/70">
                <span>Tracked Studio Courier</span>
                <span>₹{delivery}</span>
              </div>
              {appreciationAmount > 0 && (
                <div className="flex justify-between text-[#242322]/70">
                  <span>Artisan Appreciation</span>
                  <span>₹{appreciationAmount}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-mono font-bold text-[#242322] pt-2 border-t border-[#242322]/10">
                <span>Total Payable</span>
                <span className="text-[#A97849]">₹{grandTotal}</span>
              </div>
            </div>

            {/* Continue to Checkout */}
            <button
              onClick={onProceedToCheckout}
              className="w-full py-4 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] text-xs font-bold uppercase tracking-wider rounded-full transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl hover:scale-105"
            >
              <span>CONTINUE TO CHECKOUT (₹{grandTotal})</span>
              <ArrowRight className="w-4 h-4 text-[#E8F36B]" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
