import { ArrowDownRight } from 'lucide-react';

interface FinalCTAProps {
  onOpenEnrollment: () => void;
}

export default function FinalCTA({ onOpenEnrollment }: FinalCTAProps) {
  return (
    <section className="py-24 sm:py-32 px-6 bg-[#F7EFDF] text-[#242322] select-none">
      <div className="max-w-5xl mx-auto">
        {/* Curatorial Focal Banner on Warm Charcoal Ground */}
        <div className="relative rounded-3xl overflow-hidden border border-[#242322]/15 shadow-2xl bg-[#242322] p-10 sm:p-20 text-center text-[#F7EFDF] space-y-8">
          
          {/* Background Atmospheric image with soft opacity */}
          <div className="absolute inset-0 opacity-20 pointer-events-none mix-blend-overlay">
            <img
              src="/images/hero_ketolune_box.jpg"
              alt="Atmospheric wrapped gift parcel"
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/images/ketolune_campaign_hero.jpg';
              }}
            />
          </div>

          <div className="relative z-10 space-y-6 max-w-2xl mx-auto">
            <div className="flex items-center justify-center gap-2">
              <span className="text-xs font-mono uppercase tracking-widest text-[#E8F36B] font-bold">
                Personalized Studio Allocation
              </span>
              <span className="text-white/40">•</span>
              <span className="font-script text-base text-[#F7EFDF]">
                Made slowly. Meant personally.
              </span>
            </div>

            <h2 className="font-condensed text-5xl sm:text-7xl md:text-8xl uppercase tracking-tight text-[#F7EFDF] leading-[0.9]">
              READY TO LET THE<br />
              <span className="text-[#E8F36B]">SURPRISE UNFOLD?</span>
            </h2>

            <p className="text-sm sm:text-base text-white/80 font-sans max-w-md mx-auto leading-relaxed">
              Three quiet observations. We sculpt, pour, and letter an unrepeatable physical mystery specifically for them.
            </p>

            <div className="pt-2">
              <button
                onClick={onOpenEnrollment}
                className="px-9 py-4 bg-[#E8F36B] hover:bg-white text-[#242322] rounded-full text-xs sm:text-sm font-bold uppercase tracking-wider transition-all hover:scale-105 cursor-pointer shadow-xl inline-flex items-center gap-2"
              >
                <span>Reserve Parcel</span>
                <ArrowDownRight className="w-4 h-4 text-[#242322]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
