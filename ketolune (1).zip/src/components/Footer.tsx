import { useState } from 'react';
import { ArrowUpRight } from 'lucide-react';

interface FooterProps {
  onOpenEnrollment: () => void;
  onOpenTracking: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export default function Footer({ onOpenEnrollment, onOpenTracking, onNavigateSection }: FooterProps) {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);

  const footerCards = [
    {
      id: 0,
      title: "The Idea",
      tag: "Philosophy",
      bg: "bg-[#DDEBFF]",
      textColor: "text-[#242322]",
      action: () => onNavigateSection('idea')
    },
    {
      id: 1,
      title: "How It Works",
      tag: "The Ritual",
      bg: "bg-[#EDE8DF]",
      textColor: "text-[#242322]",
      action: () => onNavigateSection('how-it-works')
    },
    {
      id: 2,
      title: "The Capsule",
      tag: "Craft Anatomy",
      bg: "bg-[#EFC9D0]",
      textColor: "text-[#242322]",
      action: () => onNavigateSection('capsule')
    },
    {
      id: 3,
      title: "Reserve",
      tag: "Personal Parcel",
      bg: "bg-[#E8F36B]",
      textColor: "text-[#242322]",
      action: onOpenEnrollment
    }
  ];

  return (
    <footer className="bg-[#242322] text-[#F7EFDF] relative overflow-hidden select-none">
      {/* Scalloped Cloud Top Divider from Warm Cream ground */}
      <div className="w-full leading-none -mt-1 overflow-hidden">
        <svg
          className="w-full h-12 sm:h-16 md:h-20 fill-current text-[#F7EFDF]"
          viewBox="0 0 1200 120"
          preserveAspectRatio="none"
        >
          <path d="M0,120 C75,40 125,40 200,120 C275,40 325,40 400,120 C475,40 525,40 600,120 C675,40 725,40 800,120 C875,40 925,40 1000,120 C1075,40 1125,40 1200,120 L1200,0 L0,0 Z" />
        </svg>
      </div>

      <div className="max-w-6xl mx-auto pt-16 pb-12 px-6 space-y-16">
        
        {/* Brand Kicker */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-b border-white/10 pb-8 text-center md:text-left">
          <div className="space-y-1">
            <h3 className="font-condensed text-4xl sm:text-5xl uppercase tracking-tight text-[#F7EFDF] font-black">
              KETOLUNE
            </h3>
            <p className="font-script text-xl text-[#A97849]">
              Made slowly. Meant personally.
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono tracking-widest uppercase">
            <button
              onClick={onOpenEnrollment}
              className="px-6 py-3 rounded-full bg-[#E8F36B] text-[#242322] font-bold hover:bg-white transition-colors cursor-pointer shadow-md"
            >
              Reserve Gift
            </button>
            <button
              onClick={onOpenTracking}
              className="px-5 py-3 rounded-full border border-white/20 text-[#F7EFDF] hover:border-white transition-colors cursor-pointer"
            >
              Check Status
            </button>
          </div>
        </div>

        {/* 4 Interactive Curatorial Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {footerCards.map((card, idx) => {
            const isHovered = hoveredCard === idx;
            return (
              <div
                key={card.id}
                onMouseEnter={() => setHoveredCard(idx)}
                onMouseLeave={() => setHoveredCard(null)}
                onClick={card.action}
                className={`relative aspect-[3/4] sm:aspect-[2/3] rounded-3xl p-6 sm:p-8 flex flex-col justify-between cursor-pointer border border-black/10 shadow-xl transition-all duration-300 transform ${card.bg} ${card.textColor} ${
                  isHovered ? '-translate-y-3 shadow-2xl scale-[1.02]' : 'hover:-translate-y-1'
                }`}
              >
                <span className="text-[10px] font-mono uppercase tracking-widest font-bold opacity-75">
                  {card.tag}
                </span>

                <div>
                  <h4 className="font-condensed text-3xl sm:text-4xl uppercase tracking-tight leading-none font-bold">
                    {card.title}
                  </h4>
                  <div className="pt-2 flex items-center gap-1 text-xs font-bold uppercase tracking-wider">
                    <span>Explore</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Quiet Authentic Copyright & Navigation Links */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs font-mono text-white/50 gap-4">
          <div>
            © 2026 KETOLUNE Studio. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:text-white transition-colors cursor-pointer" onClick={() => onNavigateSection('idea')}>
              Philosophy
            </span>
            <span className="hover:text-white transition-colors cursor-pointer" onClick={() => onNavigateSection('capsule')}>
              Capsule
            </span>
            <span className="hover:text-white transition-colors cursor-pointer" onClick={() => onNavigateSection('tiers')}>
              Allocations
            </span>
            <span className="hover:text-white transition-colors cursor-pointer" onClick={onOpenTracking}>
              Tracking
            </span>
          </div>
        </div>

      </div>
    </footer>
  );
}
