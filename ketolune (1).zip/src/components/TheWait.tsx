import { Clock } from 'lucide-react';

export default function TheWait() {
  const lifecycle = [
    { span: "Stage 01", title: "Observation & Curation", desc: "Reviewing your three answers, defining the sensory direction, selecting tailored surprise elements." },
    { span: "Stage 02", title: "Assembly & Detailing", desc: "Harmonizing tactile objects, preparing personal presentation pieces with patient studio care." },
    { span: "Stage 03", title: "Keepsake Inscription & Seal", desc: "Inscribing your dedicated note word-for-word on archival paper, pressing the personal wax impression." },
    { span: "Stage 04", title: "Inspection & Hand-Off", desc: "Wrapping in unbleached kraft, botanical sprig accent, final inspection before courier dispatch." }
  ];

  return (
    <section id="wait" className="py-24 sm:py-32 px-6 bg-[#F7EFDF] text-[#242322] border-t border-[#242322]/10 select-none">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Bold Editorial Statements */}
          <div className="lg:col-span-6 space-y-8">
            <div className="text-xs font-mono uppercase tracking-[0.2em] text-[#A97849] font-bold flex items-center gap-2">
              <Clock className="w-3.5 h-3.5" />
              <span>Studio Philosophy</span>
            </div>

            <h2 className="text-4xl sm:text-5xl md:text-6xl font-condensed uppercase tracking-tight text-[#242322] leading-[0.95]">
              A LITTLE TIME.<br />
              <span className="text-[#A97849] italic font-serif">
                A LOT OF MEANING.
              </span>
            </h2>

            <div className="space-y-4 text-sm md:text-base text-[#242322]/80 leading-relaxed font-sans">
              <p className="text-base sm:text-lg font-medium text-[#242322]">
                Your surprise takes shape after booking. Good things deserve a little thought.
              </p>
              <p>
                We live in a culture of two-hour warehouse dropoffs. KETOLUNE is the deliberate opposite. We do not pre-pack boxes and slap shipping stickers on them. Every surprise is made slowly and meant personally.
              </p>
            </div>
          </div>

          {/* Right Column: Production Lifecycle */}
          <div className="lg:col-span-6 space-y-4">
            <div className="text-xs font-mono text-[#A97849] uppercase tracking-wider font-bold mb-2">
              Inside the Studio Preparation Stages
            </div>

            <div className="space-y-3">
              {lifecycle.map((p, idx) => (
                <div
                  key={idx}
                  className="p-5 bg-white/80 rounded-2xl border border-[#242322]/10 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-[#A97849]/50 transition-colors"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-[#A97849] font-bold">{p.span}</span>
                      <span className="text-[#242322]/30">·</span>
                      <h3 className="text-base font-condensed uppercase tracking-wide text-[#242322] font-bold">{p.title}</h3>
                    </div>
                    <p className="text-xs text-[#242322]/75 leading-relaxed font-sans">
                      {p.desc}
                    </p>
                  </div>
                  <div className="text-xs font-mono text-[#A97849] font-bold shrink-0 self-end sm:self-center">
                    0{idx + 1}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4 flex items-center justify-between text-xs font-mono text-[#242322]/60">
              <span>Patient studio craft & care</span>
              <span className="text-[#A97849] font-bold">Made slowly. Meant personally.</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
