import { ArrowRight } from 'lucide-react';

// Asset 2: Close-up of the handwritten Ketolune tag, natural twine, and heavy kraft paper
const ASSET_HANDWRITTEN_TAG = '/images/ketolune_paper_craft.jpg';

interface TheIdeaProps {
  onOpenEnrollment: () => void;
}

export default function TheIdea({ onOpenEnrollment }: TheIdeaProps) {
  const editorialLabels = [
    { num: "01", label: "WHO THEY ARE TO YOU", desc: "The quiet relation and shared history that shapes the gift's mood." },
    { num: "02", label: "WHAT THEY'RE LIKE", desc: "Private rituals, morning habits, and the atmosphere they naturally carry." },
    { num: "03", label: "THE LITTLE THINGS THAT MAKE THEM DIFFERENT", desc: "The subtle quirks and preferences no generic registry could ever guess." },
    { num: "04", label: "WHAT YOU WANT US TO REMEMBER", desc: "The sentiment or unspoken feeling you want preserved in the parcel." },
  ];

  return (
    <section id="idea" className="py-24 sm:py-32 px-6 bg-[#F7EFDF] text-[#242322] select-none border-b border-[#242322]/10">
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Curatorial Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-[#242322]/15 pb-8">
          <div className="space-y-3 max-w-2xl">
            <div className="flex items-center gap-3">
              <span className="text-xs uppercase tracking-widest font-mono text-[#A97849] font-bold">
                Chapter 01
              </span>
              <span className="w-12 h-px bg-[#A97849]/40" />
              <span className="text-xs uppercase tracking-widest text-[#242322]/60">
                Personalization Experience
              </span>
            </div>

            <h2 className="font-condensed text-5xl sm:text-7xl lg:text-8xl text-[#242322] uppercase tracking-tight leading-[0.9]">
              THE LITTLE THINGS<br />
              <span className="text-[#A97849]">THAT MAKE THEM THEM.</span>
            </h2>
          </div>

          <div className="max-w-md space-y-4">
            <p className="text-base sm:text-lg text-[#242322]/85 leading-relaxed font-sans">
              Three thoughtful questions help us understand who you're gifting. No giant questionnaire. Just the details that matter.
            </p>
            <div className="flex items-center gap-2 text-xs font-mono text-[#A97849] font-semibold">
              <span className="w-2 h-2 rounded-full bg-[#A97849]" />
              <span>Made slowly. Meant personally.</span>
            </div>
          </div>
        </div>

        {/* Asymmetrical Composition: Pure Photographic Asset 2 + Four Editorial Labels & Reserve Gift Button */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Asset 2 Pure Macro Tag Photography (NO text overlaid on image) */}
          <div className="lg:col-span-6 space-y-3">
            <div className="relative rounded-3xl overflow-hidden shadow-xl border border-[#A97849]/20 bg-[#EDE8DF] aspect-[4/3] group">
              <img
                src={ASSET_HANDWRITTEN_TAG}
                alt="Close-up of handwritten Ketolune tag on textured kraft parcel with dried botanicals"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/images/craft_made_slowly.jpg';
                }}
              />
            </div>
            {/* Clean caption below photo */}
            <div className="pt-2 flex items-center justify-between text-xs font-mono text-[#242322]/60 px-1">
              <span>Archival Kraft Paper & Botanical Twine</span>
              <span className="font-script text-base text-[#A97849]">Personalized Inscription</span>
            </div>
          </div>

          {/* Right Column: 4 Clean Editorial Labels + Beautiful Reserve Gift Action */}
          <div className="lg:col-span-6 space-y-6">
            <div className="space-y-3">
              {editorialLabels.map((item) => (
                <div
                  key={item.num}
                  className="p-4 sm:p-5 rounded-2xl bg-white/80 border border-[#242322]/10 shadow-sm space-y-1 hover:border-[#A97849]/40 hover:bg-white transition-all"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-xs font-mono font-bold text-[#A97849]">{item.num} —</span>
                    <h3 className="font-condensed text-lg sm:text-xl uppercase tracking-wider text-[#242322] font-bold">
                      {item.label}
                    </h3>
                  </div>
                  <p className="text-xs sm:text-sm text-[#242322]/70 font-sans leading-relaxed pl-7">
                    {item.desc}
                  </p>
                </div>
              ))}
            </div>

            {/* Elegantly arranged Reserve Gift Action */}
            <div className="pt-2 flex flex-col sm:flex-row sm:items-center gap-4">
              <button
                onClick={onOpenEnrollment}
                className="px-8 py-4 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs sm:text-sm font-bold uppercase tracking-wider transition-all duration-200 cursor-pointer shadow-lg shadow-[#242322]/15 flex items-center justify-center gap-2.5 hover:scale-105"
              >
                <span>Reserve a Gift</span>
                <ArrowRight className="w-4 h-4 text-[#E8F36B]" />
              </button>
              <div className="text-xs font-mono text-[#242322]/60">
                <span className="text-[#A97849] font-bold">3 Questions</span> • 2 Minutes to complete
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
