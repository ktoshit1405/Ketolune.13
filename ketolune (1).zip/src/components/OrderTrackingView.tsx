import { useState } from 'react';
import { SAMPLE_ORDERS, OrderState } from '../data/batchData';
import { Check, ArrowLeft, Search } from 'lucide-react';

interface OrderTrackingViewProps {
  initialOrderId?: string;
  onBack: () => void;
}

export default function OrderTrackingView({ initialOrderId = 'KL-8821', onBack }: OrderTrackingViewProps) {
  const [searchId, setSearchId] = useState(initialOrderId);
  const [activeOrder, setActiveOrder] = useState<OrderState>(
    SAMPLE_ORDERS[initialOrderId] || SAMPLE_ORDERS['KL-8821']
  );
  const [errorMsg, setErrorMsg] = useState('');

  const milestones = [
    { title: "ENROLLED", note: "Answers logged. Studio review underway." },
    { title: "SELECTED", note: "Dedicated studio allocation confirmed." },
    { title: "BOOKED", note: "Reservation confirmed. Craft ticket queued at workbench." },
    { title: "BEING MADE", note: "Your gift is being put together on the wheel and wax bench." },
    { title: "PACKED", note: "The pieces came together in heavy kraft paper and plant-dyed ribbon." },
    { title: "SHIPPED", note: "The surprise is on its way via dedicated studio courier." },
    { title: "DELIVERED", note: "Arrived at their doorstep. Surprise unfolded." }
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchId.trim().toUpperCase();
    if (SAMPLE_ORDERS[query]) {
      setActiveOrder(SAMPLE_ORDERS[query]);
      setErrorMsg('');
    } else {
      setErrorMsg(`No active studio allocation found for "${query}". Try searching KL-8821.`);
    }
  };

  return (
    <div className="min-h-screen py-20 px-6 bg-[#F7EFDF] text-[#242322]">
      <div className="max-w-5xl mx-auto space-y-12">
        {/* Navigation back */}
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-mono text-[#A97849] hover:text-[#242322] transition-colors cursor-pointer font-bold"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>RETURN TO HOME</span>
        </button>

        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between pb-8 border-b border-[#242322]/15 gap-6">
          <div className="space-y-2">
            <div className="text-xs font-mono uppercase tracking-[0.2em] text-[#A97849] font-bold">
              Real Studio State · Genuine Progress
            </div>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-condensed uppercase tracking-tight text-[#242322] font-black">
              YOUR GIFT’S JOURNEY
            </h1>
            <p className="font-script text-2xl text-[#A97849]">
              "Made slowly. Meant personally."
            </p>
          </div>

          {/* Order Search Form */}
          <form onSubmit={handleSearch} className="flex gap-2 w-full md:w-auto">
            <input
              type="text"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              placeholder="e.g. KL-8821"
              className="px-4 py-2.5 bg-white/80 border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none focus:border-[#242322] uppercase"
            />
            <button
              type="submit"
              className="px-4 py-2.5 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] text-xs font-mono rounded-xl cursor-pointer transition-colors"
            >
              <Search className="w-4 h-4" />
            </button>
          </form>
        </div>

        {errorMsg && (
          <div className="p-4 bg-red-50 border border-red-200 text-xs font-mono text-red-700 rounded-xl">
            {errorMsg}
          </div>
        )}

        {/* Current Order Summary Card */}
        <div className="p-8 bg-white/80 border border-[#242322]/10 rounded-3xl shadow-sm grid grid-cols-1 md:grid-cols-4 gap-6 text-xs font-mono">
          <div className="space-y-1">
            <span className="text-[#A97849] uppercase text-[10px] font-bold">Studio Tracking ID</span>
            <div className="text-base font-bold text-[#242322]">{activeOrder.orderId}</div>
          </div>
          <div className="space-y-1">
            <span className="text-[#A97849] uppercase text-[10px] font-bold">For Recipient</span>
            <div className="text-base text-[#242322] font-semibold">{activeOrder.recipientName}</div>
          </div>
          <div className="space-y-1">
            <span className="text-[#A97849] uppercase text-[10px] font-bold">Curated Parcel</span>
            <div className="text-base text-[#242322] uppercase font-semibold">{activeOrder.tierId} Parcel</div>
          </div>
          <div className="space-y-1">
            <span className="text-[#A97849] uppercase text-[10px] font-bold">Estimated Dispatch</span>
            <div className="text-base text-[#242322] font-semibold">{activeOrder.estimatedDelivery}</div>
          </div>
        </div>

        {/* Milestone Timeline Journey */}
        <div className="p-8 md:p-12 bg-white/80 border border-[#242322]/10 rounded-3xl shadow-sm space-y-8">
          <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
            Handmade Production Milestones
          </div>

          <div className="space-y-8 relative before:absolute before:left-3.5 before:top-4 before:bottom-4 before:w-px before:bg-[#242322]/15">
            {milestones.map((m, idx) => {
              const isPast = idx < activeOrder.currentMilestone;
              const isCurrent = idx === activeOrder.currentMilestone;
              const isFuture = idx > activeOrder.currentMilestone;

              return (
                <div key={idx} className="relative flex items-start gap-6">
                  {/* Status Indicator Icon */}
                  <div
                    className={`relative z-10 w-7 h-7 rounded-full flex items-center justify-center shrink-0 border transition-colors ${
                      isPast
                        ? 'bg-[#242322] text-[#F7EFDF] border-[#242322]'
                        : isCurrent
                        ? 'bg-white text-[#A97849] border-[#A97849] ring-4 ring-[#A97849]/20 font-bold'
                        : 'bg-[#EDE8DF] text-[#242322]/40 border-[#242322]/15'
                    }`}
                  >
                    {isPast && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    {isCurrent && <span className="w-2 h-2 rounded-full bg-[#A97849] animate-ping" />}
                    {isFuture && <span className="text-[10px] font-mono">○</span>}
                  </div>

                  {/* Milestone Content */}
                  <div className="space-y-1 flex-1 pt-0.5">
                    <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
                      <h3
                        className={`text-base font-condensed uppercase tracking-wide font-bold ${
                          isCurrent
                            ? 'text-[#A97849]'
                            : isPast
                            ? 'text-[#242322]'
                            : 'text-[#242322]/40'
                        }`}
                      >
                        {m.title}
                      </h3>
                      <span className="text-[11px] font-mono text-[#242322]/60">
                        {isPast ? 'COMPLETED' : isCurrent ? 'CURRENT STUDIO PHASE' : 'UPCOMING'}
                      </span>
                    </div>

                    <p
                      className={`text-xs font-sans ${
                        isCurrent ? 'text-[#242322]' : isPast ? 'text-[#242322]/70' : 'text-[#242322]/40'
                      }`}
                    >
                      {m.note}
                    </p>

                    {/* Active Milestone Live Studio Note */}
                    {isCurrent && (
                      <div className="mt-3 p-4 bg-[#EDE8DF] rounded-2xl border-l-4 border-[#A97849] text-xs font-mono text-[#242322]/80 space-y-1">
                        <div className="text-[#A97849] uppercase text-[10px] font-bold">
                          STUDIO LOG · CURRENT STATUS
                        </div>
                        <p>
                          "Your gift is being assembled. Sensory elements selected based on your three answers. Keepsake letter lettered on archival paper and sealed by hand."
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Studio Notice */}
        <div className="p-6 bg-white/80 rounded-2xl border-l-4 border-[#A97849] text-xs font-mono text-[#242322]/70 space-y-1">
          <p className="font-script text-base text-[#242322]">
            "Made slowly. Meant personally."
          </p>
          <p>
            You will receive direct notification the moment your dedicated studio courier takes receipt.
          </p>
        </div>
      </div>
    </div>
  );
}
