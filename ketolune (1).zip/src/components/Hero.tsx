import { useState, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

// Tactile gift photographic assets against atmospheric sky
const HERO_SKY_GIFT_ASSET = '/images/hero_ketolune_box.jpg';
const CAMPAIGN_ART_ASSET = '/images/let_surprise_unfold_art.jpg';

interface HeroProps {
  onOpenEnrollment?: () => void;
  onScrollToManifesto?: () => void;
  onScrollToHowItWorks?: () => void;
}

export default function Hero({ onOpenEnrollment, onScrollToHowItWorks }: HeroProps) {
  const navigate = useNavigate();
  const [mouseOffset, setMouseOffset] = useState({ x: 0, y: 0 });

  const { scrollY } = useScroll();
  const yClouds = useTransform(scrollY, [0, 800], [0, -100]);
  const yProduct = useTransform(scrollY, [0, 800], [0, -35]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      const x = (e.clientX / innerWidth - 0.5) * 14;
      const y = (e.clientY / innerHeight - 0.5) * 14;
      setMouseOffset({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handlePrimaryCta = () => {
    if (onOpenEnrollment) {
      onOpenEnrollment();
    } else {
      navigate('/enroll');
    }
  };

  const handleSecondaryCta = () => {
    if (onScrollToHowItWorks) {
      onScrollToHowItWorks();
    } else {
      const el = document.getElementById('how-it-works');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      } else {
        navigate('/#how-it-works');
      }
    }
  };

  return (
    <section className="relative min-h-[92vh] md:min-h-screen flex flex-col justify-between overflow-hidden bg-gradient-to-b from-[#579CF5] via-[#85B8F8] to-[#DDEBFF] pt-28 sm:pt-32 select-none">
      {/* Background Parallax Cloud Shapes */}
      <motion.div
        style={{ y: yClouds }}
        className="absolute inset-0 pointer-events-none overflow-hidden opacity-90"
      >
        {/* Soft paper cloud left */}
        <div
          className="absolute top-16 -left-16 w-96 h-48 bg-white/70 rounded-full blur-2xl transition-transform duration-700 ease-out"
          style={{ transform: `translate3d(${mouseOffset.x * -1.8}px, ${mouseOffset.y * -1.8}px, 0)` }}
        />
        {/* Soft paper cloud right */}
        <div
          className="absolute top-28 -right-20 w-[28rem] h-52 bg-white/75 rounded-full blur-2xl transition-transform duration-700 ease-out"
          style={{ transform: `translate3d(${mouseOffset.x * 2.2}px, ${mouseOffset.y * 2.2}px, 0)` }}
        />
        {/* Lower atmospheric cloud */}
        <div
          className="absolute bottom-28 left-1/4 w-[36rem] h-60 bg-white/60 rounded-full blur-3xl transition-transform duration-700 ease-out"
          style={{ transform: `translate3d(${mouseOffset.x * -1.2}px, ${mouseOffset.y * -1.2}px, 0)` }}
        />
      </motion.div>

      {/* Main Hero Visual Composition */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 text-center flex-1 flex flex-col items-center justify-center py-6">
        
        {/* Top Brand Pill & Subtle Handwritten Accent */}
        <div className="flex flex-col items-center gap-2 mb-4 sm:mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/85 backdrop-blur-md border border-[#242322]/10 shadow-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-[#242322]" />
            <span className="text-[10px] sm:text-[11px] uppercase tracking-[0.22em] font-bold text-[#242322]">
              MADE FOR THEM. NOT JUST ANYONE.
            </span>
          </div>

          <span className="font-script text-base sm:text-lg text-[#8C6036] tracking-wide -rotate-1 select-none">
            Made slowly. Meant personally.
          </span>
        </div>

        {/* Master Three-Line Headline */}
        <h1 className="font-condensed text-6xl sm:text-8xl md:text-9xl lg:text-[10.5rem] tracking-tight text-[#242322] uppercase font-black leading-[0.86] drop-shadow-sm flex flex-col items-center mb-5">
          <span className="block font-black">LET THE</span>
          <span className="block font-black text-white drop-shadow-[0_4px_20px_rgba(25,24,47,0.22)]">
            SURPRISE
          </span>
          <span className="block font-black text-[#242322]">UNFOLD</span>
        </h1>

        {/* Visually Interesting Supporting Line */}
        <p className="text-sm sm:text-base md:text-lg text-[#242322]/90 font-medium tracking-wide max-w-md sm:max-w-xl mx-auto font-sans leading-relaxed mb-6 sm:mb-7">
          Make them wonder, <span className="font-serif italic font-semibold text-[#242322] tracking-normal">“How did you know?”</span>
        </p>

        {/* Central Photographic Asset 1: Pure Photography */}
        <motion.div
          style={{ y: yProduct }}
          className="relative z-20 my-2 sm:my-3 w-full max-w-[540px] sm:max-w-[620px] aspect-[4/3] transition-transform duration-500 ease-out"
        >
          <div className="relative w-full h-full rounded-3xl overflow-hidden shadow-2xl border-4 border-white/90 bg-[#DFD7C7]">
            <img
              src={HERO_SKY_GIFT_ASSET}
              alt="KETOLUNE handcrafted gift box with wax seal, dried botanicals and linen ribbon"
              className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                if (!target.src.includes('let_surprise_unfold_art')) {
                  target.src = CAMPAIGN_ART_ASSET;
                }
              }}
            />
            {/* Tasteful atelier marker */}
            <div className="absolute top-3.5 right-3.5 px-3 py-1 rounded-full bg-[#242322]/75 backdrop-blur-md text-[#F7EFDF] text-[10px] font-mono uppercase tracking-wider font-semibold border border-white/20">
              Atelier No. 04
            </div>
          </div>
        </motion.div>

        {/* Primary & Secondary Call to Actions */}
        <div className="pt-6 sm:pt-8 flex flex-col items-center gap-3">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 w-full max-w-md">
            {/* Primary CTA */}
            <button
              onClick={handlePrimaryCta}
              className="w-full sm:w-auto px-8 sm:px-10 py-4 bg-[#242322] hover:bg-[#394D92] text-[#F7EFDF] rounded-full text-xs sm:text-sm font-bold uppercase tracking-widest transition-all duration-200 shadow-xl shadow-[#242322]/20 cursor-pointer hover:scale-105 flex items-center justify-center gap-2.5 group"
            >
              <span>FIND THEIR SURPRISE</span>
              <span className="text-[#E8F36B] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform font-mono text-base font-normal">↗</span>
            </button>

            {/* Secondary CTA */}
            <button
              onClick={handleSecondaryCta}
              className="w-full sm:w-auto px-7 sm:px-8 py-4 bg-white/80 hover:bg-white text-[#242322] border border-[#242322]/15 rounded-full text-xs sm:text-sm font-bold uppercase tracking-widest transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer hover:scale-105 text-center"
            >
              HOW IT WORKS
            </button>
          </div>

          <span className="text-[11px] font-mono uppercase tracking-wider text-[#242322]/70 font-semibold mt-1">
            Limited Monthly Studio Allotment
          </span>
        </div>

      </div>

      {/* Organic Scalloped Cloud Divider Transitioning to Warm Cream Ground */}
      <div className="relative z-20 w-full mt-6 leading-none -mb-1 overflow-hidden">
        <svg
          className="w-full h-12 sm:h-16 md:h-20 fill-current text-[#F7EFDF]"
          viewBox="0 0 1200 120"
          preserveAspectRatio="none"
        >
          <path d="M0,0 C75,80 125,80 200,0 C275,80 325,80 400,0 C475,80 525,80 600,0 C675,80 725,80 800,0 C875,80 925,80 1000,0 C1075,80 1125,80 1200,0 L1200,120 L0,120 Z" />
        </svg>
      </div>
    </section>
  );
}
