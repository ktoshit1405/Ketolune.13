import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, CheckCircle2, Sparkles, Upload, FileText, Compass, Shield } from 'lucide-react';
import { CURRENT_BATCH } from '../data/batchData';
import { saveNewEnrollment } from '../services/adminAuth';
import { uploadKeepsakeAsset, getStoredClientSession } from '../services/firebase';
import { generateKeepsakeNoteSuggestion } from '../services/gemini';
import { sendReservationEmail } from '../services/email';

export default function EnrollPage() {
  const navigate = useNavigate();

  const [step, setStep] = useState(0);
  const activeClient = getStoredClientSession();
  const [recipientName, setRecipientName] = useState('');
  const [giverName, setGiverName] = useState(activeClient?.name || '');
  const [giverEmail, setGiverEmail] = useState(activeClient?.email || '');
  const [recipientCategory, setRecipientCategory] = useState<'boys' | 'girls'>('girls');
  const [occasion, setOccasion] = useState('Birthday Landmark');

  useEffect(() => {
    const client = getStoredClientSession();
    if (client) {
      if (!giverName) setGiverName(client.name);
      if (!giverEmail) setGiverEmail(client.email);
    }
  }, []);

  const [q1, setQ1] = useState('');
  const [q2, setQ2] = useState('');
  const [q3, setQ3] = useState('');
  const [extraNote, setExtraNote] = useState('');
  const [selectedTier, setSelectedTier] = useState<'mini' | 'medium' | 'large'>('medium');

  const [attachmentUrl, setAttachmentUrl] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);
  const [aiNoteDraft, setAiNoteDraft] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploading(true);
    try {
      const url = await uploadKeepsakeAsset(file);
      setAttachmentUrl(url);
    } catch (err) {
      console.warn('Storage fallback:', err);
    } finally {
      setIsUploading(false);
    }
  };

  const handleAskGemini = async () => {
    setIsGeneratingAi(true);
    try {
      const draft = await generateKeepsakeNoteSuggestion({
        recipientName: recipientName.trim() || 'Your Recipient',
        relation: q1.trim() || 'A deeply cherished person',
        habits: q2.trim() || 'Quiet daily habits',
        uniqueTrait: q3.trim() || 'A gentle soul',
      });
      setAiNoteDraft(draft);
    } catch (err) {
      console.warn('Gemini draft error:', err);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const handleSubmitEnrollment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const record = {
      recipientName: recipientName.trim() || 'Cherished Recipient',
      giverName: giverName.trim() || 'Client Giver',
      giverEmail: giverEmail.trim() || (activeClient?.email || 'client@ketolune.com'),
      recipientCategory,
      selectedTier,
      q1: q1.trim() || 'Someone who brought quiet light into ordinary days.',
      q2: q2.trim() || 'Morning rituals by the window, reads backwards, collects river stones.',
      q3: q3.trim() || 'That they are loved for who they are without having to solve the world.',
      extraNote: extraNote.trim(),
      attachmentUrl,
    };

    // Save enrollment to persistent store
    const saved = saveNewEnrollment(record);

    // Dispatch email acknowledgment via Resend
    sendReservationEmail({
      to: record.giverEmail,
      recipientName: record.recipientName,
      orderId: saved.id,
      tierTitle: `${selectedTier.toUpperCase()} Mystery Allocation`,
      estimatedDispatch: '7–8 Business Days upon review',
    }).catch(() => {});

    setIsSubmitting(false);
    navigate(`/account?enrolledId=${saved.id}`);
  };

  return (
    <div className="min-h-screen bg-[#F7EFDF] text-[#242322] font-sans selection:bg-[#E8F36B] selection:text-[#242322] pt-28 pb-32 px-4 sm:px-6">
      <div className="max-w-3xl mx-auto space-y-10">
        
        {/* Header */}
        <div className="border-b border-[#242322]/15 pb-6 space-y-3">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-xs font-mono uppercase text-[#242322]/70 hover:text-[#242322] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Landing Page</span>
          </button>

          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                Chapter 01 • Client Enrollment
              </span>
              <h1 className="font-condensed text-4xl sm:text-6xl uppercase tracking-tight text-[#242322] font-bold mt-1">
                TELL US ABOUT THEM
              </h1>
            </div>

            {/* Monthly Limit Badge */}
            <div className="hidden sm:flex flex-col items-end">
              <span className="px-3.5 py-1 rounded-full bg-white/90 border border-[#242322]/10 text-xs font-mono font-bold text-[#242322]">
                Cap: {CURRENT_BATCH.monthlyEnrollmentCap} Members/Month
              </span>
              <span className="text-[10px] font-mono text-[#A97849] mt-1">
                Handmade studio capacity
              </span>
            </div>
          </div>

          <p className="text-sm sm:text-base text-[#242322]/80 font-sans">
            Three thoughtful questions help our workshop understand who you're gifting. No giant questionnaire. Just the nuances that matter.
          </p>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center justify-between pb-2">
          {['The Recipient', 'Observations', 'Personal Touch', 'Review & Submit'].map((label, idx) => (
            <div key={idx} className="flex items-center gap-2 text-xs font-mono">
              <span className={`w-6 h-6 rounded-full flex items-center justify-center font-bold ${
                step === idx
                  ? 'bg-[#242322] text-[#F7EFDF]'
                  : step > idx
                  ? 'bg-[#A97849] text-white'
                  : 'bg-[#242322]/10 text-[#242322]/60'
              }`}>
                0{idx + 1}
              </span>
              <span className="hidden sm:inline text-[#242322]/80">{label}</span>
            </div>
          ))}
        </div>

        {/* Multi-step Form */}
        <form onSubmit={handleSubmitEnrollment} className="p-8 sm:p-12 bg-white/90 rounded-3xl border border-[#242322]/15 shadow-xl space-y-8">
          
          {/* Step 0: The Recipient */}
          {step === 0 && (
            <div className="space-y-6 animate-fade-in">
              <div className="border-b border-[#242322]/10 pb-4">
                <h3 className="font-condensed text-3xl uppercase font-bold text-[#242322]">
                  Who are you gifting?
                </h3>
                <p className="text-xs text-[#242322]/70 font-sans mt-0.5">
                  We address the archival parcel directly to this individual.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">
                    Recipient Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    placeholder="e.g. Maya Rostova"
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none focus:border-[#242322]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">
                    Recipient Path
                  </label>
                  <select
                    value={recipientCategory}
                    onChange={(e) => setRecipientCategory(e.target.value as 'boys' | 'girls')}
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none"
                  >
                    <option value="girls">For Her / Girls Curations</option>
                    <option value="boys">For Him / Boys Curations</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">
                    Your Name (Giver)
                  </label>
                  <input
                    type="text"
                    required
                    value={giverName}
                    onChange={(e) => setGiverName(e.target.value)}
                    placeholder="e.g. Thomas"
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none focus:border-[#242322]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">
                    Your Email (for review updates)
                  </label>
                  <input
                    type="email"
                    required
                    value={giverEmail}
                    onChange={(e) => setGiverEmail(e.target.value)}
                    placeholder="thomas@example.com"
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none focus:border-[#242322]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">
                  Occasion or Meaningful Date
                </label>
                <input
                  type="text"
                  value={occasion}
                  onChange={(e) => setOccasion(e.target.value)}
                  placeholder="e.g. Birthday Milestone, Thank You, Quiet Friendship"
                  className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none focus:border-[#242322]"
                />
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-8 py-3 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-md"
                >
                  Next: Three Observations →
                </button>
              </div>
            </div>
          )}

          {/* Step 1: Observations */}
          {step === 1 && (
            <div className="space-y-6 animate-fade-in">
              <div className="border-b border-[#242322]/10 pb-4">
                <h3 className="font-condensed text-3xl uppercase font-bold text-[#242322]">
                  The Three Nuances
                </h3>
                <p className="text-xs text-[#242322]/70 font-sans mt-0.5">
                  Our workshop reads each answer to curate tactile elements.
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-mono uppercase text-[#A97849] font-bold mb-1">
                    01 — Who are they to you?
                  </label>
                  <p className="text-[11px] text-[#242322]/60 font-sans mb-1.5">
                    The quiet history, shared memories, or how you think of them.
                  </p>
                  <textarea
                    rows={3}
                    required
                    value={q1}
                    onChange={(e) => setQ1(e.target.value)}
                    placeholder="e.g. My sister who held our family together during our hardest season..."
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none focus:border-[#242322] resize-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase text-[#A97849] font-bold mb-1">
                    02 — What are they like when nobody is watching?
                  </label>
                  <p className="text-[11px] text-[#242322]/60 font-sans mb-1.5">
                    Private habits, sensory palettes, coffee or tea rituals.
                  </p>
                  <textarea
                    rows={3}
                    required
                    value={q2}
                    onChange={(e) => setQ2(e.target.value)}
                    placeholder="e.g. Reads backward from the last chapter, drinks tea cold, keeps dried lavender in coat pockets..."
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none focus:border-[#242322] resize-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase text-[#A97849] font-bold mb-1">
                    03 — What's something you wish they knew?
                  </label>
                  <p className="text-[11px] text-[#242322]/60 font-sans mb-1.5">
                    The sentiment or appreciation you rarely speak aloud.
                  </p>
                  <textarea
                    rows={3}
                    required
                    value={q3}
                    onChange={(e) => setQ3(e.target.value)}
                    placeholder="e.g. That they don't have to carry every burden alone anymore..."
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none focus:border-[#242322] resize-none"
                  />
                </div>
              </div>

              <div className="pt-4 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(0)}
                  className="text-xs font-mono uppercase text-[#242322]/70 hover:text-[#242322] cursor-pointer"
                >
                  ← Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-8 py-3 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-md"
                >
                  Next: Dedication & Notes →
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Personal Touch & Keepsake Upload */}
          {step === 2 && (
            <div className="space-y-6 animate-fade-in">
              <div className="border-b border-[#242322]/10 pb-4">
                <h3 className="font-condensed text-3xl uppercase font-bold text-[#242322]">
                  Keepsake Note & Keepsake Attachment
                </h3>
                <p className="text-xs text-[#242322]/70 font-sans mt-0.5">
                  Add optional handwritten letter scans or photo memories for the interior parcel.
                </p>
              </div>

              {/* Dedication Note */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-mono uppercase text-[#242322]/70 font-semibold">
                    Dedication Note (Word-for-Word Inscription)
                  </label>
                  <button
                    type="button"
                    onClick={handleAskGemini}
                    disabled={isGeneratingAi}
                    className="text-xs font-mono text-[#A97849] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{isGeneratingAi ? 'Curating draft...' : '✨ Suggest Note with Gemini'}</span>
                  </button>
                </div>

                <textarea
                  rows={3}
                  value={extraNote}
                  onChange={(e) => setExtraNote(e.target.value)}
                  placeholder="Optional words inscribed with dip-pen onto 300gsm cotton paper..."
                  className="w-full p-4 bg-white border border-[#242322]/15 rounded-2xl text-xs font-serif italic text-[#242322] outline-none focus:border-[#242322] resize-none"
                />

                {aiNoteDraft && (
                  <div className="p-4 bg-[#FAF7F2] rounded-xl border-l-4 border-[#A97849] space-y-1 text-xs">
                    <span className="font-mono text-[10px] uppercase text-[#A97849] font-bold">Studio Gemini Draft:</span>
                    <p className="font-serif italic text-[#242322]">"{aiNoteDraft}"</p>
                    <button
                      type="button"
                      onClick={() => setExtraNote(aiNoteDraft)}
                      className="text-[11px] font-mono text-[#A97849] underline cursor-pointer"
                    >
                      Apply this draft
                    </button>
                  </div>
                )}
              </div>

              {/* Keepsake Upload */}
              <div className="p-4 bg-[#FAF7F2] rounded-2xl border border-dashed border-[#A97849]/40 flex items-center justify-between gap-4">
                <div className="space-y-0.5">
                  <div className="text-xs font-mono font-bold text-[#242322] flex items-center gap-1.5">
                    <Upload className="w-3.5 h-3.5 text-[#A97849]" />
                    <span>Keepsake Asset Upload (Firebase Storage)</span>
                  </div>
                  <p className="text-[11px] text-[#242322]/60">
                    Include a photo of giver & recipient or handwritten letter scan.
                  </p>
                </div>
                <div>
                  <label className="px-4 py-2 bg-[#242322] text-[#F7EFDF] rounded-full text-xs font-mono font-semibold hover:bg-[#A97849] cursor-pointer inline-flex items-center gap-1.5 transition-colors">
                    {isUploading ? 'Uploading...' : attachmentUrl ? '✓ Attached' : 'Choose File'}
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Tier Preference */}
              <div>
                <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-2 font-semibold">
                  Intended Gift Tier Preference
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {CURRENT_BATCH.tiers.map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setSelectedTier(t.id)}
                      className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                        selectedTier === t.id
                          ? 'border-[#242322] bg-[#FAF7F2] shadow-md'
                          : 'border-[#242322]/10 bg-white hover:bg-white/80'
                      }`}
                    >
                      <div className="flex justify-between items-baseline mb-1">
                        <span className="font-condensed text-lg uppercase font-bold text-[#242322]">
                          {t.customerFacingName}
                        </span>
                        <span className="text-xs font-mono text-[#A97849] font-bold">₹{t.priceINR}</span>
                      </div>
                      <p className="text-[11px] text-[#242322]/70 font-sans">
                        {t.tagline}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-4 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-xs font-mono uppercase text-[#242322]/70 hover:text-[#242322] cursor-pointer"
                >
                  ← Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-8 py-3 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-md"
                >
                  Next: Review & Submit →
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Review & Submit */}
          {step === 3 && (
            <div className="space-y-6 animate-fade-in">
              <div className="border-b border-[#242322]/10 pb-4">
                <h3 className="font-condensed text-3xl uppercase font-bold text-[#242322]">
                  Review Your Enrollment
                </h3>
                <p className="text-xs text-[#242322]/70 font-sans mt-0.5">
                  Confirm the details before submitting to our curation team.
                </p>
              </div>

              <div className="p-6 bg-[#FAF7F2] rounded-2xl border border-[#242322]/10 space-y-4 text-xs font-mono">
                <div className="flex justify-between pb-2 border-b border-[#242322]/10">
                  <span className="text-[#242322]/60">RECIPIENT:</span>
                  <span className="font-bold text-[#242322]">{recipientName} ({recipientCategory.toUpperCase()})</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-[#242322]/10">
                  <span className="text-[#242322]/60">GIVER:</span>
                  <span className="font-bold text-[#242322]">{giverName} ({giverEmail})</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-[#242322]/10">
                  <span className="text-[#242322]/60">TIER PREFERENCE:</span>
                  <span className="font-bold text-[#A97849]">{CURRENT_BATCH.tiers.find(t => t.id === selectedTier)?.customerFacingName}</span>
                </div>
                <div className="space-y-1">
                  <span className="text-[#242322]/60">OBSERVATIONS RECORDED:</span>
                  <p className="text-[11px] font-sans text-[#242322]/80 leading-relaxed italic">
                    "{q1}"
                  </p>
                </div>
              </div>

              {/* Review Policy Notice */}
              <div className="p-4 bg-white rounded-2xl border-l-4 border-[#A97849] text-xs space-y-1">
                <div className="font-mono font-bold text-[#A97849]">Curated Review Notice:</div>
                <p className="text-[#242322]/80 leading-relaxed font-sans">
                  Submissions are reviewed by our studio administrators (limited to 50 active allotments monthly). Upon approval, you will be invited to select your exact collection and complete reservation.
                </p>
              </div>

              <div className="pt-4 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="text-xs font-mono uppercase text-[#242322]/70 hover:text-[#242322] cursor-pointer"
                >
                  ← Back
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-10 py-4 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-all cursor-pointer shadow-xl hover:scale-105 disabled:opacity-50 flex items-center gap-2"
                >
                  <span>{isSubmitting ? 'LOGGING SUBMISSION...' : 'SUBMIT ENROLLMENT FOR REVIEW'}</span>
                  <ArrowRight className="w-4 h-4 text-[#E8F36B]" />
                </button>
              </div>
            </div>
          )}

        </form>

      </div>
    </div>
  );
}
