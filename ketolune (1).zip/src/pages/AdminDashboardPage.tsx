import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  fetchAllEnrollments, 
  updateEnrollmentStatus, 
  EnrollmentRecord, 
  APPROVED_ADMINS, 
  isAuthorizedAdmin,
  getAdminName 
} from '../services/adminAuth';
import { subscribeToAuth, signOutUser } from '../services/firebase';
import { sendReservationEmail } from '../services/email';
import { CURRENT_BATCH } from '../data/batchData';
import { CURATED_COLLECTIONS } from '../data/collectionsData';
import { 
  Shield, 
  LogOut, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Users, 
  Package, 
  Mail, 
  Search, 
  Filter, 
  Sparkles, 
  Eye, 
  ExternalLink 
} from 'lucide-react';
import { User } from 'firebase/auth';

export default function AdminDashboardPage() {
  const navigate = useNavigate();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [adminName, setAdminName] = useState<string>('');
  const [isAuthorized, setIsAuthorized] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  const [enrollments, setEnrollments] = useState<EnrollmentRecord[]>([]);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PENDING_REVIEW' | 'ACCEPTED' | 'REJECTED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRecord, setSelectedRecord] = useState<EnrollmentRecord | null>(null);
  const [actionMessage, setActionMessage] = useState('');

  // Check Authorization
  useEffect(() => {
    // Check session first
    const sessionRaw = sessionStorage.getItem('ketolune_admin_session');
    let sessionValid = false;
    if (sessionRaw) {
      try {
        const sess = JSON.parse(sessionRaw);
        if (APPROVED_ADMINS.some(a => a.email === sess.email)) {
          setAdminName(sess.name);
          setIsAuthorized(true);
          sessionValid = true;
          setLoading(false);
        }
      } catch {}
    }

    const unsub = subscribeToAuth((user) => {
      setCurrentUser(user);
      if (user && isAuthorizedAdmin(user)) {
        setIsAuthorized(true);
        setAdminName(getAdminName(user) || 'Administrator');
        setLoading(false);
      } else if (!sessionValid) {
        setIsAuthorized(false);
        setLoading(false);
      }
    });

    return () => unsub();
  }, []);

  // Load Enrollments
  useEffect(() => {
    if (isAuthorized) {
      fetchAllEnrollments().then((data) => {
        setEnrollments(data);
        if (data.length > 0 && !selectedRecord) {
          setSelectedRecord(data[0]);
        }
      });
    }
  }, [isAuthorized]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F7EFDF] flex items-center justify-center font-mono text-xs">
        VERIFYING ADMINISTRATOR PRIVILEGES...
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="min-h-screen bg-[#F7EFDF] flex items-center justify-center p-6 text-[#242322]">
        <div className="max-w-md bg-white p-8 rounded-3xl border border-red-200 shadow-xl text-center space-y-4">
          <Shield className="w-10 h-10 text-red-600 mx-auto" />
          <h2 className="font-condensed text-3xl uppercase font-bold text-[#242322]">
            ACCESS RESTRICTED
          </h2>
          <p className="text-xs font-sans text-[#242322]/80 leading-relaxed">
            Only authorized studio administrators may view this operational dashboard.
          </p>
          <button
            onClick={() => navigate('/admin/login')}
            className="px-6 py-2.5 bg-[#242322] text-[#F7EFDF] rounded-full text-xs font-mono uppercase font-bold"
          >
            Authenticate Admin
          </button>
        </div>
      </div>
    );
  }

  const handleStatusChange = async (id: string, newStatus: 'ACCEPTED' | 'REJECTED') => {
    setActionMessage('');
    const target = enrollments.find(e => e.id === id);
    if (!target) return;

    await updateEnrollmentStatus(id, newStatus, adminName);
    
    // Refresh list
    const updated = await fetchAllEnrollments();
    setEnrollments(updated);
    const updatedSelected = updated.find(e => e.id === id) || null;
    setSelectedRecord(updatedSelected);

    // If accepted, send email notification
    if (newStatus === 'ACCEPTED') {
      sendReservationEmail({
        to: target.giverEmail,
        recipientName: target.recipientName,
        orderId: target.id,
        tierTitle: `${target.selectedTier.toUpperCase()} Parcel Accepted`,
        estimatedDispatch: '7–8 Business Days upon selection',
      }).catch(() => {});
      setActionMessage(`Accepted enrollment for ${target.recipientName}. Acceptance email dispatched to ${target.giverEmail}.`);
    } else {
      setActionMessage(`Status updated to Rejected for ${target.recipientName}.`);
    }
  };

  const handleSignOut = async () => {
    sessionStorage.removeItem('ketolune_admin_session');
    await signOutUser();
    navigate('/admin/login');
  };

  // Filtered List
  const filteredEnrollments = enrollments.filter(item => {
    if (statusFilter !== 'ALL' && item.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.recipientName.toLowerCase().includes(q) ||
        item.giverEmail.toLowerCase().includes(q) ||
        item.id.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const acceptedCount = enrollments.filter(e => e.status === 'ACCEPTED').length;
  const pendingCount = enrollments.filter(e => e.status === 'PENDING_REVIEW').length;

  return (
    <div className="min-h-screen bg-[#F7EFDF] text-[#242322] font-sans selection:bg-[#E8F36B] selection:text-[#242322] pt-28 pb-32 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Top Operational Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#242322]/15 pb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#242322] text-[#F7EFDF] flex items-center justify-center font-bold font-mono text-sm shadow-md">
              <Shield className="w-5 h-5 text-[#E8F36B]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-condensed text-3xl sm:text-4xl uppercase tracking-tight text-[#242322] font-bold">
                  KETOLUNE STUDIO ATELIER
                </h1>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#E8F36B] text-[#242322] font-bold uppercase">
                  Curator: {adminName || 'Admin'}
                </span>
              </div>
              <p className="text-xs text-[#242322]/70 font-sans">
                Active studio administration & review session ({adminName})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/collections')}
              className="px-4 py-2 bg-white/80 border border-[#242322]/15 hover:bg-white text-[#242322] rounded-full text-xs font-mono font-bold uppercase transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>View Collections</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleSignOut}
              className="px-4 py-2 bg-[#242322] text-[#F7EFDF] hover:bg-[#A97849] rounded-full text-xs font-mono font-bold uppercase transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>

        {/* Studio Capacity & Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Card 1: 50 Members Monthly Cap */}
          <div className="p-5 bg-white/90 rounded-2xl border border-[#242322]/10 shadow-sm space-y-2">
            <div className="flex items-center justify-between text-xs font-mono text-[#A97849] font-bold">
              <span>MONTHLY ALLOTMENT CAP</span>
              <Users className="w-4 h-4" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="font-condensed text-4xl font-bold text-[#242322]">{acceptedCount}</span>
              <span className="text-xs font-mono text-[#242322]/60">/ 50 Approved</span>
            </div>
            {/* Progress bar */}
            <div className="w-full bg-[#242322]/10 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-[#242322] h-full rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, (acceptedCount / 50) * 100)}%` }}
              />
            </div>
            <p className="text-[11px] text-[#242322]/60 font-sans">
              Strict 50-member capacity protects slow craft quality.
            </p>
          </div>

          {/* Card 2: Pending Reviews */}
          <div className="p-5 bg-white/90 rounded-2xl border border-[#242322]/10 shadow-sm space-y-1">
            <div className="flex items-center justify-between text-xs font-mono text-[#A97849] font-bold">
              <span>PENDING REVIEWS</span>
              <Clock className="w-4 h-4" />
            </div>
            <div className="font-condensed text-4xl font-bold text-[#242322]">
              {pendingCount}
            </div>
            <p className="text-[11px] text-[#242322]/60 font-sans">
              Awaiting admin inspection & decision.
            </p>
          </div>

          {/* Card 3: 8 Curated Collections */}
          <div className="p-5 bg-white/90 rounded-2xl border border-[#242322]/10 shadow-sm space-y-1">
            <div className="flex items-center justify-between text-xs font-mono text-[#A97849] font-bold">
              <span>ACTIVE COLLECTIONS</span>
              <Package className="w-4 h-4" />
            </div>
            <div className="font-condensed text-4xl font-bold text-[#242322]">
              08
            </div>
            <p className="text-[11px] text-[#242322]/60 font-sans">
              4 Boys Collections • 4 Girls Collections.
            </p>
          </div>

          {/* Card 4: Standard Production Timeline */}
          <div className="p-5 bg-white/90 rounded-2xl border border-[#242322]/10 shadow-sm space-y-1">
            <div className="flex items-center justify-between text-xs font-mono text-[#A97849] font-bold">
              <span>PRODUCTION TIMELINE</span>
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="font-condensed text-3xl font-bold text-[#242322]">
              7–8 DAYS
            </div>
            <p className="text-[11px] text-[#242322]/60 font-sans">
              Preparation before dispatch (delivery additional).
            </p>
          </div>

        </div>

        {/* Action message banner */}
        {actionMessage && (
          <div className="p-4 bg-[#E8F36B] rounded-2xl border border-[#242322]/20 text-xs font-mono font-bold text-[#242322] flex items-center gap-2 animate-fade-in shadow-sm">
            <CheckCircle2 className="w-4 h-4" />
            <span>{actionMessage}</span>
          </div>
        )}

        {/* Main Work Area: Enrollment Management */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Filterable Submissions List */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* Filter Tabs & Search */}
            <div className="p-4 bg-white/90 rounded-2xl border border-[#242322]/10 shadow-sm space-y-3">
              <div className="flex items-center gap-2 bg-[#FAF7F2] p-2 rounded-xl border border-[#242322]/10">
                <Search className="w-4 h-4 text-[#242322]/40 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search recipient, email, ID..."
                  className="w-full bg-transparent text-xs font-mono outline-none text-[#242322]"
                />
              </div>

              {/* Status Tabs */}
              <div className="flex items-center gap-1 text-[11px] font-mono">
                {(['ALL', 'PENDING_REVIEW', 'ACCEPTED', 'REJECTED'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setStatusFilter(tab)}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      statusFilter === tab
                        ? 'bg-[#242322] text-[#F7EFDF] font-bold'
                        : 'text-[#242322]/70 hover:bg-[#242322]/5'
                    }`}
                  >
                    {tab === 'ALL' ? 'All' : tab === 'PENDING_REVIEW' ? 'Pending' : tab === 'ACCEPTED' ? 'Accepted' : 'Rejected'}
                  </button>
                ))}
              </div>
            </div>

            {/* List */}
            <div className="space-y-2.5 max-h-[620px] overflow-y-auto pr-1">
              {filteredEnrollments.map((rec) => {
                const isSelected = selectedRecord?.id === rec.id;
                return (
                  <div
                    key={rec.id}
                    onClick={() => setSelectedRecord(rec)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-white border-[#242322] shadow-md ring-2 ring-[#A97849]/50'
                        : 'bg-white/70 border-[#242322]/10 hover:bg-white hover:border-[#242322]/25'
                    }`}
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-condensed text-xl uppercase font-bold text-[#242322]">
                          {rec.recipientName}
                        </span>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#FAF7F2] text-[#A97849] uppercase">
                          {rec.recipientCategory || 'Path'}
                        </span>
                      </div>
                      <div className="text-[11px] font-mono text-[#242322]/60">
                        {rec.id} • by {rec.giverName}
                      </div>
                    </div>

                    <div className="shrink-0 text-right">
                      <span className={`text-[10px] font-mono font-bold uppercase px-2.5 py-1 rounded-full ${
                        rec.status === 'ACCEPTED'
                          ? 'bg-[#E8F36B] text-[#242322]'
                          : rec.status === 'PENDING_REVIEW'
                          ? 'bg-[#FAF7F2] border border-[#A97849]/30 text-[#A97849]'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {rec.status === 'PENDING_REVIEW' ? 'Pending' : rec.status}
                      </span>
                    </div>
                  </div>
                );
              })}

              {filteredEnrollments.length === 0 && (
                <div className="p-8 text-center bg-white/60 rounded-2xl text-xs font-mono text-[#242322]/60">
                  No submissions match filter.
                </div>
              )}
            </div>

          </div>

          {/* Right Column: Detailed Review & Admin Decision Console */}
          <div className="lg:col-span-7">
            {selectedRecord ? (
              <div className="p-6 sm:p-8 bg-white/95 rounded-3xl border border-[#242322]/15 shadow-xl space-y-6">
                
                {/* Header */}
                <div className="flex items-start justify-between border-b border-[#242322]/10 pb-4">
                  <div className="space-y-1">
                    <span className="text-xs font-mono uppercase text-[#A97849] font-bold">
                      Submission Inspection: {selectedRecord.id}
                    </span>
                    <h3 className="font-condensed text-4xl uppercase tracking-tight text-[#242322] font-bold">
                      {selectedRecord.recipientName}
                    </h3>
                    <p className="text-xs font-mono text-[#242322]/70">
                      Giver: {selectedRecord.giverName} ({selectedRecord.giverEmail})
                    </p>
                  </div>

                  <div className="text-right space-y-1">
                    <span className="text-[11px] font-mono text-[#242322]/60 block">
                      Submitted: {new Date(selectedRecord.createdAt).toLocaleDateString()}
                    </span>
                    <span className={`inline-block text-xs font-mono font-bold uppercase px-3 py-1 rounded-full ${
                      selectedRecord.status === 'ACCEPTED'
                        ? 'bg-[#E8F36B] text-[#242322]'
                        : selectedRecord.status === 'PENDING_REVIEW'
                        ? 'bg-[#FAF7F2] border border-[#A97849]/30 text-[#A97849]'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {selectedRecord.status}
                    </span>
                  </div>
                </div>

                {/* Answers / Observations */}
                <div className="space-y-4">
                  <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                    Recipient Observations
                  </div>

                  <div className="p-4 bg-[#FAF7F2] rounded-2xl border border-[#242322]/10 space-y-1">
                    <span className="text-[10px] font-mono text-[#A97849] font-bold">01 — WHO THEY ARE TO GIVER</span>
                    <p className="text-xs font-sans text-[#242322] leading-relaxed">
                      {selectedRecord.q1}
                    </p>
                  </div>

                  <div className="p-4 bg-[#FAF7F2] rounded-2xl border border-[#242322]/10 space-y-1">
                    <span className="text-[10px] font-mono text-[#A97849] font-bold">02 — WHAT THEY'RE LIKE (PRIVATE HABITS & SENSORY PALETTE)</span>
                    <p className="text-xs font-sans text-[#242322] leading-relaxed">
                      {selectedRecord.q2}
                    </p>
                  </div>

                  <div className="p-4 bg-[#FAF7F2] rounded-2xl border border-[#242322]/10 space-y-1">
                    <span className="text-[10px] font-mono text-[#A97849] font-bold">03 — UNSPOKEN TRUTH / WISH THEY KNEW</span>
                    <p className="text-xs font-sans text-[#242322] leading-relaxed">
                      {selectedRecord.q3}
                    </p>
                  </div>

                  {selectedRecord.extraNote && (
                    <div className="p-4 bg-white rounded-2xl border border-[#242322]/15 space-y-1">
                      <span className="text-[10px] font-mono text-[#A97849] font-bold">CUSTOM NOTE / SENSITIVITY PREFERENCE:</span>
                      <p className="text-xs font-serif italic text-[#242322] leading-relaxed">
                        "{selectedRecord.extraNote}"
                      </p>
                    </div>
                  )}

                  {selectedRecord.attachmentUrl && (
                    <div className="p-3 bg-[#FAF7F2] rounded-xl flex items-center justify-between text-xs font-mono">
                      <span>Attached Keepsake File Available</span>
                      <a 
                        href={selectedRecord.attachmentUrl} 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-[#A97849] underline font-bold"
                      >
                        View Attachment ↗
                      </a>
                    </div>
                  )}
                </div>

                {/* Curator Decision Console */}
                <div className="pt-4 border-t border-[#242322]/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono uppercase text-[#A97849] font-bold">
                      Curator Decision Action:
                    </span>
                    {selectedRecord.adminDecisionBy && (
                      <span className="text-[11px] font-mono text-[#242322]/60">
                        Previously decided by {selectedRecord.adminDecisionBy}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => handleStatusChange(selectedRecord.id, 'ACCEPTED')}
                      className="py-3.5 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-2xl text-xs font-mono uppercase font-bold tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                    >
                      <CheckCircle2 className="w-4 h-4 text-[#E8F36B]" />
                      <span>Accept & Send Invitation</span>
                    </button>

                    <button
                      onClick={() => handleStatusChange(selectedRecord.id, 'REJECTED')}
                      className="py-3.5 bg-white border border-red-300 hover:bg-red-50 text-red-700 rounded-2xl text-xs font-mono uppercase font-bold tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <XCircle className="w-4 h-4 text-red-600" />
                      <span>Mark Full / Reject</span>
                    </button>
                  </div>
                </div>

              </div>
            ) : (
              <div className="p-12 text-center bg-white/70 rounded-3xl border border-[#242322]/10 text-xs font-mono text-[#242322]/60">
                Select an enrollment on the left to review observations.
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
