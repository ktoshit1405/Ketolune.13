import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { fetchAllEnrollments, EnrollmentRecord } from '../services/adminAuth';
import { getStoredClientSession } from '../services/firebase';
import { ArrowLeft, ArrowRight, CheckCircle2, Clock, AlertCircle, Sparkles, User, Package, Mail, Search, Lock } from 'lucide-react';
import { CURRENT_BATCH } from '../data/batchData';

export default function AccountPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const enrolledIdParam = searchParams.get('enrolledId');

  const [activeClient, setActiveClient] = useState(getStoredClientSession());
  const [allEnrollments, setAllEnrollments] = useState<EnrollmentRecord[]>([]);
  const [userEnrollments, setUserEnrollments] = useState<EnrollmentRecord[]>([]);
  const [selectedRecord, setSelectedRecord] = useState<EnrollmentRecord | null>(null);
  const [searchId, setSearchId] = useState(enrolledIdParam || '');
  const [lookupAttempted, setLookupAttempted] = useState(false);

  useEffect(() => {
    const handleAuthChange = () => {
      setActiveClient(getStoredClientSession());
    };
    window.addEventListener('ketolune_auth_change', handleAuthChange);
    return () => window.removeEventListener('ketolune_auth_change', handleAuthChange);
  }, []);

  useEffect(() => {
    fetchAllEnrollments().then((data) => {
      setAllEnrollments(data);

      const client = getStoredClientSession();
      if (client?.email) {
        const clientEmail = client.email.toLowerCase().trim();
        const clientRecords = data.filter((r) => r.giverEmail.toLowerCase().trim() === clientEmail);
        setUserEnrollments(clientRecords);

        if (enrolledIdParam) {
          const matchParam = data.find((r) => r.id.toLowerCase() === enrolledIdParam.toLowerCase().trim());
          if (matchParam) {
            setSelectedRecord(matchParam);
            return;
          }
        }
        if (clientRecords.length > 0) {
          setSelectedRecord(clientRecords[0]);
          return;
        }
      }

      if (enrolledIdParam) {
        const matchParam = data.find((r) => r.id.toLowerCase() === enrolledIdParam.toLowerCase().trim());
        if (matchParam) {
          setSelectedRecord(matchParam);
        }
      }
    });
  }, [enrolledIdParam]);

  const handleLookup = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLookupAttempted(true);
    const query = searchId.trim().toLowerCase();
    if (!query) {
      setSelectedRecord(null);
      return;
    }

    const found = allEnrollments.find(
      (r) => r.id.toLowerCase() === query || r.giverEmail.toLowerCase() === query
    );
    setSelectedRecord(found || null);
  };

  return (
    <div className="min-h-screen bg-[#F7EFDF] text-[#242322] font-sans selection:bg-[#E8F36B] selection:text-[#242322] pt-28 pb-32 px-4 sm:px-6">
      <div className="max-w-4xl mx-auto space-y-10">
        
        {/* Header */}
        <div className="border-b border-[#242322]/15 pb-6 space-y-3">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-xs font-mono uppercase text-[#242322]/70 hover:text-[#242322] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Storefront</span>
          </button>

          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-4">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                Client Portal
              </span>
              <h1 className="font-condensed text-4xl sm:text-6xl uppercase tracking-tight text-[#242322] font-bold mt-1">
                ENROLLMENT & STATUS
              </h1>
            </div>

            <div className="text-xs font-mono text-[#242322]/70">
              Capacity: <span className="font-bold text-[#A97849]">50 Monthly Members</span>
            </div>
          </div>
        </div>

        {/* Private Lookup bar */}
        <form onSubmit={handleLookup} className="p-4 bg-white/80 rounded-2xl border border-[#242322]/15 shadow-sm flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <input
              type="text"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              placeholder="Search by Enrollment ID (e.g. ENR-8821) or your email..."
              className="w-full pl-9 pr-4 py-2.5 bg-white border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none focus:border-[#242322]"
            />
            <Search className="w-4 h-4 text-[#242322]/40 absolute left-3 top-3" />
          </div>
          <button
            type="submit"
            className="w-full sm:w-auto px-6 py-2.5 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-xl text-xs font-mono font-bold uppercase transition-colors cursor-pointer"
          >
            Find Enrollment
          </button>
        </form>

        {/* Active Client Submissions Switcher (Only visible to the logged-in client) */}
        {activeClient && userEnrollments.length > 0 && (
          <div className="p-5 bg-white/70 rounded-2xl border border-[#242322]/10 space-y-2">
            <span className="text-xs font-mono uppercase text-[#A97849] font-bold">
              Your Enrolled Submissions ({userEnrollments.length})
            </span>
            <div className="flex flex-wrap gap-2">
              {userEnrollments.map((rec) => (
                <button
                  key={rec.id}
                  onClick={() => setSelectedRecord(rec)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-mono transition-all cursor-pointer ${
                    selectedRecord?.id === rec.id
                      ? 'bg-[#242322] text-[#F7EFDF] font-bold'
                      : 'bg-white border border-[#242322]/15 text-[#242322]/70 hover:bg-white'
                  }`}
                >
                  {rec.recipientName} ({rec.id} • {rec.status})
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Status Card */}
        {selectedRecord ? (
          <div className="p-8 sm:p-10 bg-white/95 rounded-3xl border border-[#242322]/15 shadow-xl space-y-8 animate-fade-in">
            
            {/* Status Indicator Banner */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#242322]/10">
              <div className="space-y-1">
                <span className="text-[11px] font-mono text-[#242322]/60 uppercase">
                  RECORD ID: <strong className="text-[#242322]">{selectedRecord.id}</strong>
                </span>
                <h3 className="font-condensed text-3xl sm:text-4xl uppercase tracking-tight text-[#242322] font-bold">
                  {selectedRecord.recipientName}
                </h3>
                <p className="text-xs text-[#242322]/70 font-sans">
                  Enrolled by {selectedRecord.giverName} ({selectedRecord.giverEmail})
                </p>
              </div>

              {/* Status Badge */}
              <div>
                {selectedRecord.status === 'ACCEPTED' && (
                  <div className="px-4 py-2 rounded-full bg-[#E8F36B] border border-[#242322]/20 text-[#242322] flex items-center gap-2 text-xs font-mono font-bold uppercase">
                    <CheckCircle2 className="w-4 h-4 text-[#242322]" />
                    <span>ENROLLMENT ACCEPTED</span>
                  </div>
                )}
                {selectedRecord.status === 'PENDING_REVIEW' && (
                  <div className="px-4 py-2 rounded-full bg-[#FAF7F2] border border-[#A97849]/30 text-[#A97849] flex items-center gap-2 text-xs font-mono font-bold uppercase">
                    <Clock className="w-4 h-4 text-[#A97849]" />
                    <span>PENDING STUDIO REVIEW</span>
                  </div>
                )}
                {selectedRecord.status === 'REJECTED' && (
                  <div className="px-4 py-2 rounded-full bg-[#FEE2E2] border border-red-300 text-red-800 flex items-center gap-2 text-xs font-mono font-bold uppercase">
                    <AlertCircle className="w-4 h-4 text-red-700" />
                    <span>ALLOTMENT FULL</span>
                  </div>
                )}
              </div>
            </div>

            {/* Dynamic Content Based On Status */}
            {selectedRecord.status === 'ACCEPTED' && (
              <div className="p-6 bg-[#FAF7F2] rounded-2xl border-l-4 border-[#242322] space-y-4">
                <div className="space-y-1">
                  <div className="text-xs font-mono font-bold uppercase text-[#A97849]">
                    Studio Curator Decision
                  </div>
                  <h4 className="font-condensed text-2xl uppercase tracking-tight text-[#242322] font-bold">
                    You Are Approved for This Allotment
                  </h4>
                  <p className="text-xs sm:text-sm text-[#242322]/85 font-sans leading-relaxed">
                    Our atelier team reviewed your observations. You are invited to explore the tailored collections, choose your interest niche, and complete reservation.
                  </p>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                  <button
                    onClick={() => navigate(`/collections?path=${selectedRecord.recipientCategory || 'girls'}`)}
                    className="w-full sm:w-auto px-8 py-3.5 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Discover Collections for {selectedRecord.recipientName}</span>
                    <ArrowRight className="w-4 h-4 text-[#E8F36B]" />
                  </button>
                  <span className="text-xs font-mono text-[#242322]/60">
                    Reviewed by studio curator {selectedRecord.adminDecisionBy || 'atelier team'}
                  </span>
                </div>
              </div>
            )}

            {selectedRecord.status === 'PENDING_REVIEW' && (
              <div className="p-6 bg-[#FAF7F2] rounded-2xl border-l-4 border-[#A97849] space-y-3">
                <div className="space-y-1">
                  <div className="text-xs font-mono font-bold uppercase text-[#A97849]">
                    Curatorial Review in Progress
                  </div>
                  <h4 className="font-condensed text-2xl uppercase tracking-tight text-[#242322] font-bold">
                    Reviewing Your Observations
                  </h4>
                  <p className="text-xs sm:text-sm text-[#242322]/85 font-sans leading-relaxed">
                    To preserve our deliberate, slow handmade craft ("Made slowly. Meant personally."), we accept only 50 members each month. Our administrators are currently reviewing your answers to ensure our workshop can craft a truly meaningful surprise.
                  </p>
                </div>

                <div className="p-3.5 bg-white rounded-xl text-xs font-mono text-[#242322]/70 flex items-center gap-2">
                  <Mail className="w-4 h-4 text-[#A97849]" />
                  <span>A decision notification will be sent to <strong>{selectedRecord.giverEmail}</strong>.</span>
                </div>
              </div>
            )}

            {selectedRecord.status === 'REJECTED' && (
              <div className="p-6 bg-red-50/60 rounded-2xl border-l-4 border-red-400 space-y-2">
                <div className="text-xs font-mono font-bold uppercase text-red-800">
                  Monthly Capacity Reached
                </div>
                <h4 className="font-condensed text-2xl uppercase tracking-tight text-red-950 font-bold">
                  Allotment Full
                </h4>
                <p className="text-xs sm:text-sm text-red-900/80 font-sans leading-relaxed">
                  Our 50-member limit for this month has been filled. We have placed your answers on priority reserve for next month's opening.
                </p>
              </div>
            )}

            {/* Recipient Nuances Recorded */}
            <div className="space-y-4 pt-2">
              <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                Client Observations on File
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-[#FAF7F2] rounded-2xl space-y-1">
                  <span className="text-[10px] font-mono text-[#A97849] font-bold">01 — RELATION</span>
                  <p className="text-xs font-sans text-[#242322]/80 leading-relaxed italic">
                    "{selectedRecord.q1}"
                  </p>
                </div>
                <div className="p-4 bg-[#FAF7F2] rounded-2xl space-y-1">
                  <span className="text-[10px] font-mono text-[#A97849] font-bold">02 — WHAT THEY'RE LIKE</span>
                  <p className="text-xs font-sans text-[#242322]/80 leading-relaxed italic">
                    "{selectedRecord.q2}"
                  </p>
                </div>
                <div className="p-4 bg-[#FAF7F2] rounded-2xl space-y-1">
                  <span className="text-[10px] font-mono text-[#A97849] font-bold">03 — UNSPOKEN TRUTH</span>
                  <p className="text-xs font-sans text-[#242322]/80 leading-relaxed italic">
                    "{selectedRecord.q3}"
                  </p>
                </div>
              </div>
            </div>

          </div>
        ) : (
          <div className="p-12 text-center bg-white/80 rounded-3xl border border-[#242322]/10 space-y-4">
            <User className="w-10 h-10 text-[#A97849] mx-auto" />
            <h3 className="font-condensed text-3xl uppercase text-[#242322] font-bold">
              {lookupAttempted ? 'No Matching Enrollment Found' : 'Check Enrollment Status'}
            </h3>
            <p className="text-xs text-[#242322]/70 max-w-sm mx-auto font-sans">
              {lookupAttempted 
                ? 'Please check your Enrollment ID (e.g. ENR-8821) or email address and try again.'
                : 'Enter your Enrollment ID or registered email address above to view your review status.'}
            </p>
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => navigate('/enroll')}
                className="px-6 py-2.5 bg-[#242322] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider hover:bg-[#A97849] transition-colors"
              >
                Enroll a Recipient Now
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
