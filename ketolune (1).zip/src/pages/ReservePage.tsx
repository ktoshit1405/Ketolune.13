import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { CURATED_COLLECTIONS } from '../data/collectionsData';
import { CURRENT_BATCH, CUSTOMIZATION_OPTIONS, BatchTier } from '../data/batchData';
import { Lock, ArrowLeft, ArrowRight, CheckCircle2, ShieldCheck, QrCode, CreditCard, Building, Banknote, Sparkles } from 'lucide-react';
import { saveReservation, getStoredClientSession } from '../services/firebase';
import { sendReservationEmail } from '../services/email';

export default function ReservePage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const collectionId = searchParams.get('collection') || 'botanical-herbarium';
  const tierId = (searchParams.get('tier') as 'mini' | 'medium' | 'large') || 'medium';
  const interestId = searchParams.get('interest');

  const selectedCollection = CURATED_COLLECTIONS.find((c) => c.id === collectionId) || CURATED_COLLECTIONS[0];
  const selectedTier = CURRENT_BATCH.tiers.find((t) => t.id === tierId) || CURRENT_BATCH.tiers[1];

  const activeClient = getStoredClientSession();

  // Form State
  const [recipientName, setRecipientName] = useState('Elena Rostova');
  const [giverName, setGiverName] = useState(activeClient?.name || '');
  const [giverEmail, setGiverEmail] = useState(activeClient?.email || '');
  const [addressLine, setAddressLine] = useState('42 Meadowbrook Crescent, Indiranagar');
  const [city, setCity] = useState('Bengaluru');
  const [state, setState] = useState('Karnataka');
  const [postalCode, setPostalCode] = useState('560038');

  // Personal Touch add-on (increments of ₹50: 0, 50, 100, 150, 200)
  const [personalTouchAmount, setPersonalTouchAmount] = useState<number>(50);

  // Customization
  const [selectedAroma, setSelectedAroma] = useState(CUSTOMIZATION_OPTIONS.aroma[0].label);
  const [selectedCeramic, setSelectedCeramic] = useState(CUSTOMIZATION_OPTIONS.ceramicFinish[0].label);
  const [selectedRibbon, setSelectedRibbon] = useState(CUSTOMIZATION_OPTIONS.ribbonColor[0].label);
  const [selectedWaxSeal, setSelectedWaxSeal] = useState(CUSTOMIZATION_OPTIONS.waxSealColor[0].label);
  const [noteText, setNoteText] = useState('To the one who notices the quietest light at dusk. May this little weight bring your mornings stillness.');

  // Payment
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking' | 'cod'>('upi');
  const [upiId, setUpiId] = useState('giver@okhdfcbank');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Pricing Calculation
  const basePrice = selectedTier.priceINR;
  const deliveryFee = CURRENT_BATCH.deliveryFeeINR; // Approved ₹19
  const grandTotal = basePrice + deliveryFee + personalTouchAmount;

  const handlePersonalTouchIncrement = (amount: number) => {
    // Validated in ₹50 increments
    if (amount >= 0 && amount <= 500 && amount % 50 === 0) {
      setPersonalTouchAmount(amount);
    }
  };

  const handleCompleteReservation = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const generatedOrderId = `KL-${Math.floor(1000 + Math.random() * 9000)}`;

    try {
      // 1. Save to Firebase Firestore
      await saveReservation({
        orderId: generatedOrderId,
        recipientName,
        giverName,
        giverEmail,
        collectionId: selectedCollection.id,
        collectionTitle: selectedCollection.title,
        interestId,
        tierName: selectedTier.customerFacingName,
        tierPriceINR: basePrice,
        deliveryFeeINR: deliveryFee,
        personalTouchINR: personalTouchAmount,
        grandTotalINR: grandTotal,
        customization: {
          aroma: selectedAroma,
          ceramicFinish: selectedCeramic,
          ribbon: selectedRibbon,
          waxSeal: selectedWaxSeal,
        },
        personalNote: noteText,
        shippingAddress: {
          addressLine,
          city,
          state,
          postalCode,
        },
        paymentMethod,
        paymentStatus: 'AUTHORIZED',
        status: 'STUDIO_PREPARATION',
      });

      // 2. Dispatch via Resend Email
      await sendReservationEmail({
        to: giverEmail,
        recipientName,
        orderId: generatedOrderId,
        tierTitle: selectedTier.customerFacingName,
        estimatedDispatch: '7–8 Business Days',
      });
    } catch (err) {
      console.warn('Reservation save note:', err);
    } finally {
      setIsSubmitting(false);
      navigate(`/orders?orderId=${generatedOrderId}`);
    }
  };

  return (
    <div className="min-h-screen bg-[#F7EFDF] text-[#242322] font-sans selection:bg-[#E8F36B] selection:text-[#242322] pt-28 pb-32 px-4 sm:px-6">
      <div className="max-w-5xl mx-auto space-y-10">
        
        {/* Top Back Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate('/collections')}
            className="flex items-center gap-2 text-xs font-mono uppercase text-[#242322]/70 hover:text-[#242322] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Collections</span>
          </button>

          <div className="flex items-center gap-2 text-xs font-mono text-[#A97849] font-bold uppercase">
            <Lock className="w-3.5 h-3.5" />
            <span>Secure Studio Reservation</span>
          </div>
        </div>

        {/* Heading */}
        <div className="border-b border-[#242322]/15 pb-6 space-y-2">
          <h1 className="font-condensed text-4xl sm:text-6xl uppercase tracking-tight text-[#242322] font-bold">
            CONFIRM YOUR RESERVATION
          </h1>
          <p className="text-sm sm:text-base text-[#242322]/80 font-sans max-w-xl">
            Selected: <span className="font-bold text-[#242322]">{selectedCollection.title}</span> ({selectedCollection.path.toUpperCase()}) • <span className="font-bold text-[#242322]">{selectedTier.customerFacingName}</span> (₹{basePrice})
          </p>
        </div>

        <form onSubmit={handleCompleteReservation} className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Left Column: Personalisation, Shipping & Payment */}
          <div className="lg:col-span-7 space-y-8">
            
            {/* 1. Recipient & Occasion Details */}
            <div className="p-6 bg-white/80 rounded-3xl border border-[#242322]/10 shadow-sm space-y-4">
              <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                01. Recipient & Giver Details
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">
                    Recipient Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none focus:border-[#242322]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">
                    Your Name (Giver)
                  </label>
                  <input
                    type="text"
                    required
                    value={giverName}
                    onChange={(e) => setGiverName(e.target.value)}
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none focus:border-[#242322]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">
                  Your Email (for status & booking receipt)
                </label>
                <input
                  type="email"
                  required
                  value={giverEmail}
                  onChange={(e) => setGiverEmail(e.target.value)}
                  placeholder="e.g. yourname@example.com"
                  className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none focus:border-[#242322]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">
                  Delivery Address & Flat
                </label>
                <input
                  type="text"
                  required
                  value={addressLine}
                  onChange={(e) => setAddressLine(e.target.value)}
                  className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none focus:border-[#242322]"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">City</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">State</label>
                  <input
                    type="text"
                    required
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-sans text-[#242322] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase text-[#242322]/70 mb-1">PIN Code</label>
                  <input
                    type="text"
                    required
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none"
                  />
                </div>
              </div>
            </div>

            {/* 2. Personal Dedication Note */}
            <div className="p-6 bg-white/80 rounded-3xl border border-[#242322]/10 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                  02. Archival Inscription Note
                </div>
                <span className="text-[11px] font-mono text-[#242322]/50">Dip-pen cotton rag</span>
              </div>
              <p className="text-xs text-[#242322]/70 font-sans">
                Inscribed word-for-word by hand onto heavy cotton paper with archival ink and sealed with personal wax.
              </p>
              <textarea
                rows={3}
                required
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                className="w-full p-4 bg-white border border-[#242322]/15 rounded-2xl text-xs font-serif italic text-[#242322] focus:border-[#242322] outline-none leading-relaxed resize-none"
              />
            </div>

            {/* 3. Personal Touch Add-on (₹50 increments) */}
            <div className="p-6 bg-white/80 rounded-3xl border border-[#242322]/10 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>03. Personal Touch Add-on</span>
                </div>
                <span className="text-xs font-mono font-bold text-[#242322]">
                  + ₹{personalTouchAmount}
                </span>
              </div>
              <p className="text-xs text-[#242322]/75 font-sans leading-relaxed">
                Add an extra handcrafted detail, extended handwritten letter, or direct artisan appreciation in verified increments of ₹50.
              </p>

              {/* Increments buttons */}
              <div className="grid grid-cols-5 gap-2">
                {[0, 50, 100, 150, 200].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => handlePersonalTouchIncrement(amt)}
                    className={`py-2 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                      personalTouchAmount === amt
                        ? 'bg-[#242322] text-[#F7EFDF] shadow-md'
                        : 'bg-white border border-[#242322]/15 text-[#242322]/70 hover:bg-white/80'
                    }`}
                  >
                    {amt === 0 ? 'None' : `+ ₹${amt}`}
                  </button>
                ))}
              </div>
            </div>

            {/* 4. Payment Method */}
            <div className="p-6 bg-white/80 rounded-3xl border border-[#242322]/10 shadow-sm space-y-4">
              <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                04. Payment Method
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-3 rounded-xl border text-xs font-mono flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'upi'
                      ? 'border-[#242322] bg-white text-[#242322] font-bold shadow-sm'
                      : 'border-[#242322]/15 bg-white/50 text-[#242322]/60'
                  }`}
                >
                  <QrCode className="w-4 h-4 text-[#A97849]" />
                  <span>UPI / QR</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-xl border text-xs font-mono flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'card'
                      ? 'border-[#242322] bg-white text-[#242322] font-bold shadow-sm'
                      : 'border-[#242322]/15 bg-white/50 text-[#242322]/60'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-[#A97849]" />
                  <span>Card</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('netbanking')}
                  className={`p-3 rounded-xl border text-xs font-mono flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'netbanking'
                      ? 'border-[#242322] bg-white text-[#242322] font-bold shadow-sm'
                      : 'border-[#242322]/15 bg-white/50 text-[#242322]/60'
                  }`}
                >
                  <Building className="w-4 h-4 text-[#A97849]" />
                  <span>NetBanking</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('cod')}
                  className={`p-3 rounded-xl border text-xs font-mono flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-all ${
                    paymentMethod === 'cod'
                      ? 'border-[#242322] bg-white text-[#242322] font-bold shadow-sm'
                      : 'border-[#242322]/15 bg-white/50 text-[#242322]/60'
                  }`}
                >
                  <Banknote className="w-4 h-4 text-[#A97849]" />
                  <span>COD Reserve</span>
                </button>
              </div>

              {paymentMethod === 'upi' && (
                <div>
                  <label className="block text-xs font-mono text-[#242322]/70 mb-1">
                    Virtual Payment Address (VPA / UPI ID)
                  </label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="e.g. username@okhdfcbank"
                    className="w-full p-3 bg-white border border-[#242322]/15 rounded-xl text-xs font-mono text-[#242322] outline-none"
                  />
                </div>
              )}
            </div>

          </div>

          {/* Right Column: Reservation Summary & Transparent Pricing */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="p-6 bg-white/90 border border-[#242322]/15 rounded-3xl space-y-5 shadow-lg">
              <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold border-b border-[#242322]/10 pb-3">
                Transparent Reservation Breakdown
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-start text-xs font-mono">
                  <div className="space-y-0.5">
                    <span className="font-bold text-[#242322]">{selectedTier.customerFacingName}</span>
                    <p className="text-[11px] text-[#242322]/60 font-sans">{selectedCollection.title}</p>
                  </div>
                  <span className="font-bold text-[#242322]">₹{basePrice}</span>
                </div>

                <div className="flex justify-between text-xs font-mono text-[#242322]/75">
                  <span>Standard Tracked Courier Delivery</span>
                  <span>₹{deliveryFee}</span>
                </div>

                {personalTouchAmount > 0 && (
                  <div className="flex justify-between text-xs font-mono text-[#242322]/75">
                    <span>Personal Touch Add-on</span>
                    <span>₹{personalTouchAmount}</span>
                  </div>
                )}

                <div className="pt-3 border-t border-[#242322]/10 flex justify-between items-baseline text-base font-mono font-bold text-[#242322]">
                  <span>Total Payable</span>
                  <span className="text-xl text-[#A97849]">₹{grandTotal}</span>
                </div>
              </div>

              {/* Exact Production Timeline Policy */}
              <div className="p-4 bg-[#FAF7F2] rounded-2xl border-l-4 border-[#A97849] space-y-1.5 text-xs">
                <div className="font-mono font-bold text-[#A97849] uppercase">
                  Accurate Studio Fulfillment Policy
                </div>
                <p className="text-[#242322]/85 font-sans leading-relaxed font-medium">
                  Preparation takes approximately 7–8 business days before dispatch. Delivery time is additional and depends on your location.
                </p>
                <p className="text-[11px] text-[#242322]/60 font-sans">
                  Because each parcel is handmade around your recipient's nuance, orders cannot be cancelled once production begins.
                </p>
              </div>

              {/* Authorize & Reserve CTA */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] text-xs font-bold uppercase tracking-wider rounded-full transition-all flex items-center justify-center gap-2.5 cursor-pointer shadow-xl hover:scale-105 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>AUTHORIZING RESERVATION...</span>
                ) : (
                  <>
                    <span>CONFIRM & BOOK GIFT (₹{grandTotal})</span>
                    <ArrowRight className="w-4 h-4 text-[#E8F36B]" />
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] font-mono text-[#242322]/60">
                <ShieldCheck className="w-3.5 h-3.5 text-[#A97849]" />
                <span>Genuine Handcrafted Gifting • Zero Warehouse Slop</span>
              </div>
            </div>

          </div>

        </form>

      </div>
    </div>
  );
}
