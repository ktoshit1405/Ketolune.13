import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { signInWithGoogle, signOutUser, subscribeToAuth, authenticateWithCredentials } from '../services/firebase';
import { isAuthorizedAdmin } from '../services/adminAuth';
import { Shield, Lock, LogIn, ArrowLeft, AlertTriangle, Eye, EyeOff, User as UserIcon, Mail, KeyRound } from 'lucide-react';
import { User } from 'firebase/auth';

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Form input fields
  const [nameInput, setNameInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    // Check if admin session already exists
    const sessionRaw = sessionStorage.getItem('ketolune_admin_session');
    if (sessionRaw) {
      try {
        const sess = JSON.parse(sessionRaw);
        if (sess?.email) {
          navigate('/admin');
          return;
        }
      } catch {}
    }

    const unsub = subscribeToAuth((user) => {
      setCurrentUser(user);
      if (user && isAuthorizedAdmin(user)) {
        navigate('/admin');
      }
    });
    return () => unsub();
  }, [navigate]);

  const handleCredentialsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    try {
      const res = await authenticateWithCredentials(nameInput, emailInput, passwordInput);
      // Valid credentials verified
      navigate('/admin');
    } catch (err: any) {
      setErrorMsg(err.message || 'Invalid administrator credentials. Please check your name, email, and password.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const user = await signInWithGoogle();
      if (isAuthorizedAdmin(user)) {
        navigate('/admin');
      } else {
        await signOutUser();
        setErrorMsg(`Access Denied: ${user.email} is not an authorized KETOLUNE administrator.`);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Authentication failed or popup closed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F7EFDF] text-[#242322] font-sans selection:bg-[#E8F36B] selection:text-[#242322] flex items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-md bg-white/95 rounded-3xl border border-[#242322]/15 shadow-2xl p-8 sm:p-10 space-y-6 text-center">
        
        {/* Top return */}
        <div className="flex justify-start">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-xs font-mono uppercase text-[#242322]/60 hover:text-[#242322] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Storefront</span>
          </button>
        </div>

        {/* Shield Icon */}
        <div className="space-y-3">
          <div className="w-14 h-14 rounded-full bg-[#FAF7F2] border border-[#A97849]/30 flex items-center justify-center mx-auto text-[#A97849] shadow-sm">
            <Shield className="w-7 h-7" />
          </div>
          <div>
            <span className="text-[11px] font-mono uppercase tracking-widest text-[#A97849] font-bold">
              Restricted Operations
            </span>
            <h1 className="font-condensed text-3xl sm:text-4xl uppercase tracking-tight text-[#242322] font-bold mt-1">
              ADMINISTRATOR LOGIN
            </h1>
          </div>
          <p className="text-xs text-[#242322]/70 font-sans leading-relaxed">
            Strict verification required. Enter your registered administrator credentials to access the studio console.
          </p>
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-2xl text-xs text-red-800 text-left space-y-1">
            <div className="flex items-center gap-1.5 font-bold font-mono">
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
              <span>UNAUTHORIZED IDENTITY</span>
            </div>
            <p className="leading-relaxed">{errorMsg}</p>
          </div>
        )}

        {/* Credentials Login Form */}
        <form onSubmit={handleCredentialsSubmit} className="space-y-4 text-left">
          
          {/* Name Input */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-mono uppercase tracking-wider text-[#A97849] font-bold">
              Administrator Name
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                placeholder="Enter administrator name"
                className="w-full pl-10 pr-4 py-3 bg-[#FAF7F2] rounded-2xl border border-[#242322]/15 text-xs text-[#242322] placeholder:text-[#242322]/35 focus:outline-none focus:border-[#A97849] focus:ring-1 focus:ring-[#A97849] transition-all font-sans"
              />
              <UserIcon className="w-4 h-4 text-[#242322]/40 absolute left-3.5 top-3.5" />
            </div>
          </div>

          {/* Email Input */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-mono uppercase tracking-wider text-[#A97849] font-bold">
              Registered Email
            </label>
            <div className="relative">
              <input
                type="email"
                required
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                placeholder="e.g. name@example.com"
                className="w-full pl-10 pr-4 py-3 bg-[#FAF7F2] rounded-2xl border border-[#242322]/15 text-xs text-[#242322] placeholder:text-[#242322]/35 focus:outline-none focus:border-[#A97849] focus:ring-1 focus:ring-[#A97849] transition-all font-sans"
              />
              <Mail className="w-4 h-4 text-[#242322]/40 absolute left-3.5 top-3.5" />
            </div>
          </div>

          {/* Password Input */}
          <div className="space-y-1.5">
            <label className="block text-[11px] font-mono uppercase tracking-wider text-[#A97849] font-bold">
              Access Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-10 py-3 bg-[#FAF7F2] rounded-2xl border border-[#242322]/15 text-xs text-[#242322] placeholder:text-[#242322]/35 focus:outline-none focus:border-[#A97849] focus:ring-1 focus:ring-[#A97849] transition-all font-mono tracking-wider"
              />
              <KeyRound className="w-4 h-4 text-[#242322]/40 absolute left-3.5 top-3.5" />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-3.5 text-[#242322]/40 hover:text-[#242322] transition-colors cursor-pointer"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50 mt-2"
          >
            <Lock className="w-4 h-4 text-[#E8F36B]" />
            <span>{loading ? 'VERIFYING CREDENTIALS...' : 'AUTHENTICATE AS ADMINISTRATOR'}</span>
          </button>
        </form>

        <div className="relative flex py-1 items-center">
          <div className="flex-grow border-t border-[#242322]/10"></div>
          <span className="flex-shrink mx-4 text-[10px] font-mono text-[#242322]/40 uppercase">Or Google OAuth</span>
          <div className="flex-grow border-t border-[#242322]/10"></div>
        </div>

        {/* Action: Google Sign In */}
        <button
          type="button"
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full py-3 bg-[#FAF7F2] hover:bg-white border border-[#242322]/15 text-[#242322] rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-3 cursor-pointer shadow-sm hover:shadow disabled:opacity-50"
        >
          <LogIn className="w-4 h-4 text-[#A97849]" />
          <span>SIGN IN WITH GOOGLE</span>
        </button>

        <div className="pt-2 text-[10px] font-mono text-[#242322]/40">
          KETOLUNE Studio Security • Identity & Password Verified
        </div>

      </div>
    </div>
  );
}
