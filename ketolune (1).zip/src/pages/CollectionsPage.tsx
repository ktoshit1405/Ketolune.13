import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { CURATED_COLLECTIONS, RecipientPath, CuratedCollection, CollectionInterest } from '../data/collectionsData';
import { CURRENT_BATCH, BatchTier } from '../data/batchData';
import { ArrowLeft, ArrowRight, Sparkles, Check, Compass, Eye, Heart, Layers } from 'lucide-react';

export default function CollectionsPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  
  // Recipient Path: Boys or Girls (defaults to 'girls' or param)
  const initialPath = (searchParams.get('path') as RecipientPath) || 'girls';
  const [activePath, setActivePath] = useState<RecipientPath>(initialPath);

  // Selected Collection
  const [selectedCollectionId, setSelectedCollectionId] = useState<string | null>(searchParams.get('collection'));
  
  // Selected Niche / Interest
  const [selectedInterestId, setSelectedInterestId] = useState<string | null>(null);

  // Selected Tier
  const [selectedTierId, setSelectedTierId] = useState<'mini' | 'medium' | 'large'>('medium');

  // Filter collections by path
  const collectionsForPath = CURATED_COLLECTIONS.filter((c) => c.path === activePath);
  const activeCollection = CURATED_COLLECTIONS.find((c) => c.id === selectedCollectionId) || null;

  const handlePathChange = (path: RecipientPath) => {
    setActivePath(path);
    setSelectedCollectionId(null);
    setSelectedInterestId(null);
    setSearchParams({ path });
  };

  const handleSelectCollection = (col: CuratedCollection) => {
    setSelectedCollectionId(col.id);
    setSelectedInterestId(col.interests[0]?.id || null);
    setSearchParams({ path: activePath, collection: col.id });
    window.scrollTo({ top: 400, behavior: 'smooth' });
  };

  const handleProceedToReserve = () => {
    if (!activeCollection) return;
    navigate(`/reserve?collection=${activeCollection.id}&path=${activePath}&tier=${selectedTierId}${selectedInterestId ? `&interest=${selectedInterestId}` : ''}`);
  };

  return (
    <div className="min-h-screen bg-[#F7EFDF] text-[#242322] font-sans selection:bg-[#E8F36B] selection:text-[#242322] pt-28 pb-32 px-4 sm:px-6">
      <div className="max-w-6xl mx-auto space-y-12">
        
        {/* Curatorial Header */}
        <div className="border-b border-[#242322]/15 pb-8 space-y-4">
          <div className="flex items-center gap-3 text-xs uppercase tracking-widest font-mono text-[#A97849] font-bold">
            <Compass className="w-3.5 h-3.5" />
            <span>Curated Collection Architecture</span>
            <span>•</span>
            <span>Two Paths, Eight Collections</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="font-condensed text-5xl sm:text-7xl lg:text-8xl text-[#242322] uppercase tracking-tight leading-[0.9] font-bold">
                CHOOSE A DIRECTION
              </h1>
              <p className="text-sm sm:text-base text-[#242322]/80 mt-3 font-sans max-w-xl">
                Every surprise begins by choosing who you are gifting. From there, discover tailored atelier collections, personal fandom niches, and handcrafted keepsakes.
              </p>
            </div>

            {/* Path Toggle: Boys or Girls */}
            <div className="flex items-center p-1.5 bg-white/80 rounded-full border border-[#242322]/15 shadow-sm">
              <button
                onClick={() => handlePathChange('girls')}
                className={`px-6 py-2.5 rounded-full text-xs font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
                  activePath === 'girls'
                    ? 'bg-[#242322] text-[#F7EFDF] shadow-md'
                    : 'text-[#242322]/70 hover:text-[#242322]'
                }`}
              >
                For Her / Girls
              </button>
              <button
                onClick={() => handlePathChange('boys')}
                className={`px-6 py-2.5 rounded-full text-xs font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
                  activePath === 'boys'
                    ? 'bg-[#242322] text-[#F7EFDF] shadow-md'
                    : 'text-[#242322]/70 hover:text-[#242322]'
                }`}
              >
                For Him / Boys
              </button>
            </div>
          </div>
        </div>

        {/* 4 Distinct Collections for Selected Path */}
        <div className="space-y-6">
          <div className="flex items-center justify-between text-xs font-mono text-[#242322]/70">
            <span className="uppercase tracking-widest font-bold text-[#A97849]">
              {activePath.toUpperCase()} COLLECTIONS (04 AVAILABLE)
            </span>
            <span>Click any collection to inspect items & niches</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {collectionsForPath.map((col, idx) => {
              const isSelected = activeCollection?.id === col.id;
              return (
                <div
                  key={col.id}
                  onClick={() => handleSelectCollection(col)}
                  className={`group rounded-3xl p-5 border transition-all duration-300 cursor-pointer flex flex-col justify-between space-y-4 ${
                    isSelected
                      ? 'bg-white border-[#242322] shadow-xl ring-2 ring-[#A97849]/50 -translate-y-1'
                      : 'bg-white/70 border-[#242322]/10 hover:bg-white hover:border-[#242322]/30 hover:shadow-md'
                  }`}
                >
                  <div className="space-y-3">
                    {/* Collection Cover Image */}
                    <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-[#EDE8DF] border border-[#242322]/10">
                      <img
                        src={col.coverImage}
                        alt={col.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-full bg-white/90 backdrop-blur-sm text-[10px] font-mono font-bold uppercase text-[#242322]">
                        0{idx + 1} • {col.path}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <h3 className="font-condensed text-2xl uppercase tracking-tight text-[#242322] font-bold group-hover:text-[#A97849] transition-colors">
                        {col.title}
                      </h3>
                      <p className="text-xs text-[#242322]/75 leading-relaxed font-sans line-clamp-2">
                        {col.tagline}
                      </p>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#242322]/10 flex items-center justify-between text-xs font-mono">
                    <span className="text-[#A97849] font-semibold">{col.interests.length} Niches</span>
                    <span className="text-xs font-bold text-[#242322] flex items-center gap-1">
                      <span>{isSelected ? 'Active' : 'Inspect'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Collection Deep Dive (Niches, Items, Inclusions & Tiers) */}
        {activeCollection && (
          <div className="p-8 sm:p-12 rounded-3xl bg-white/90 border border-[#242322]/15 shadow-xl space-y-10 animate-fade-in">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 pb-6 border-b border-[#242322]/10">
              <div className="space-y-2 max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FAF7F2] text-[#A97849] text-xs font-mono font-bold uppercase">
                  <span>Selected Collection</span>
                  <span>•</span>
                  <span>{activeCollection.path}</span>
                </div>
                <h2 className="font-condensed text-4xl sm:text-5xl uppercase tracking-tight text-[#242322] font-bold">
                  {activeCollection.title}
                </h2>
                <p className="text-base text-[#242322]/85 font-sans leading-relaxed">
                  {activeCollection.description}
                </p>
                <p className="text-xs font-mono text-[#A97849] italic">
                  Theme note: {activeCollection.themeExplanation}
                </p>
              </div>

              <div className="shrink-0">
                <button
                  onClick={handleProceedToReserve}
                  className="px-8 py-4 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-all shadow-xl hover:scale-105 flex items-center gap-2.5 cursor-pointer"
                >
                  <span>Reserve In This Collection</span>
                  <ArrowRight className="w-4 h-4 text-[#E8F36B]" />
                </button>
              </div>
            </div>

            {/* Interest & Niche Discovery */}
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                <span>1. Select An Interest Or Niche</span>
                <span className="text-[#242322]/40">Guides Studio Selection</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {activeCollection.interests.map((interest) => {
                  const isSelectedInterest = selectedInterestId === interest.id;
                  return (
                    <div
                      key={interest.id}
                      onClick={() => setSelectedInterestId(interest.id)}
                      className={`p-5 rounded-2xl border transition-all cursor-pointer space-y-2 ${
                        isSelectedInterest
                          ? 'bg-[#FAF7F2] border-[#A97849] shadow-md ring-1 ring-[#A97849]'
                          : 'bg-white border-[#242322]/10 hover:border-[#242322]/30'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <h4 className="font-condensed text-lg uppercase font-bold text-[#242322]">
                          {interest.label}
                        </h4>
                        <span className="text-xs text-[#A97849] font-mono">
                          {isSelectedInterest ? '●' : '○'}
                        </span>
                      </div>
                      <p className="text-xs text-[#242322]/75 font-sans leading-relaxed">
                        {interest.description}
                      </p>
                      <div className="pt-2 text-[11px] font-mono text-[#A97849]">
                        Sample pieces: {interest.sampleItems.join(', ')}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Actual Handmade Gift Items in this Collection */}
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                <span>2. Available Handcrafted Elements</span>
                <span className="text-[#242322]/40">Tactile Craft Inventory</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {activeCollection.availableItems.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 bg-white rounded-2xl border border-[#242322]/10 space-y-2 flex flex-col justify-between"
                  >
                    <div className="space-y-1">
                      <div className="text-[11px] font-mono text-[#A97849] uppercase font-semibold">
                        Craft Object
                      </div>
                      <h4 className="font-condensed text-lg uppercase tracking-tight text-[#242322] font-bold">
                        {item.name}
                      </h4>
                      <p className="text-xs text-[#242322]/75 font-sans leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                    <div className="pt-2 border-t border-[#242322]/10 text-[10px] font-mono text-[#242322]/60">
                      Materials: {item.materials}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Approved Gift Tiers Selection */}
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                <span>3. Select Gift Tier</span>
                <span>Delivery: ₹19</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {CURRENT_BATCH.tiers.map((t) => {
                  const isSelectedTier = selectedTierId === t.id;
                  return (
                    <div
                      key={t.id}
                      onClick={() => setSelectedTierId(t.id)}
                      className={`p-6 rounded-2xl border transition-all cursor-pointer space-y-3 flex flex-col justify-between ${
                        isSelectedTier
                          ? 'bg-[#FAF7F2] border-[#242322] shadow-lg ring-2 ring-[#A97849]/50'
                          : 'bg-white border-[#242322]/10 hover:border-[#242322]/30'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-baseline justify-between">
                          <h4 className="font-condensed text-2xl uppercase font-bold text-[#242322]">
                            {t.customerFacingName}
                          </h4>
                          <span className="font-mono text-base font-bold text-[#A97849]">
                            ₹{t.priceINR}
                          </span>
                        </div>
                        <p className="text-xs text-[#242322]/70 font-sans">
                          {t.tagline}
                        </p>
                        <div className="pt-3 space-y-1 text-xs text-[#242322]/80 font-sans">
                          {t.contents.map((item, i) => (
                            <div key={i} className="flex items-start gap-1.5">
                              <span className="text-[#A97849]">•</span>
                              <span>{item}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="pt-3 border-t border-[#242322]/10 flex items-center justify-between text-xs font-mono">
                        <span className="text-[#242322]/60">{t.dimensions}</span>
                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${
                          isSelectedTier ? 'bg-[#242322] text-[#F7EFDF]' : 'bg-[#242322]/10 text-[#242322]'
                        }`}>
                          {isSelectedTier ? 'Selected Tier' : 'Choose'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Bottom Call to Action */}
            <div className="pt-4 border-t border-[#242322]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="text-xs font-mono text-[#242322]/70">
                <span className="font-bold text-[#242322]">Selected:</span> {activeCollection.title} ({activePath}) • {CURRENT_BATCH.tiers.find(t => t.id === selectedTierId)?.customerFacingName} (₹{CURRENT_BATCH.tiers.find(t => t.id === selectedTierId)?.priceINR})
              </div>

              <button
                onClick={handleProceedToReserve}
                className="px-8 py-3.5 bg-[#242322] hover:bg-[#A97849] text-[#F7EFDF] rounded-full text-xs font-bold uppercase tracking-wider transition-all shadow-xl hover:scale-105 flex items-center justify-center gap-2.5 cursor-pointer"
              >
                <span>Proceed to Personalize & Reserve</span>
                <ArrowRight className="w-4 h-4 text-[#E8F36B]" />
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
