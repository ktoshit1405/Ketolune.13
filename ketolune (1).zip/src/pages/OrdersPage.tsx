import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { SAMPLE_ORDERS, OrderState } from '../data/batchData';
import { ArrowLeft, Package, Clock, ShieldCheck, CheckCircle2, Search, Truck } from 'lucide-react';

export default function OrdersPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const orderIdParam = searchParams.get('orderId') || 'KL-8821';

  const [searchId, setSearchId] = useState(orderIdParam);
  const [activeOrder, setActiveOrder] = useState<OrderState>(SAMPLE_ORDERS[orderIdParam] || SAMPLE_ORDERS['KL-8821']);

  const milestones = [
    { num: '01', title: 'Observation & Curation', days: 'Day 01–02', desc: 'Curators review your 3 answers and define the bespoke sensory direction.' },
    { num: '02', title: 'Studio Handcrafting', days: 'Day 03–04', desc: 'Assembling tactile keepsake elements, hand-shaping ceramics and poured aromatics.' },
    { num: '03', title: 'Inscription & Wax Seal', days: 'Day 05–06', desc: 'Inscribing your dedicated words with dip pen onto 300gsm cotton paper and pressing personal wax.' },
    { num: '04', title: 'Inspection & Dispatch', days: 'Day 07–08', desc: 'Wrapping in archival kraft, hand-tied cord, final studio inspection before courier hand-off.' },
  ];

  const handleSearch = () => {
    if (SAMPLE_ORDERS[searchId.trim()]) {
      setActiveOrder(SAMPLE_ORDERS[searchId.trim()]);
    } else {
      // Create active order state for simulated generated order
      setActiveOrder({
        orderId: searchId.trim(),
        recipientName: 'Elena Rostova',
        tierId: 'medium',
        selectedAroma: 'Alpine Lavender & Cypress',
        selectedCeramic: 'Volcanic Basalt',
        selectedRibbon: 'Dusty Lavender Tie',
        selectedWaxSeal: 'Deep Plum Wax',
        noteText: 'To the one who notices the quietest light at dusk. May this little weight bring your mornings stillness.',
        appreciationAmountINR: 50,
        currentMilestone: 2, // Studio Handcrafting
        estimatedDelivery: 'Approximately 7–8 business days preparation before dispatch',
        createdAt: 'OCT 13, 2026',
        shippingAddress: {
          name: 'Elena Rostova',
          address: '42 Meadowbrook Crescent, Indiranagar',
          city: 'Bengaluru',
          postalCode: '560038',
          state: 'Karnataka'
        }
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#F7EFDF] text-[#242322] font-sans selection:bg-[#E8F36B] selection:text-[#242322] pt-28 pb-32 px-4 sm:px-6">
      <div className="max-w-4xl mx-auto space-y-10">
        
        {/* Header */}
        <div className="border-b border-[#242322]/15 pb-6 space-y-3">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-xs font-mono uppercase text-[#242322]/70 hover:text-[#242322] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Landing Page</span>
          </button>

          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-4">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
                Handmade Production Tracking
              </span>
              <h1 className="font-condensed text-4xl sm:text-6xl uppercase tracking-tight text-[#242322] font-bold mt-1">
                PARCEL JOURNEY
              </h1>
            </div>

            <span className="text-xs font-mono text-[#242322]/70">
              Tracking ID: <strong className="text-[#242322]">{activeOrder.orderId}</strong>
            </span>
          </div>
        </div>

        {/* Search Bar */}
        <div className="p-4 bg-white/80 rounded-2xl border border-[#242322]/15 shadow-sm flex items-center gap-3">
          <input
            type="text"
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
            placeholder="Enter Order ID (e.g. KL-8821)..."
            className="flex-1 p-2 bg-transparent text-xs font-mono outline-none text-[#242322]"
          />
          <button
            onClick={handleSearch}
            className="px-6 py-2 bg-[#242322] text-[#F7EFDF] rounded-xl text-xs font-mono uppercase font-bold hover:bg-[#A97849] transition-colors cursor-pointer"
          >
            Track Parcel
          </button>
        </div>

        {/* Order Details & Lifecycle Timeline */}
        <div className="p-8 sm:p-10 bg-white/95 rounded-3xl border border-[#242322]/15 shadow-xl space-y-8">
          
          {/* Order Overview Header */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-6 border-b border-[#242322]/10">
            <div className="space-y-1">
              <span className="text-xs font-mono uppercase text-[#A97849] font-bold">
                Recipient Mystery Parcel
              </span>
              <h3 className="font-condensed text-3xl sm:text-4xl uppercase tracking-tight text-[#242322] font-bold">
                {activeOrder.recipientName}
              </h3>
              <p className="text-xs font-mono text-[#242322]/60">
                Created: {activeOrder.createdAt} • Dedicated Inscription On File
              </p>
            </div>

            <div className="p-3 bg-[#FAF7F2] rounded-2xl border border-[#242322]/10 text-right space-y-0.5">
              <span className="text-[10px] font-mono uppercase text-[#A97849] font-bold">
                Studio Timeline Policy
              </span>
              <div className="text-xs font-bold text-[#242322]">
                7–8 Business Days Studio Making
              </div>
              <p className="text-[10px] font-mono text-[#242322]/60">
                Delivery time additional by destination
              </p>
            </div>
          </div>

          {/* 4 Milestones */}
          <div className="space-y-4">
            <div className="text-xs font-mono uppercase tracking-widest text-[#A97849] font-bold">
              Production Lifecycle Stages
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {milestones.map((m, idx) => {
                const isCurrent = idx === 1; // Studio Handcrafting
                const isDone = idx < 1;
                return (
                  <div
                    key={m.num}
                    className={`p-5 rounded-2xl border space-y-2 transition-all ${
                      isCurrent
                        ? 'bg-[#FAF7F2] border-[#242322] shadow-md ring-1 ring-[#A97849]'
                        : isDone
                        ? 'bg-white/80 border-[#242322]/15'
                        : 'bg-white/40 border-[#242322]/10 opacity-75'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-[#A97849] font-bold">{m.days}</span>
                        <span className="text-xs font-bold uppercase tracking-tight text-[#242322] font-condensed">
                          {m.title}
                        </span>
                      </div>
                      <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-full ${
                        isCurrent
                          ? 'bg-[#E8F36B] text-[#242322]'
                          : isDone
                          ? 'bg-[#242322]/10 text-[#242322]'
                          : 'bg-black/5 text-[#242322]/40'
                      }`}>
                        {isCurrent ? 'IN PROGRESS' : isDone ? 'COMPLETED' : 'QUEUED'}
                      </span>
                    </div>
                    <p className="text-xs text-[#242322]/75 font-sans leading-relaxed">
                      {m.desc}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Inscription Note Preview */}
          <div className="p-6 bg-[#FAF7F2] rounded-2xl border-l-4 border-[#A97849] space-y-2">
            <div className="text-xs font-mono uppercase text-[#A97849] font-bold">
              Archival Keepsake Inscription Included:
            </div>
            <p className="text-sm font-serif italic text-[#242322] leading-relaxed">
              "{activeOrder.noteText}"
            </p>
          </div>

          {/* Destination */}
          {activeOrder.shippingAddress && (
            <div className="pt-2 border-t border-[#242322]/10 flex flex-col sm:flex-row sm:items-center justify-between text-xs font-mono text-[#242322]/70 gap-2">
              <div>
                Destination: {activeOrder.shippingAddress.address}, {activeOrder.shippingAddress.city} ({activeOrder.shippingAddress.postalCode})
              </div>
              <span className="text-[#A97849] font-bold">
                Standard ₹19 Tracked Courier Hand-off
              </span>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
